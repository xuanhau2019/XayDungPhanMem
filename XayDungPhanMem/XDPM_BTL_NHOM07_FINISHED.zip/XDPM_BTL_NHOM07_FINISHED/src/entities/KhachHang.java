package entities;

public class KhachHang {

	private String idkh;
	private String tenkh;
	private String sodt;
	private String diachi;
	
	public String getIdkh() {
		return idkh;
	}
	public void setIdkh(String idkh) {
		this.idkh = idkh;
	}
	public String getTenkh() {
		return tenkh;
	}
	public void setTenkh(String tenkh) {
		this.tenkh = tenkh;
	}
	public String getSodt() {
		return sodt;
	}
	public void setSodt(String sodt) {
		this.sodt = sodt;
	}
	public String getDiachi() {
		return diachi;
	}
	public void setDiachi(String diachi) {
		this.diachi = diachi;
	}
	
	@Override
	public int hashCode() {
		final int prime = 31;
		int result = 1;
		result = prime * result + ((idkh == null) ? 0 : idkh.hashCode());
		return result;
	}
	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (obj == null)
			return false;
		if (getClass() != obj.getClass())
			return false;
		KhachHang other = (KhachHang) obj;
		if (idkh == null) {
			if (other.idkh != null)
				return false;
		} else if (!idkh.equals(other.idkh))
			return false;
		return true;
	}
	
	public KhachHang() {
		super();
		// TODO Auto-generated constructor stub
	}
	public KhachHang(String idkh, String tenkh, String sodt, String diachi) {
		super();
		this.idkh = idkh;
		this.tenkh = tenkh;
		this.sodt = sodt;
		this.diachi = diachi;
	}
	@Override
	public String toString() {
		return idkh + " - " + tenkh;
	}
	
	
}
