package entities;

import java.util.Date;
import java.util.List;

public class PhieuThue {

	private String maphieuthue;
	private KhachHang kh;
	private Date ngaythue;
	
	List<ChiTietPhieuThue> listCTPT;
	
	public String getMaphieuthue() {
		return maphieuthue;
	}
	public void setMaphieuthue(String maphieuthue) {
		this.maphieuthue = maphieuthue;
	}
	public KhachHang getKh() {
		return kh;
	}
	public void setKh(KhachHang kh) {
		this.kh = kh;
	}
	public Date getNgaythue() {
		return ngaythue;
	}
	public void setNgaythue(Date ngaythue) {
		this.ngaythue = ngaythue;
	}	
	public List<ChiTietPhieuThue> getListCTPT() {
		return listCTPT;
	}
	public void setListCTPT(List<ChiTietPhieuThue> listCTPT) {
		this.listCTPT = listCTPT;
	}
	
	public PhieuThue() {
		super();
	}
	public PhieuThue(String maphieuthue, KhachHang kh, Date ngaythue) {
		super();
		this.maphieuthue = maphieuthue;
		this.kh = kh;
		this.ngaythue = ngaythue;
	}
}
