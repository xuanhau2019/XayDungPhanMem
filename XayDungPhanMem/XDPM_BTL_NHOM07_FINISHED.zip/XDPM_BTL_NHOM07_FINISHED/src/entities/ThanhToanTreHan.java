package entities;

import java.util.Date;

public class ThanhToanTreHan {

	private String mathanhtoan;
	private PhiTreHan phitrehan;
	private Date ngaytrano;
	
	public String getMathanhtoan() {
		return mathanhtoan;
	}
	public void setMathanhtoan(String mathanhtoan) {
		this.mathanhtoan = mathanhtoan;
	}
	public PhiTreHan getPhitrehan() {
		return phitrehan;
	}
	public void setPhitrehan(PhiTreHan phitrehan) {
		this.phitrehan = phitrehan;
	}
	public Date getNgaytrano() {
		return ngaytrano;
	}
	public void setNgaytrano(Date ngaytrano) {
		this.ngaytrano = ngaytrano;
	}
	
	public ThanhToanTreHan() {
		super();
	}
	public ThanhToanTreHan(String mathanhtoan, PhiTreHan phitrehan, Date ngaytrano) {
		super();
		this.mathanhtoan = mathanhtoan;
		this.phitrehan = phitrehan;
		this.ngaytrano = ngaytrano;
	}	
}
