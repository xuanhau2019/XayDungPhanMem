package entities;

public class Dia {

	private String madia;
	private String trangthai;
	private TuaDia tuadia;
	
	public String getMadia() {
		return madia;
	}
	public void setMadia(String madia) {
		this.madia = madia;
	}
	public String getTrangthai() {
		return trangthai;
	}
	public void setTrangthai(String trangthai) {
		this.trangthai = trangthai;
	}
	public TuaDia getTuadia() {
		return tuadia;
	}
	public void setTuadia(TuaDia tuadia) {
		this.tuadia = tuadia;
	}
	
	@Override
	public int hashCode() {
		final int prime = 31;
		int result = 1;
		result = prime * result + ((madia == null) ? 0 : madia.hashCode());
		return result;
	}
	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (obj == null)
			return false;
		if (getClass() != obj.getClass())
			return false;
		Dia other = (Dia) obj;
		if (madia == null) {
			if (other.madia != null)
				return false;
		} else if (!madia.equals(other.madia))
			return false;
		return true;
	}
	
	public Dia() {
		super();
	}
	public Dia(String madia, String trangthai, TuaDia tuadia) {
		super();
		this.madia = madia;
		this.trangthai = trangthai;
		this.tuadia = tuadia;
	}
	
	@Override
	public String toString() {
		return madia;
	}	
}
