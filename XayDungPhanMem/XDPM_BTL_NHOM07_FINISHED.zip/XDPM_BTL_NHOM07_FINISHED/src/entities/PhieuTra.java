package entities;

import java.util.Date;

public class PhieuTra {

	private String maphieutra;
	private Date ngaytradia;
	private PhieuThue phieuthue;
	private Dia dia;
	
	public String getMaphieutra() {
		return maphieutra;
	}
	public void setMaphieutra(String maphieutra) {
		this.maphieutra = maphieutra;
	}
	public Date getNgaytradia() {
		return ngaytradia;
	}
	public void setNgaytradia(Date ngaytradia) {
		this.ngaytradia = ngaytradia;
	}
	public PhieuThue getPhieuthue() {
		return phieuthue;
	}
	public void setPhieuthue(PhieuThue phieuthue) {
		this.phieuthue = phieuthue;
	}
	public Dia getDia() {
		return dia;
	}
	public void setDia(Dia dia) {
		this.dia = dia;
	}
	
	public PhieuTra() {
		super();
	}
	public PhieuTra(String maphieutra, Date ngaytradia, PhieuThue phieuthue, Dia dia) {
		super();
		this.maphieutra = maphieutra;
		this.ngaytradia = ngaytradia;
		this.phieuthue = phieuthue;
		this.dia = dia;
	}
}
