package entities;

import java.util.List;

public class TuaDia {
	
	private String matua;
	private String tentua;
	private LoaiDia loaidia;
	private double phitrehan;
	private String mota;
	private String anh;
	
	private List<Dia> listDia;

	public String getMatua() {
		return matua;
	}

	public void setMatua(String matua) {
		this.matua = matua;
	}

	public String getTentua() {
		return tentua;
	}

	public void setTentua(String tentua) {
		this.tentua = tentua;
	}

	public LoaiDia getLoaidia() {
		return loaidia;
	}

	public void setLoaidia(LoaiDia loaidia) {
		this.loaidia = loaidia;
	}

	public double getPhitrehan() {
		return phitrehan;
	}

	public void setPhitrehan(double phitrehan) {
		this.phitrehan = phitrehan;
	}

	public String getMota() {
		return mota;
	}

	public void setMota(String mota) {
		this.mota = mota;
	}

	public String getAnh() {
		return anh;
	}

	public void setAnh(String anh) {
		this.anh = anh;
	}

	public List<Dia> getListDia() {
		return listDia;
	}

	public void setListDia(List<Dia> listDia) {
		this.listDia = listDia;
	}

	@Override
	public int hashCode() {
		final int prime = 31;
		int result = 1;
		result = prime * result + ((matua == null) ? 0 : matua.hashCode());
		return result;
	}

	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (obj == null)
			return false;
		if (getClass() != obj.getClass())
			return false;
		TuaDia other = (TuaDia) obj;
		if (matua == null) {
			if (other.matua != null)
				return false;
		} else if (!matua.equals(other.matua))
			return false;
		return true;
	}

	public TuaDia() {
		super();
	}
	public TuaDia(String matua, String tentua, LoaiDia loaidia, double phitrehan, String mota, String anh) {
		super();
		this.matua = matua;
		this.tentua = tentua;
		this.loaidia = loaidia;
		this.phitrehan = phitrehan;
		this.mota = mota;
		this.anh = anh;
	}

	@Override
	public String toString() {
		return tentua + " - " + loaidia.getTenloaidia();
	}
}
