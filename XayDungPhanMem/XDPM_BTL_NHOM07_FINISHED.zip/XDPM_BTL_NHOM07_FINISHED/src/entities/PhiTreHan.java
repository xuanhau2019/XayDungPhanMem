package entities;

public class PhiTreHan {

	private String matrehan;
	private PhieuTra phieutra;
	private double tienno;
	
	public String getMatrehan() {
		return matrehan;
	}
	public void setMatrehan(String matrehan) {
		this.matrehan = matrehan;
	}
	public PhieuTra getPhieutra() {
		return phieutra;
	}
	public void setPhieutra(PhieuTra phieutra) {
		this.phieutra = phieutra;
	}
	public double getTienno() {
		return tienno;
	}
	public void setTienno(double tienno) {
		this.tienno = tienno;
	}
	
	public PhiTreHan() {
		super();
	}
	public PhiTreHan(String matrehan, PhieuTra phieutra, double tienno) {
		super();
		this.matrehan = matrehan;
		this.phieutra = phieutra;
		this.tienno = tienno;
	}	
}
