package entities;

public class TaiKhoan {

	private String madn;
	private String matkhau;
	
	public String getMadn() {
		return madn;
	}
	public void setMadn(String madn) {
		this.madn = madn;
	}
	public String getMatkhau() {
		return matkhau;
	}
	public void setMatkhau(String matkhau) {
		this.matkhau = matkhau;
	}
	
	public TaiKhoan() {
		super();
	}
	public TaiKhoan(String madn, String matkhau) {
		super();
		this.madn = madn;
		this.matkhau = matkhau;
	}
}
