package entities;

public class LoaiDia {

	private int maloaidia;
	private String tenloaidia;
	private double giathue;
	private int hanthue;
	
	public int getMaloaidia() {
		return maloaidia;
	}
	public void setMaloaidia(int maloaidia) {
		this.maloaidia = maloaidia;
	}
	public String getTenloaidia() {
		return tenloaidia;
	}
	public void setTenloaidia(String tenloaidia) {
		this.tenloaidia = tenloaidia;
	}
	public double getGiathue() {
		return giathue;
	}
	public void setGiathue(double giathue) {
		this.giathue = giathue;
	}
	public int getHanthue() {
		return hanthue;
	}
	public void setHanthue(int hanthue) {
		this.hanthue = hanthue;
	}
	
	public LoaiDia() {
		super();
	}
	public LoaiDia(int maloaidia, String tenloaidia, double giathue, int hanthue) {
		super();
		this.maloaidia = maloaidia;
		this.tenloaidia = tenloaidia;
		this.giathue = giathue;
		this.hanthue = hanthue;
	}	
}
