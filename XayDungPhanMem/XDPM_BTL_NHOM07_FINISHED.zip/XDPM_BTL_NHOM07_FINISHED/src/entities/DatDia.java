package entities;

import java.util.Date;

public class DatDia {

	private KhachHang kh;
	private TuaDia tuadia;
	private Date ngaydat;
	private Dia ganDia;
	
	public KhachHang getKh() {
		return kh;
	}
	public void setKh(KhachHang kh) {
		this.kh = kh;
	}
	public TuaDia getTuadia() {
		return tuadia;
	}
	public void setTuadia(TuaDia tuadia) {
		this.tuadia = tuadia;
	}
	public Date getNgaydat() {
		return ngaydat;
	}
	public void setNgaydat(Date ngaydat) {
		this.ngaydat = ngaydat;
	}	
	public Dia getGanDia() {
		return ganDia;
	}
	public void setGanDia(Dia ganDia) {
		this.ganDia = ganDia;
	}
	
	public DatDia() {
		super();
	}
	public DatDia(KhachHang kh, TuaDia tuadia, Date ngaydat, Dia ganDia) {
		super();
		this.kh = kh;
		this.tuadia = tuadia;
		this.ngaydat = ngaydat;
		this.ganDia = ganDia;
	}	
}
