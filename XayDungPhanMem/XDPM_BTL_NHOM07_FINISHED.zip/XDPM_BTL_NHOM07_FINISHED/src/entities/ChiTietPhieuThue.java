package entities;

public class ChiTietPhieuThue {

	private PhieuThue phieuthue;
	private Dia dia;
	private double phitrehan;
	private int hantradia;
	private double giathue;
	private String trangthai;

	public PhieuThue getPhieuthue() {
		return phieuthue;
	}

	public void setPhieuthue(PhieuThue phieuthue) {
		this.phieuthue = phieuthue;
	}

	public Dia getDia() {
		return dia;
	}

	public void setDia(Dia dia) {
		this.dia = dia;
	}

	public double getPhitrehan() {
		return phitrehan;
	}

	public void setPhitrehan(double phitrehan) {
		this.phitrehan = phitrehan;
	}

	public int getHantradia() {
		return hantradia;
	}

	public void setHantradia(int hantradia) {
		this.hantradia = hantradia;
	}

	public double getGiathue() {
		return giathue;
	}

	public void setGiathue(double giathue) {
		this.giathue = giathue;
	}

	public String getTrangthai() {
		return trangthai;
	}

	public void setTrangthai(String trangthai) {
		this.trangthai = trangthai;
	}

	@Override
	public int hashCode() {
		final int prime = 31;
		int result = 1;
		result = prime * result + ((dia == null) ? 0 : dia.hashCode());
		return result;
	}

	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (obj == null)
			return false;
		if (getClass() != obj.getClass())
			return false;
		ChiTietPhieuThue other = (ChiTietPhieuThue) obj;
		if (dia == null) {
			if (other.dia != null)
				return false;
		} else if (!dia.equals(other.dia))
			return false;
		return true;
	}

	public ChiTietPhieuThue(PhieuThue phieuthue, Dia dia, double phitrehan, int hantradia, double giathue,
			String trangthai) {
		super();
		this.phieuthue = phieuthue;
		this.dia = dia;
		this.phitrehan = phitrehan;
		this.hantradia = hantradia;
		this.giathue = giathue;
		this.trangthai = trangthai;
	}

	public ChiTietPhieuThue() {
		super();
	}	
}
