package control;

import java.sql.CallableStatement;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.List;

import dal.KetNoiDB;
import entities.Dia;
import entities.LoaiDia;
import entities.TuaDia;

public class TuaDiaControl {
	
public ArrayList<TuaDia> listTuaDia;
	
	public TuaDiaControl() {
		listTuaDia = new ArrayList<>();
	}
	
	/**
	 * kết nối với CSDL để tìm thông tin tựa đĩa
	 * @param ttTim
	 * @return
	 */
	public ArrayList<TuaDia> timThongTinTuaDia(String ttTim) {
		ArrayList<TuaDia> array = new ArrayList<>();
		Connection con = KetNoiDB.getConnection();
		try {
			CallableStatement call = con.prepareCall("{call tuadia_TimThongTin(?)}");
			call.setString(1, ttTim);
			
			DiaControl diaCon = new DiaControl();
			
			ResultSet res = call.executeQuery();
			while(res.next()) {
				String matua = res.getString(1);
				String tentua = res.getString(2);
				int maloaidia = res.getInt(3);
				String tenloaidia = res.getString(4);
				double giathue = res.getFloat(5);
				int hanthue = res.getInt(6);
				double phitrehan = res.getDouble(7);
				String mota = res.getString(8);
				String anh = res.getString(9);
				
				LoaiDia loai = new LoaiDia(maloaidia, tenloaidia, giathue, hanthue);
				TuaDia td = new TuaDia(matua, tentua, loai, phitrehan, mota, anh);
				
				List<Dia> listDia = diaCon.getAllDiaByMaTua(td);
				td.setListDia(listDia);
				
				array.add(td);
			}
		} catch (SQLException e) {
			e.printStackTrace();
		}
		return array;
	}
	
	//------------------------------------------------ TRƯỜNG GIANG ------------------------------------------------//
	public List<TuaDia> getAllTuaDia() {
		ArrayList<TuaDia> list = new ArrayList<>();
		Connection con = KetNoiDB.getConnection();
		try {
			CallableStatement call = con.prepareCall("{call tuadia_getAllThongTin}");
			DiaControl diaCon = new DiaControl();
			ResultSet res = call.executeQuery();
			while(res.next()) {
				String matua = res.getString(1);
				String tentua = res.getString(2);
				int maloaidia = res.getInt(3);
				String tenloaidia = res.getString(4);
				double giathue = res.getFloat(5);
				int hanthue = res.getInt(6);
				double phitrehan = res.getDouble(7);
				String mota = res.getString(8);
				String anh = res.getString(9);
				
				LoaiDia loai = new LoaiDia(maloaidia, tenloaidia, giathue, hanthue);
				TuaDia td = new TuaDia(matua, tentua, loai, phitrehan, mota, anh);
				
				List<Dia> listDia = diaCon.getAllDiaByMaTua(td);
				td.setListDia(listDia);
				
				list.add(td);
			}
		} catch (SQLException e) {
			e.printStackTrace();
		}
		return list;
	}

	public String getMatuaMax() {
		Connection con = KetNoiDB.getConnection();
		String ma = null;
		try {
			Statement stm = con.createStatement();
			ResultSet res = stm.executeQuery("select MAX(matua) from TuaDia");
			while(res.next()) {
				ma = res.getString(1);
			}
		} catch (SQLException e) {
			e.printStackTrace();
		}
		return ma;
	}

	public boolean themTua(TuaDia tua) {
		Connection con = KetNoiDB.getConnection();
		try {
			PreparedStatement stm = con.prepareStatement("Insert into TuaDia values (?,?,?,?,?,?)");
			stm.setString(1, tua.getMatua());
			stm.setNString(2, tua.getTentua());
			stm.setInt(3, tua.getLoaidia().getMaloaidia());
			stm.setDouble(4, tua.getPhitrehan());
			stm.setNString(5, tua.getMota());
			stm.setNString(6, tua.getAnh());
			stm.execute();
			return true;
		} catch (SQLException e) {
			e.printStackTrace();
		}
		return false;
	}

	public TuaDia getTuaByID(String maTua) {
		Connection con = KetNoiDB.getConnection();
		try {
			CallableStatement call = con.prepareCall("{call tuadia_timTuaTheoMa(?)}");
			call.setString(1, maTua);
			DiaControl diaCon = new DiaControl();
			ResultSet res = call.executeQuery();
			while(res.next()) {
				String tentua = res.getString(2);
				int maloaidia = res.getInt(3);
				String tenloaidia = res.getString(4);
				double giathue = res.getFloat(5);
				int hanthue = res.getInt(6);
				double phitrehan = res.getDouble(7);
				String mota = res.getString(8);
				String anh = res.getString(9);
				
				LoaiDia loai = new LoaiDia(maloaidia, tenloaidia, giathue, hanthue);
				TuaDia td = new TuaDia(maTua, tentua, loai, phitrehan, mota, anh);
				
				List<Dia> listDia = diaCon.getAllDiaByMaTua(td);
				td.setListDia(listDia);
				return td;
			}
		} catch (SQLException e) {
			e.printStackTrace();
		}
		return null;
	}

	public boolean suaTua(TuaDia tua) {
		Connection con = KetNoiDB.getConnection();
		try {
			PreparedStatement stm = con.prepareStatement("update TuaDia set tentua = ?, maloaidia = ?, mota = ?, anh = ? where matua = ?");
			stm.setNString(1, tua.getTentua());
			stm.setInt(2, tua.getLoaidia().getMaloaidia());
			stm.setNString(3, tua.getMota());
			stm.setNString(4, tua.getAnh());
			stm.setString(5, tua.getMatua());
			stm.execute();
			return true;
		} catch (SQLException e) {
			e.printStackTrace();
		}
		return false;
	}
	
	public boolean xoaTua(String matua) {
		Connection con = KetNoiDB.getConnection();
		try {
			PreparedStatement stm = con.prepareStatement("Delete from TuaDia where matua = ?");
			stm.setString(1, matua);
			stm.execute();
			return true;
		} catch (SQLException e) {
			return false;
		}
		
	}
	
	
	public int soLuongKhachDatTua(String matua) {
		Connection con = KetNoiDB.getConnection();
		int count = 0;
		try {
			PreparedStatement stm = con.prepareStatement("Select count(*) from DatDia where matua = ? and madia is null");
			stm.setString(1, matua);
			ResultSet rs = stm.executeQuery();
			while (rs.next()) {
				count = rs.getInt(1);
			}
			return count;
		} catch (SQLException e) {
			e.printStackTrace();
			return 0;
		}
	}
}
