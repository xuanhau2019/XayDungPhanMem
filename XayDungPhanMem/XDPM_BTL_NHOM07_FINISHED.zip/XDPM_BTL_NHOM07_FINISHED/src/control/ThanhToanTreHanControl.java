package control;

import java.sql.CallableStatement;
import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;

import dal.KetNoiDB;
import entities.ThanhToanTreHan;

public class ThanhToanTreHanControl {
	
public ArrayList<ThanhToanTreHan> listTTTreHan;
	
	SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd");
	
	public ThanhToanTreHanControl() {
		listTTTreHan = new ArrayList<>();
	}
	
	/**
	 * kết nối với CSDL và lấy mã thanh toán cuối cùng
	 */
	public String getLastMaThanhToanTreHan() {
		Connection con = KetNoiDB.getConnection();
		String ma = null;
		try {
			CallableStatement call = con.prepareCall("{call thanhtoanTreHan_GetLastMaTT}");
			ResultSet res = call.executeQuery();
			while(res.next()) {
				ma = res.getString(1);
			}
		} catch (SQLException e) {
			e.printStackTrace();
		}
		return ma;
	}
	
	/**
	 * Kết nối CSDL và thêm thanh toán trễ hạn
	 * @param pt
	 * @return
	 */
	public boolean themThanhToanTreHan(ThanhToanTreHan ttTreHan) {
		Connection con = KetNoiDB.getConnection();
		int n = 0;
		try {
			CallableStatement call = con.prepareCall("{call thanhtoanTreHan_Them(?,?,?)}");
			call.setString(1, ttTreHan.getMathanhtoan());
			call.setString(2, ttTreHan.getPhitrehan().getMatrehan());
			call.setString(3, sdf.format(ttTreHan.getNgaytrano()));
			n = call.executeUpdate();
		} catch (SQLException e) {
			e.printStackTrace();
		}
		return n > 0;
	}
}
