package control;

import java.sql.CallableStatement;
import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;

import dal.KetNoiDB;
import entities.Dia;
import entities.PhieuThue;
import entities.PhieuTra;

public class PhieuTraControl {

public ArrayList<PhieuTra> listPhieuTra;
	
	SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd");
	
	public PhieuTraControl() {
		listPhieuTra = new ArrayList<>();
	}
	
	/**
	 * kết nối với CSDL và lấy mã phiếu trả cuối cùng
	 */
	public String getLastMaPhieuTra() {
		Connection con = KetNoiDB.getConnection();
		String ma = null;
		try {
			CallableStatement call = con.prepareCall("{call phieutra_GetLastMaPTra}");
			ResultSet res = call.executeQuery();
			while(res.next()) {
				ma = res.getString(1);
			}
		} catch (SQLException e) {
			e.printStackTrace();
		}
		return ma;
	}
	
	/**
	 * kết nối với CSDL để thêm phiếu tra
	 * @param ptra
	 * @return
	 */
	public boolean themPhieuTra(PhieuTra ptra) {
		Connection con = KetNoiDB.getConnection();
		int n = 0;
		try {
			CallableStatement call = con.prepareCall("{call phieutra_Them(?,?,?,?)}");
			call.setString(1, ptra.getMaphieutra());
			call.setString(2, sdf.format(ptra.getNgaytradia()));
			call.setString(3, ptra.getPhieuthue().getMaphieuthue());
			call.setString(4, ptra.getDia().getMadia());
			
			n = call.executeUpdate();
		} catch (SQLException e) {
			e.printStackTrace();
		}
		return n > 0;
	}
	
	/**
	 * kết nối với CSDL để tìm phiếu tra
	 * @param mapt
	 * @return
	 */
	public PhieuTra timPhieuTraTheoMaPT(String maptra) {
		PhieuTra pt = null;
		Connection con = KetNoiDB.getConnection();
		try {
			CallableStatement call = con.prepareCall("{call phieutra_TimTheoMaPT(?)}");
			call.setString(1, maptra);
			ResultSet res = call.executeQuery();
			while(res.next()) {
				String maphieutra = res.getString(1);
				Date ngaytradia = res.getDate(2);
				String maphieuthue = res.getString(3);
				String madia = res.getString(4);
				DiaControl diaCon = new DiaControl();
				PhieuThueControl pthueCon = new PhieuThueControl();
				
				Dia dia = diaCon.timThongTinDia(madia).get(0);
				PhieuThue phieuthue = pthueCon.timPhieuThueTheoMaPT(maphieuthue);
				pt = new PhieuTra(maphieutra, ngaytradia, phieuthue, dia);
			}
		} catch (SQLException e) {
			e.printStackTrace();
		}
		return pt;
	}
}
