package control;

import java.sql.CallableStatement;
import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.Date;

import dal.KetNoiDB;
import entities.Dia;
import entities.KhachHang;
import entities.PhiTreHan;
import entities.PhieuThue;
import entities.PhieuTra;

public class ThongKeControl {

	/**
	 * * Kết nối vào CSDL và thống kê thông tin tất cả khách hàng
	 * 
	 * @return
	 */
	public ArrayList<Object[]> thongKeThongTinKhachHang() {
		ArrayList<Object[]> arrayObjects = new ArrayList<>();
		Connection con = KetNoiDB.getConnection();
		try {
			CallableStatement call = con.prepareCall("{call thongke_ThongTinKhachHang}");
			ResultSet res = call.executeQuery();
			
			while(res.next()) {
				String idkh = res.getString(1);
				String tenkh = res.getString(2);
				String sodt = res.getString(3);
				String diachi = res.getString(4);
				int soDiaDangGiu = res.getInt(5) - demSoDiaKhachDaTra(idkh);
				double tongTienDangNo = 0;
				if(res.getString(6) != null)
					tongTienDangNo = res.getDouble(6) - tongSoTienKhachTra(idkh);
				
				KhachHang kh = new KhachHang(idkh, tenkh, sodt, diachi);
				Object[] objs = {kh, soDiaDangGiu, tongTienDangNo};
				arrayObjects.add(objs);
			}
		} catch (SQLException e) {
			e.printStackTrace();
		}
		return arrayObjects;
	}
	
	/**
	 * * Kết nối vào CSDL và thống kê khách hàng có nợ phí trễ hạn
	 *
	 * @return
	 */
	public ArrayList<Object[]> thongKeKhachHangCoPhiTreHan() {
		ArrayList<Object[]> arrayObjects = new ArrayList<>();
		Connection con = KetNoiDB.getConnection();
		try {
			CallableStatement call = con.prepareCall("{call ThongKe_KhachHangCoPhiTreHan}");
			ResultSet res = call.executeQuery();
			
			while(res.next()) {
				String idkh = res.getString(1);
				String tenkh = res.getString(2);
				String sodt = res.getString(3);
				String diachi = res.getString(4);
				int soDiaDangGiu = res.getInt(5) - demSoDiaKhachDaTra(idkh);
				double tongTienDangNo = 0;
				if(res.getString(6) != null)
					tongTienDangNo = res.getDouble(6) - tongSoTienKhachTra(idkh);
				
				if(tongTienDangNo > 0) {
					KhachHang kh = new KhachHang(idkh, tenkh, sodt, diachi);
					Object[] objs = {kh, soDiaDangGiu, tongTienDangNo};
					arrayObjects.add(objs);
				}
			}
		} catch (SQLException e) {
			e.printStackTrace();
		}
		return arrayObjects;
	}
	
	/**
	 * * Kết nối vào CSDL và thống kê khách hàng có đĩa trễ hạn
	 *
	 * @return
	 */
	public ArrayList<Object[]> thongKeKhachHangCoDiaTreHan() {
		ArrayList<Object[]> arrayObjects = new ArrayList<>();
		Connection con = KetNoiDB.getConnection();
		try {
			CallableStatement call = con.prepareCall("{call ThongKe_KhachHangCoDiaTreHan}");
			ResultSet res = call.executeQuery();
			
			while(res.next()) {
				String idkh = res.getString(1);
				String tenkh = res.getString(2);
				String sodt = res.getString(3);
				String diachi = res.getString(4);
				int soDiaDangGiu = res.getInt(5) - demSoDiaKhachDaTra(idkh);
				double tongTienDangNo = 0;
				if(res.getString(6) != null)
					tongTienDangNo = res.getDouble(6) - tongSoTienKhachTra(idkh);
				
				KhachHang kh = new KhachHang(idkh, tenkh, sodt, diachi);
				Object[] objs = {kh, soDiaDangGiu, tongTienDangNo};
				arrayObjects.add(objs);
			}
		} catch (SQLException e) {
			e.printStackTrace();
		}
		return arrayObjects;
	}
	
	/**
	 * Kết nối CSDL và thống kê theo khách hàng
	 * @param idkh
	 * @return
	 */
	public ArrayList<Object[]> thongKeTheoTungKhachHang(String idkh) {
		ArrayList<Object[]> arrayObjects = new ArrayList<>();
		Connection con = KetNoiDB.getConnection();
		try {
			CallableStatement call = con.prepareCall("{call thongke_TheoTungKhachHang(?)}");
			call.setString(1, idkh);

			DiaControl diaCon = new DiaControl();
			PhieuThueControl pthueCon = new PhieuThueControl();
			PhieuTraControl ptraCon = new PhieuTraControl();
			PhiTreHanControl ptrehanCon = new PhiTreHanControl();
			
			Dia dia = null;
			PhieuThue pthue = null;
			PhieuTra ptra = null;
			PhiTreHan phiTreHan = null;
			
			ResultSet res = call.executeQuery();
			while(res.next()) {
				dia = diaCon.timDiaTheoMa(res.getString(1));
				pthue = pthueCon.timPhieuThueTheoMaPT(res.getString(2));
				String maPhieuTra = res.getString(3);
				if(maPhieuTra != null)
					ptra = ptraCon.timPhieuTraTheoMaPT(maPhieuTra);
				else
					ptra = null;
				String maTreHan = res.getString(4);
				if(maTreHan != null)
					phiTreHan = ptrehanCon.timPhiTreHan(maTreHan);
				else
					phiTreHan = null;
				Date kyHan = res.getDate(6);
				
				Object[] objs = {dia, pthue, ptra, kyHan, res.getString(5), phiTreHan};
				arrayObjects.add(objs);
			}
		} catch (SQLException e) {
			e.printStackTrace();
		}
		return arrayObjects;
	}
	
	/**
	 * Kết nối vào CSDL và gọi hàm đếm số đĩa khách trả
	 * @param idkh
	 * @return
	 */
	public int demSoDiaKhachDaTra(String idkh) {
		int sodiatra = 0;
		Connection con = KetNoiDB.getConnection();
		try {
			CallableStatement call = con.prepareCall("{call countSoDiaTra(?)}");
			call.setString(1, idkh);
			
			ResultSet res = call.executeQuery();
			while(res.next()) {
				sodiatra = res.getInt(1);
			}
		} catch (SQLException e) {
			e.printStackTrace();
		}
		return sodiatra;
	}
	
	/**
	 * Kết nối vào CSDL và gọi hàm tính tổng số tiền khách đã trả
	 * @param idkh
	 * @return
	 */
	public double tongSoTienKhachTra(String idkh) {
		double sotientra = 0;
		Connection con = KetNoiDB.getConnection();
		try {
			CallableStatement call = con.prepareCall("{call sumSoTienTra(?)}");
			call.setString(1, idkh);
			
			ResultSet res = call.executeQuery();
			while(res.next()) {
				sotientra = res.getDouble(1);
			}
		} catch (SQLException e) {
			e.printStackTrace();
		}
		return sotientra;
	}
}
