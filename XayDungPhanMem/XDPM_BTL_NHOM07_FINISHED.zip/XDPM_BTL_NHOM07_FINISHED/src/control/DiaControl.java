package control;

import java.sql.CallableStatement;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

import dal.KetNoiDB;
import entities.Dia;
import entities.LoaiDia;
import entities.TuaDia;

public class DiaControl {

public ArrayList<Dia> listDia;
	TuaDiaControl tuaDiaControl = new TuaDiaControl();
	public DiaControl() {
		listDia = new ArrayList<>();
	}
	
	/**
	 * kết nối với CSDL để cập nhật lại thông tin đĩa
	 * @param dia
	 * @return
	 */
	public boolean capnhatThongTinDia(Dia dia) {
		int n = 0;
		Connection con = KetNoiDB.getConnection();
		try {
			CallableStatement call = con.prepareCall("{call dia_capnhatThongTin(?,?,?)}");
			call.setString(1, dia.getMadia());
			call.setString(2, dia.getTrangthai());
			call.setString(3, dia.getTuadia().getMatua());
			n = call.executeUpdate();
		} catch (SQLException e) {
			e.printStackTrace();
		}
		return n > 0;
	}
	
	/**
	 * kết nối với CSDL để tìm thông tin đĩa
	 * @param ttTim
	 * @return
	 */
	public ArrayList<Dia> timThongTinDia(String ttTim) {
		ArrayList<Dia> array = new ArrayList<>();
		Connection con = KetNoiDB.getConnection();
		try {
			CallableStatement call = con.prepareCall("{call dia_timThongTin(?)}");
			call.setString(1, ttTim);
			
			ResultSet res = call.executeQuery();
			while(res.next()) {
				String madia = res.getString(1);
				String trangthai = res.getString(2);
				String matua = res.getString(3);
				String tentua = res.getString(4);
				int maloaidia = res.getInt(5);
				String tenloaidia = res.getString(6);
				double giathue = res.getFloat(7);
				int hanthue = res.getInt(8);
				double phitrehan = res.getDouble(9);
				String mota = res.getString(10);
				String anh = res.getString(11);
				
				LoaiDia ld = new LoaiDia(maloaidia, tenloaidia, giathue, hanthue);
				TuaDia td = new TuaDia(matua, tentua, ld, phitrehan, mota, anh);
				Dia d = new Dia(madia, trangthai, td);
				array.add(d);
			}
		} catch (SQLException e) {
			e.printStackTrace();
		}
		return array;
	}
	
	/**
	 * kết nối với CSDL để tìm đĩa trên kệ
	 * @param ttTim
	 * @return
	 */
	public Dia timDiaTheoMa(String madia) {
		Dia dia = null;
		Connection con = KetNoiDB.getConnection();
		try {
			CallableStatement call = con.prepareCall("{call dia_timDiaTheoMa(?)}");
			call.setString(1, madia);
			
			ResultSet res = call.executeQuery();
			while(res.next()) {
				String trangthai = res.getString(2);
				String matua = res.getString(3);
				String tentua = res.getString(4);
				int maloaidia = res.getInt(5);
				String tenloaidia = res.getString(6);
				double giathue = res.getFloat(7);
				int hanthue = res.getInt(8);
				double phitrehan = res.getDouble(9);
				String mota = res.getString(10);
				String anh = res.getString(11);
				
				LoaiDia ld = new LoaiDia(maloaidia, tenloaidia, giathue, hanthue);
				TuaDia td = new TuaDia(matua, tentua, ld, phitrehan, mota, anh);
				dia = new Dia(madia, trangthai, td);
			}
		} catch (SQLException e) {
			e.printStackTrace();
		}
		return dia;
	}
	
	
	
	public List<Dia> getAllDiaByMaTua(TuaDia tua){
		List<Dia>list = new ArrayList<Dia>();
		PreparedStatement stm;
		try {
			Connection con = KetNoiDB.getConnection();
			stm = con.prepareStatement("Select * from Dia where matua = ?");
			stm.setString(1, tua.getMatua());
			ResultSet rs = stm.executeQuery();
			
			while(rs.next()) {
				String madia = rs.getString(1);
				String trangthai = rs.getString(2);
				
				Dia d = new Dia(madia, trangthai, tua);
				list.add(d);
			}
		} catch (SQLException e) {
			e.printStackTrace();
		}
		
		return list;
		
	}
	
	public boolean themDia(Dia dia) {
		try {
			Connection con = KetNoiDB.getConnection();
			PreparedStatement ps = con.prepareStatement("Insert into Dia values (?,?,?)");
			ps.setString(1, dia.getMadia());
			ps.setString(2, dia.getTrangthai());
			ps.setString(3, dia.getTuadia().getMatua());
			ps.execute();
			return true;
		} catch (SQLException e) {
			return false;
		}
	}
	
	public boolean xoaDia(String madia) {
		String existsql = "Select count(*) as madia from PhieuTra Where madia ='"+madia+"'";
		Connection con = KetNoiDB.getConnection();
		try {
			PreparedStatement ps = con.prepareStatement(existsql);
			ResultSet rs = ps.executeQuery();
			rs.next();
			int count = rs.getInt("madia");
			if(count > 0)
			{
				String sql ="update Dia set trangthai = 'D' where madia = ?";
				PreparedStatement ps1 = con.prepareStatement(sql);
				ps1.setString(1, madia);
				ps1.execute();
				return true;
			}
			else
			{
				String sql ="delete from Dia where madia ='"+madia+"'";
				PreparedStatement ps1 = con.prepareStatement(sql);
				ps1.executeUpdate();
				return true;
			}
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return false;
	}
	
	public Dia getDiaByID(String maDia) {
		try {
			Connection con = KetNoiDB.getConnection();
			PreparedStatement ps = con.prepareStatement("Select * from Dia where MaDia = ?");
			ps.setString(1, maDia);
			ResultSet rs = ps.executeQuery();
			while(rs.next()) {
				String madia = rs.getString(1);
				String trangthai = rs.getString(2);
				String matua = rs.getString(3);
				TuaDiaControl tuadiacontrol = new TuaDiaControl();

				TuaDia td = tuadiacontrol.getTuaByID(matua);
				Dia dia = new Dia(madia, trangthai, td);
				return dia;
			}
		} catch (SQLException e) {
			e.printStackTrace();
		}
		return null;
	}
	
	public ArrayList<Dia> showAllDia(){
		ArrayList<Dia>list = new ArrayList<Dia>();
		Connection con = KetNoiDB.getConnection();
		try {
			PreparedStatement ps = con.prepareStatement("{call dia_getAll}");
			ResultSet rs = ps.executeQuery();
			
			while(rs.next()) {
				String madia = rs.getString(1);
				String trangthai = rs.getString(2);
				String matua = rs.getString(3);
				
				
				TuaDia td = tuaDiaControl.getTuaByID(matua);
				Dia dia = new Dia(madia, trangthai, td);
				if(!dia.getTrangthai().equals("D")) // Không lấy những đĩa đã bị xóa
					list.add(dia);
			}
		}
		catch(SQLException e) {
			e.printStackTrace();
		}
		return list;
	}
	
	/**
	 * kết nối với CSDL để so khớp mã đĩa
	 * @param ttTim
	 * @return
	 */
	public ArrayList<Dia> soKhopMaDia(String ma) {
		ArrayList<Dia> array = new ArrayList<>();
		Connection con = KetNoiDB.getConnection();
		try {
			CallableStatement call = con.prepareCall("{call dia_SoKhopMaDia(?)}");
			call.setString(1, ma);
			
			ResultSet res = call.executeQuery();
			while(res.next()) {
				String madia = res.getString(1);
				String trangthai = res.getString(2);
				String matua = res.getString(3);
				String tentua = res.getString(4);
				int maloaidia = res.getInt(5);
				String tenloaidia = res.getString(6);
				double giathue = res.getFloat(7);
				int hanthue = res.getInt(8);
				double phitrehan = res.getDouble(9);
				String mota = res.getString(10);
				String anh = res.getString(11);
				
				LoaiDia ld = new LoaiDia(maloaidia, tenloaidia, giathue, hanthue);
				TuaDia td = new TuaDia(matua, tentua, ld, phitrehan, mota, anh);
				Dia d = new Dia(madia, trangthai, td);
				array.add(d);
			}
		} catch (SQLException e) {
			e.printStackTrace();
		}
		return array;
	}
}
