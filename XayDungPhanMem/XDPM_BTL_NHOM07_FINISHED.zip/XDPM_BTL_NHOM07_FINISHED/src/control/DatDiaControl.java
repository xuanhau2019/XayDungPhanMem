package control;

import java.sql.CallableStatement;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;

import dal.KetNoiDB;
import entities.DatDia;
import entities.Dia;
import entities.KhachHang;
import entities.LoaiDia;
import entities.TuaDia;

public class DatDiaControl {
	
	public ArrayList<DatDia> listDatDia;
	
	SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd hh:mm:ss");
	
	public DatDiaControl() {
		listDatDia = new ArrayList<>();
	}

	public ArrayList<DatDia> getAllKhachHangDatDia() {
		ArrayList<DatDia> list = new ArrayList<>();
		Connection con = KetNoiDB.getConnection();
		try {
			PreparedStatement stm = con.prepareStatement("Select * From DatDia");

			KhachHangControl khCon = new KhachHangControl();
			TuaDiaControl tuaControl = new TuaDiaControl();
			DiaControl diaControl = new DiaControl();
			DatDia datdia;
			TuaDia tuadia;
			KhachHang kh;
			Dia dia = null;
			
			ResultSet res = stm.executeQuery();
			while(res.next()) {
				kh = khCon.timKhachHangTheoID(res.getString(1));
				tuadia = tuaControl.getTuaByID(res.getString(2));
				String madia = res.getString(4);
				if(madia != null)
					dia = diaControl.getDiaByID(madia);
				else
					dia = null;
					
				datdia = new DatDia(kh, tuadia, res.getDate(3), dia);
				list.add(datdia);
			}
		} catch (SQLException e) {
			e.printStackTrace();
		}
		return list;
	}
	
	/**
	 * Kết nối với CSDL để lấy khách hàng đặt đĩa sớm nhất
	 * @param ttTim
	 * @return
	 */
	public DatDia getKhachHangDatDiaDauTien(String ttTim) {
		DatDia dd = null;
		Connection con = KetNoiDB.getConnection();
		try {
			CallableStatement call = con.prepareCall("{call datdia_getNguoiDauTien(?)}");
			call.setString(1, ttTim);
			
			KhachHangControl khcon = new KhachHangControl();
			
			ResultSet res = call.executeQuery();
			while(res.next()) {
				String idkh = res.getString(1);
				Date ngaydat = res.getDate(2);
				String matua = res.getString(3);
				String tentua = res.getString(4);
				int maloaidia = res.getInt(5);
				String tenloaidia = res.getString(6);
				double giathue = res.getFloat(7);
				int hanthue = res.getInt(8);
				double phitrehan = res.getDouble(9);
				String mota = res.getString(10);
				String anh = res.getString(11);
				
				KhachHang kh = khcon.timKhachHangTheoID(idkh);
				LoaiDia ld = new LoaiDia(maloaidia, tenloaidia, giathue, hanthue);
				TuaDia td = new TuaDia(matua, tentua, ld, phitrehan, mota, anh);
				dd = new DatDia(kh, td, ngaydat, null);
			}
		} catch (SQLException e) {
			e.printStackTrace();
		}
		return dd;
	}

	/**
	 * Kết nối CSDL và lưu đặt đĩa của khách hàng
	 * @param datdia
	 * @return
	 */
	public boolean themDatDia(DatDia datdia) {
		int n = 0;
		Connection con = KetNoiDB.getConnection();
		try {
			CallableStatement call = con.prepareCall("{call datdia_Them(?,?,?,?)}");
			call.setString(1, datdia.getKh().getIdkh());
			call.setString(2, datdia.getTuadia().getMatua());
			call.setString(3, sdf.format(datdia.getNgaydat()));
			if(datdia.getGanDia() == null)
				call.setString(4, null);
			else
				call.setString(4, datdia.getGanDia().getMadia());
			
			n = call.executeUpdate();
		} catch (SQLException e) {
			e.printStackTrace();
		}
		return n > 0;
	}
	
	/**
	 * Kết nối CSDL và gán đĩa cho khách hàng đặt trước
	 * @param datdia
	 * @return
	 */
	public boolean ganDiaChoKhachHang(DatDia datdia) {
		int n = 0;
		Connection con = KetNoiDB.getConnection();
		try {
			CallableStatement call = con.prepareCall("{call datdia_GanDia(?,?,?)}");
			call.setString(1, datdia.getKh().getIdkh());
			call.setString(2, datdia.getTuadia().getMatua());
			call.setString(3, datdia.getGanDia().getMadia());
			n = call.executeUpdate();
		} catch (SQLException e) {
			e.printStackTrace();
		}
		return n > 0;
	}
	
	/**
	 * Kết nối CSDL và tìm đĩa đã gán cho khách hàng
	 * @param kh
	 * @param dia
	 * @return
	 */
	public DatDia timDiaKhachHangDaDat(KhachHang kh, Dia dia) {
		Connection con = KetNoiDB.getConnection();
		try {
			CallableStatement call = con.prepareCall("{call datdia_TimDiaKhachHangDaDat(?,?)}");
			call.setString(1, kh.getIdkh());
			call.setString(2, dia.getMadia());
			
			ResultSet res = call.executeQuery();
			while(res.next()) {
				Date ngaydat = res.getDate(3);
				return new DatDia(kh, dia.getTuadia(), ngaydat, dia);
			}
		} catch (SQLException e) {
			e.printStackTrace();
		}
		return null;
	}
	
	public boolean kiemtraTuaDat(String idkh, String matua) {
		Connection con = KetNoiDB.getConnection();
		try {
			CallableStatement call = con.prepareCall("{call datdia_KiemTraTuaDat(?,?)}");
			call.setString(1, idkh);
			call.setString(2, matua);
			ResultSet res = call.executeQuery();
			while(res.next()) {
				int kiemtra = res.getInt(1);
				if(kiemtra != 0)
					return true;
			}
		} catch (SQLException e) {
			e.printStackTrace();
		}
		return false;
	}
	
	/**
	 * Kết nối CSDL để xóa đặt đĩa của khách
	 * @param idkh
	 * @param matua
	 * @return
	 */
	public boolean xoaDatDia(String idkh, String matua) {
		int n = 0;
		Connection con = KetNoiDB.getConnection();
		try {
			CallableStatement call = con.prepareCall("{call datdia_Xoa(?,?)}");
			call.setString(1, idkh);
			call.setString(2, matua);
			
			n = call.executeUpdate();
		} catch (SQLException e) {
			e.printStackTrace();
		}
		return n > 0;
	}
	
	public ArrayList<DatDia> timKhachHangDaDatDia(KhachHang kh) {
		ArrayList<DatDia> list = new ArrayList<>();
		Connection con = KetNoiDB.getConnection();
		try {
			CallableStatement call = con.prepareCall("{call datdia_TimKhachHangDaDatDia(?)}");
			call.setString(1, kh.getIdkh());
			
			TuaDiaControl tuaControl = new TuaDiaControl();
			DiaControl diaControl = new DiaControl();
			DatDia datdia;
			TuaDia tuadia;
			Dia dia = null;
			
			ResultSet res = call.executeQuery();
			while(res.next()) {
				tuadia = tuaControl.getTuaByID(res.getString(2));
				String madia = res.getString(4);
				if(madia != null)
					dia = diaControl.getDiaByID(madia);
				else
					dia = null;
					
				datdia = new DatDia(kh, tuadia, res.getDate(3), dia);
				list.add(datdia);
			}
		} catch (SQLException e) {
			e.printStackTrace();
		}
		return list;
	}
}
