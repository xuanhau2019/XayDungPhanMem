package control;

import java.sql.CallableStatement;
import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;

import dal.KetNoiDB;
import entities.ChiTietPhieuThue;
import entities.Dia;
import entities.KhachHang;
import entities.PhieuThue;

public class PhieuThueControl {
	
	public ArrayList<PhieuThue> listPhieuThue;
	public ArrayList<ChiTietPhieuThue> listCTPT;
	
	SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd");
	
	public PhieuThueControl() {
		listPhieuThue = new ArrayList<>();
		listCTPT = new ArrayList<>();
	}
	
	/**
	 * kết nối với CSDL và lấy mã phiếu thiêu cuối cùng
	 */
	public String getLastMaPhieuThue() {
		Connection con = KetNoiDB.getConnection();
		String ma = null;
		try {
			CallableStatement call = con.prepareCall("{call phieuthue_GetLastMaPT}");
			ResultSet res = call.executeQuery();
			while(res.next()) {
				ma = res.getString(1);
			}
		} catch (SQLException e) {
			e.printStackTrace();
		}
		return ma;
	}
	
	/**
	 * Kết nối CSDL và thêm phiếu thuê
	 * @param pt
	 * @return
	 */
	public boolean themPhieuThue(PhieuThue pt) {
		Connection con = KetNoiDB.getConnection();
		int n = 0;
		try {
			CallableStatement call = con.prepareCall("{call phieuthue_Them(?,?,?)}");
			call.setString(1, pt.getMaphieuthue());
			call.setString(2, sdf.format(pt.getNgaythue()));
			call.setString(3, pt.getKh().getIdkh());
			n = call.executeUpdate();
		} catch (SQLException e) {
			e.printStackTrace();
		}
		return n > 0;
	}
	
	/**
	 * Kết nối CSDL và thêm chi tiết phiếu thuê
	 * @param ctpt
	 * @return
	 */
	public boolean themChiTietPhieuThue(ChiTietPhieuThue ctpt) {
		Connection con = KetNoiDB.getConnection();
		int n = 0;
		try {
			CallableStatement call = con.prepareCall("{call chitietPhieuThue_Them(?,?,?,?,?,?)}");
			call.setString(1, ctpt.getPhieuthue().getMaphieuthue());
			call.setString(2, ctpt.getDia().getMadia());
			call.setDouble(3, ctpt.getPhitrehan());
			call.setInt(4, ctpt.getHantradia());
			call.setDouble(5, ctpt.getGiathue());
			call.setString(6, ctpt.getTrangthai());
			n = call.executeUpdate();
		} catch (SQLException e) {
			e.printStackTrace();
		}
		return n > 0;
	}
	
	/**
	 * kết nối với CSDL để tìm phiếu thuê
	 * @param mapt
	 * @return
	 */
	public PhieuThue timPhieuThueTheoMaPT(String mapt) {
		PhieuThue pt = null;
		Connection con = KetNoiDB.getConnection();
		try {
			CallableStatement call = con.prepareCall("{call phieuthue_TimMaPT(?)}");
			call.setString(1, mapt);
			ResultSet res = call.executeQuery();
			while(res.next()) {
				String maphieuthue = res.getString(1);
				Date ngaythue = res.getDate(2);
				String idkh = res.getString(3);
				String tenkh = res.getString(4);
				String sodt = res.getString(5);
				String diachi = res.getString(6);
				KhachHang kh = new KhachHang(idkh, tenkh, sodt, diachi);
				pt = new PhieuThue(maphieuthue, kh, ngaythue);
			}
		} catch (SQLException e) {
			e.printStackTrace();
		}
		return pt;
	}
	
	/**
	 * kết nối với CSDL để tìm phiếu thuê của khách hàng có ngày thuê là NULL -> đây là phiếu tạm dùng để gán đĩa cho khách hàng
	 * @param mapt
	 * @return
	 */
//	public PhieuThue timPhieuThueCoNgayIsNULL(KhachHang kh) {
//		PhieuThue pt = null;
//		Connection con = KetNoiDB.getConnection();
//		try {
//			CallableStatement call = con.prepareCall("{call phieuthue_TimPhieuThueCoNgayNULL(?)}");
//			call.setString(1, kh.getIdkh());
//			ResultSet res = call.executeQuery();
//			while(res.next()) {
//				String maphieuthue = res.getString(1);
//				Date ngaythue = res.getDate(2);
//				String idnv = res.getString(4);
//				NhanVienControl nvCon = new NhanVienControl();
//				NhanVien nv = nvCon.timNhanVien(idnv).get(0);
//				pt = new PhieuThue(maphieuthue, kh, nv, ngaythue);
//			}
//		} catch (SQLException e) {
//			e.printStackTrace();
//		}
//		return pt;
//	}
	
	/**
	 * kết nối với CSDL để tìm chi tiết phiếu thuê
	 * 	=> Nếu madia == NULL thì sẽ tìm danh sach chi tiết của phiếu thuê theo maphieuthue
	 * 	=> Ngược lại nếu phieuthue == NULL thì tìm chi tiết phiếu thuê theo mã đĩa nhưng chưa trả.
	 * 	=> Ngược lại thì sẽ tìm chi tiết phiếu thuê theo ma phiếu thuê và đĩa
	 * @param pt
	 * @param madia
	 * @return
	 */
	public ArrayList<ChiTietPhieuThue> timChiTietPhieuThue(PhieuThue pt, Dia dia) {
		ArrayList<ChiTietPhieuThue> array = new ArrayList<>();
		Connection con = KetNoiDB.getConnection();
		DiaControl diacon = new DiaControl();
		try {
			CallableStatement call = con.prepareCall("{call chitietPhieuThue_Tim(?,?)}");
			if(pt != null)
				call.setString(1, pt.getMaphieuthue());
			else {
				call.setString(1, null);
				pt = new PhieuThue();		// chuyển phiếu thuê từ null sang tạo mới đối tượng
			}
			if(dia != null)
				call.setString(2, dia.getMadia());
			else
				call.setString(2, null);

			ResultSet res = call.executeQuery();
			while(res.next()) {
				String madia = res.getString(2);
				dia = diacon.timThongTinDia(madia).get(0);
				double phitrehan = res.getDouble(3);
				int hantradia = res.getInt(4);
				double giathue = res.getDouble(5);
				String trangthai = res.getString(6);

				pt.setMaphieuthue(res.getString(1));
				ChiTietPhieuThue ctpt = new ChiTietPhieuThue(pt, dia, phitrehan, hantradia, giathue, trangthai);
				array.add(ctpt);
			}
		} catch (SQLException e) {
			e.printStackTrace();
		}
		return array;
	}

	/**
	 *  Kết nối CSDL để cập nhật lại phiếu thuê
	 * @param pt
	 * @return
	 */
	public boolean capnhatPhieuThue(PhieuThue pt) {
		int n = 0;
		Connection con = KetNoiDB.getConnection();
		try {
			CallableStatement call = con.prepareCall("{call phieuthue_CapNhat(?,?,?)}");
			call.setString(1, pt.getMaphieuthue());
			if(pt.getNgaythue() != null)
				call.setString(2, sdf.format(pt.getNgaythue()));
			else
				call.setString(2, null);
			call.setString(3, pt.getKh().getIdkh());
			n = call.executeUpdate();
		} catch (SQLException e) {
			e.printStackTrace();
		}
		return n > 0;
	}
	
	/**
	 * Kết nối CSDL để cập nhật trạng thái của chi tiết phiếu thuê
	 * @param ctpt
	 * @return
	 */
	public boolean capnhatChiTietPhieuThue(PhieuThue pt, Dia dia, String trangthai) {
		int n = 0;
		Connection con = KetNoiDB.getConnection();
		try {
			CallableStatement call = con.prepareCall("{call chitietPhieuThue_CapNhat(?,?,?)}");
			call.setString(1, pt.getMaphieuthue());
			call.setString(2, dia.getMadia());
			call.setString(3, trangthai);
			n = call.executeUpdate();
		} catch (SQLException e) {
			e.printStackTrace();
		}
		return n > 0;
	}
	
	/**
	 * Kết nối CSDL để xóa phiếu thuê
	 * @param mapt
	 * @return
	 */
//	public boolean xoaPhieuThue(String mapt) {
//		int n = 0;
//		Connection con = KetNoiDB.getConnection();
//		try {
//			CallableStatement call = con.prepareCall("{call phieuthue_Xoa(?)}");
//			call.setString(1, mapt);
//			n = call.executeUpdate();
//		} catch (SQLException e) {
//			e.printStackTrace();
//		}
//		return n > 0;
//	}
	
	/**
	 * Kết nối CSDL để xóa chi tiết phiếu thuê
	 * @param mapt
	 * @param madia
	 * @return
	 */
//	public boolean xoaChiTietPhieuThue(String mapt, String madia) {
//		int n = 0;
//		Connection con = KetNoiDB.getConnection();
//		try {
//			CallableStatement call = con.prepareCall("{call chitietPhieuThue_Xoa(?,?)}");
//			call.setString(1, mapt);
//			call.setString(2, madia);
//			n = call.executeUpdate();
//		} catch (SQLException e) {
//			e.printStackTrace();
//		}
//		return n > 0;
//	}
}
