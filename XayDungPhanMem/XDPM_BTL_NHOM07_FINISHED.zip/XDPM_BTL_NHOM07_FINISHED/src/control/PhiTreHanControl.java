package control;

import java.sql.CallableStatement;
import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;

import dal.KetNoiDB;
import entities.PhiTreHan;
import entities.PhieuTra;

public class PhiTreHanControl {
	
public ArrayList<PhiTreHan> listTreHan;
	
	public PhiTreHanControl() {
		listTreHan = new ArrayList<>();
	}
	
	/**
	 * kết nối với CSDL và lấy mã phí trễ hạn cuối cùng
	 */
	public String getLastMaPhiTreHan() {
		Connection con = KetNoiDB.getConnection();
		String ma = null;
		try {
			CallableStatement call = con.prepareCall("{call phitrehan_GetLastMaPTreHan}");
			ResultSet res = call.executeQuery();
			while(res.next()) {
				ma = res.getString(1);
			}
		} catch (SQLException e) {
			e.printStackTrace();
		}
		return ma;
	}
	
	public ArrayList<PhiTreHan> layTatCaPhiTreHan() {
		ArrayList<PhiTreHan> array = new ArrayList<>();
		Connection con = KetNoiDB.getConnection();
		try {
			CallableStatement call = con.prepareCall("{call phitrehan_layTatCa}");

			ResultSet res = call.executeQuery();
			while (res.next()) {
				String matrehan = res.getString(1);
				Double tienno = res.getDouble(2);
				String maphieutra = res.getString(3);
				
				PhieuTraControl ptraCon = new PhieuTraControl();			
				PhieuTra phieutra = ptraCon.timPhieuTraTheoMaPT(maphieutra);
				PhiTreHan pth = new PhiTreHan(matrehan, phieutra, tienno);
				array.add(pth);
			}
		} catch (SQLException e) {
			e.printStackTrace();
		}
		return array;
	}
	
	/**
	 * kết nối với CSDL để lấy ra phí trể hạn theo khách hàng
	 * @param idkh
	 * @return
	 */
	public ArrayList<PhiTreHan> layPhiTreHanCuaKhachHang(String idkh) {
		ArrayList<PhiTreHan> array = new ArrayList<>();
		Connection con = KetNoiDB.getConnection();
		try {
			CallableStatement call = con.prepareCall("{call phitrehan_layDanhSachNoKH(?)}");
			call.setString(1, idkh);
			ResultSet res = call.executeQuery();
			while (res.next()) {
				String matrehan = res.getString(1);
				Double tienno = res.getDouble(2);
				String maphieutra = res.getString(3);
				
				PhieuTraControl ptraCon = new PhieuTraControl();			
				PhieuTra phieutra = ptraCon.timPhieuTraTheoMaPT(maphieutra);
				PhiTreHan pth = new PhiTreHan(matrehan, phieutra, tienno);
				array.add(pth);
			}
		} catch (SQLException e) {
			e.printStackTrace();
		}
		return array;
	}

	public boolean themPhiTreHan(PhiTreHan ptrehan) {
		Connection con = KetNoiDB.getConnection();
		int n = 0;
		try {
			CallableStatement call = con.prepareCall("{call phitrehan_Them(?,?,?)}");
			call.setString(1, ptrehan.getMatrehan());
			call.setString(2, ptrehan.getPhieutra().getMaphieutra());
			call.setDouble(3, ptrehan.getTienno());
			
			n = call.executeUpdate();
		} catch (SQLException e) {
			e.printStackTrace();
		}
		return n > 0;
	}
	
	/**
	 * kết nối với CSDL để tìm phí trể hạn
	 * @param matrehan
	 * @return
	 */
	public PhiTreHan timPhiTreHan(String matrehan) {
		PhiTreHan ptre = null;
		Connection con = KetNoiDB.getConnection();
		try {
			CallableStatement call = con.prepareCall("{call phitrehan_TimPhiTreHan(?)}");
			call.setString(1, matrehan);
			ResultSet res = call.executeQuery();
			while (res.next()) {
				String maphieutra = res.getString(2);
				Double tienno = res.getDouble(3);
				
				PhieuTraControl ptraCon = new PhieuTraControl();			
				PhieuTra phieutra = ptraCon.timPhieuTraTheoMaPT(maphieutra);
				ptre = new PhiTreHan(matrehan, phieutra, tienno);
			}
		} catch (SQLException e) {
			e.printStackTrace();
		}
		return ptre;
	}
	
	public boolean xoaPhiTreHanChoKhachHang(String maTreHan) {
		int n = 0;
		Connection con = KetNoiDB.getConnection();
		try {
			CallableStatement call = con.prepareCall("{call phitrehan_XoaTreHanChoKhachHang(?)}");
			call.setString(1, maTreHan);
			
			n = call.executeUpdate();
		} catch (SQLException e) {
			e.printStackTrace();
		}
		return n > 0;
	}
}
