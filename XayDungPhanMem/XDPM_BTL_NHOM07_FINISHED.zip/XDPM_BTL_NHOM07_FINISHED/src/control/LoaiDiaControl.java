package control;

import java.sql.CallableStatement;
import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;

import dal.KetNoiDB;
import entities.LoaiDia;

public class LoaiDiaControl {
	
public ArrayList<LoaiDia> listLoaiDia;
	
	public LoaiDiaControl() {
		listLoaiDia = new ArrayList<>();
	}

	public LoaiDia getLoaiDiaTheoMa(int maloai) {
		Connection con = KetNoiDB.getConnection();
		try {
			CallableStatement call = con.prepareCall("{call loaidia_LayThongTinTheoMa(?)}");
			call.setInt(1, maloai);
			ResultSet res = call.executeQuery();
			while(res.next()) {
				String tenloaidia = res.getString(2);
				double giathue = res.getDouble(3);
				int hanthue = res.getInt(4);
				return new LoaiDia(maloai, tenloaidia, giathue, hanthue);
			}
		} catch (SQLException e) {
			e.printStackTrace();
		}
		return null;
	}

	public ArrayList<LoaiDia> getAllLoaiDia() {
		Connection con = KetNoiDB.getConnection();
		ArrayList<LoaiDia> array = new ArrayList<>();
		try {
			CallableStatement call = con.prepareCall("{call loaidia_LayThongTin}");
			ResultSet res = call.executeQuery();
			while(res.next()) {
				int maloai = res.getInt(1);
				String tenloaidia = res.getString(2);
				double giathue = res.getDouble(3);
				int hanthue = res.getInt(4);
				LoaiDia ld = new LoaiDia(maloai, tenloaidia, giathue, hanthue);
				
				array.add(ld);
			}
		} catch (SQLException e) {
			e.printStackTrace();
		}
		return array;
	}

	public boolean capnhatLoaiDia(LoaiDia ld) {
		Connection con = KetNoiDB.getConnection();
		int n = 0;
		try {
			CallableStatement call = con.prepareCall("{call loaidia_capnhat(?,?,?)}");
			call.setString(1, ld.getTenloaidia());
			call.setDouble(2, ld.getGiathue());
			call.setInt(3, ld.getHanthue());
			n = call.executeUpdate();
		} catch (SQLException e) {
			e.printStackTrace();
		}
		return n > 0;
	}
}
