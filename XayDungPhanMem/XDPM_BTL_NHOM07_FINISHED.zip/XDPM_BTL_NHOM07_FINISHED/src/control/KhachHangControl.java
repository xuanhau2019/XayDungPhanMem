package control;

import java.sql.CallableStatement;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;

import dal.KetNoiDB;
import entities.KhachHang;

public class KhachHangControl {
	
	public ArrayList<KhachHang> listKH;
	
	public KhachHangControl() {
		listKH = new ArrayList<>();
	}
	
	/**
	 * kết nối với CSDL và lấy thông tin khách hàng
	 */
	public void layThongTinKhachHang() {
		Connection con = KetNoiDB.getConnection();
		String sql = "Select * from KhachHang";
		try {
			PreparedStatement ps = con.prepareStatement(sql);
			//CallableStatement call = con.prepareCall("{call khachhang_layThongTin}");
			ResultSet res = ps.executeQuery();

			while(res.next()) {
				String idkh = res.getString(1);
				String tenkh = res.getString(2);
				String sodt = res.getString(3);
				String diachi = res.getString(4);
				
				KhachHang kh = new KhachHang(idkh, tenkh, sodt, diachi);
				listKH.add(kh);
			}
		} catch (SQLException e) {
			e.printStackTrace();
		}
	}
	
	/**
	 * Tìm thông tin của khách hàng
	 * @param ttTim
	 * @return
	 */
	public ArrayList<KhachHang> timKhachHang(String ttTim) {
		ArrayList<KhachHang> array = new ArrayList<>();
		Connection con = KetNoiDB.getConnection();
		try {
			CallableStatement call = con.prepareCall("{call khachhang_TimThongTin(?)}");
			call.setString(1, ttTim);
			
			ResultSet res = call.executeQuery();
			while(res.next()) {
				String idkh = res.getString(1);
				String tenkh = res.getString(2);
				String sodt = res.getString(3);
				String diachi = res.getString(4);
				
				KhachHang kh = new KhachHang(idkh, tenkh, sodt, diachi);
				array.add(kh);
			}
		} catch (SQLException e) {
			e.printStackTrace();
		}
		return array;
	}

	public KhachHang timKhachHangTheoID(String idkh) {

		Connection con = KetNoiDB.getConnection();
		try {
			CallableStatement call = con.prepareCall("{call khachhang_TimTheoSoID(?)}");
			call.setString(1, idkh);
			
			ResultSet res = call.executeQuery();
			while(res.next()) {
				String tenkh = res.getString(2);
				String sodt = res.getString(3);
				String diachi = res.getString(4);
				
				return new KhachHang(idkh, tenkh, sodt, diachi);
			}
		} catch (SQLException e) {
			e.printStackTrace();
		}
		
		return null;
	}
	public boolean themKH(KhachHang kh) {
		String sql = "Insert into KhachHang values(?,?,?,?)";
		Connection con = KetNoiDB.getConnection();
		try {
			PreparedStatement ps = con.prepareStatement(sql);
			ps.setString(1, kh.getIdkh());
			ps.setNString(2, kh.getTenkh());
			ps.setString(3, kh.getSodt());
			ps.setNString(4, kh.getDiachi());
			ps.executeUpdate();
			return true;
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return false;
	}
	public boolean suaKH(KhachHang kh)
	{
		Connection con = KetNoiDB.getConnection();
		String sql = "Update KhachHang set tenkh=?,sodt=?,diachi=? where idkh=?";
		try {
			PreparedStatement ps = con.prepareStatement(sql);
			ps.setNString(1, kh.getTenkh());
			ps.setString(2, kh.getSodt());
			ps.setNString(3, kh.getDiachi());
			ps.setString(4, kh.getIdkh());
			ps.execute();
			return true;
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return false;
	}
	public KhachHang layKHByID(String maKH)
	{
		Connection con = KetNoiDB.getConnection();
		String sql = "Select * From KhachHang Where idkh=?";
		try {
			PreparedStatement ps = con.prepareStatement(sql);
			ps.setString(1, maKH);
			ResultSet rs = ps.executeQuery();
			while(rs.next())
			{
				String idkh = rs.getString(1);
				String tenkh = rs.getNString(2);
				String sodt = rs.getString(3);
				String diachi = rs.getNString(4);
				KhachHang kh = new KhachHang(idkh,tenkh,sodt,diachi);
				return kh;
			}
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return null;
	}
	
	public String getMaKHMAX() {
		String sql = "select Max(idkh) from KhachHang";
		Connection con = KetNoiDB.getConnection();
		PreparedStatement ps;
		try {
			ps = con.prepareStatement(sql);
			ResultSet rs = ps.executeQuery();
			while(rs.next())
			{
				return rs.getString(1);
			}
		} catch (SQLException e) {
			e.printStackTrace();
		}
		return null;
	}
	
	public boolean xoaKH(String maKH)
	{
		String existsql = "Select count(*) as idkh from PhieuThue Where idkh='"+maKH+"'";
		Connection con = KetNoiDB.getConnection();
		try {
			PreparedStatement ps = con.prepareStatement(existsql);
			ResultSet rs = ps.executeQuery();
			rs.next();
			int count = rs.getInt("idkh");
			if(count > 0)
			{
				return false;
			}
			else
			{
				String sql ="delete from KhachHang where idkh='"+maKH+"'";
				PreparedStatement ps1 = con.prepareStatement(sql);
				ps1.executeUpdate();
				return true;
			}
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return false;
	}
	public ArrayList<KhachHang> layDanhSachKhachHang() {
		listKH.clear();
		layThongTinKhachHang();		
		return listKH;
	}
}
