package control;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;

import dal.KetNoiDB;
import entities.TaiKhoan;

/**
 * 
 * @author Trường Giang
 *
 */
public class TaiKhoanControl {
	
	public ArrayList<TaiKhoan> listTaiKhoan;
	
	public TaiKhoanControl() {
		listTaiKhoan = new ArrayList<>();
	}

	public TaiKhoan dangNhap(String user, String pass) {
		Connection con = KetNoiDB.getConnection();
		try {
			PreparedStatement stm = con.prepareStatement("Select * from TaiKhoan where madn = ? and matkhau = ?");
			stm.setString(1, user);
			stm.setString(2, pass);
			ResultSet rs = stm.executeQuery();
			while(rs.next()) {
				TaiKhoan tk = new TaiKhoan(rs.getString(1), rs.getString(2));
				return tk;
			}
		} catch (SQLException e) {
			e.printStackTrace();
		}
		return null;
	}
}
