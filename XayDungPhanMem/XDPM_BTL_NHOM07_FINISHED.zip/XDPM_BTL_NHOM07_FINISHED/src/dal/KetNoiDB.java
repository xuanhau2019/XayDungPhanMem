package dal;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;

public class KetNoiDB {
	public static Connection con = null;
	private static KetNoiDB instance = new KetNoiDB();
	
	public static KetNoiDB getInstance() {
		return instance;
	}
	
	public void connect() {
		String sql = "jdbc:sqlserver://localhost:1433;databasename = XDPM_DHKTPM12A_BTL_NHOM07";
		try {
			Class.forName("com.microsoft.sqlserver.jdbc.SQLServerDriver");
			con = DriverManager.getConnection(sql, "sa", "123");
		} catch (SQLException e) {
			e.printStackTrace();
		} catch (ClassNotFoundException e) {
			e.printStackTrace();
		}
	}
	
	public void disconnect() {
		if(con != null) {
			try {
				con.close();
			} catch (SQLException e) {
				e.printStackTrace();
			}
		}
	}
	
	public static Connection getConnection() {
		return con;
	}
}
