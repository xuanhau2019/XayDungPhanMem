package main;

import java.awt.EventQueue;

import javax.swing.UIManager;

import dal.KetNoiDB;
import gui.GUIChinh;


public class Main {

	public static void main(String[] args) {
			EventQueue.invokeLater(new Runnable() {
				public void run() {
					try {
						UIManager.setLookAndFeel(UIManager.getSystemLookAndFeelClassName());
						KetNoiDB.getInstance().connect();
						
						new GUIChinh().setVisible(true);
					} catch (Exception e) {
						e.printStackTrace();
					}
				}
			});
	}

}
