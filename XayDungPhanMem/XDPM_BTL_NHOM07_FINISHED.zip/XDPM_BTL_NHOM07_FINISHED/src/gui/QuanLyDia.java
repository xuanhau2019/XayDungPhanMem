package gui;

import java.awt.Color;
import java.awt.Component;
import java.awt.Cursor;
import java.awt.Font;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.FocusEvent;
import java.awt.event.FocusListener;
import java.awt.event.KeyEvent;
import java.awt.event.KeyListener;
import java.awt.event.MouseEvent;
import java.util.ArrayList;

import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.JScrollPane;
import javax.swing.JTable;
import javax.swing.JTextField;
import javax.swing.ListSelectionModel;
import javax.swing.table.DefaultTableModel;
import javax.swing.table.JTableHeader;
import javax.swing.table.TableCellRenderer;

import control.DiaControl;
import entities.Dia;
import entities.TuaDia;

@SuppressWarnings("serial")
public class QuanLyDia extends JPanel implements ActionListener,KeyListener,FocusListener {

	
	private JTable table;
	private DefaultTableModel tableModel;
	private JButton btnThemDia;
	private JTextField textField;
	private JLabel lblTitle;
	private JButton btnXoa;
	private ThemDiaDL themDiaDL;
	private JFrame parent;
	
	TuaDia tua = new TuaDia();
	DiaControl diacontrol = new DiaControl();
	ArrayList<Dia> listdia = new ArrayList<>();
	
	public QuanLyDia() {
		JPanel panel = new JPanel();
		panel.setBounds(0, 0, 1200, 788);
		setBounds(0, 0, 1200, 788);
		setLayout(null);
		add(panel);
		panel.setLayout(null);
		
		JPanel pnTitle = new JPanel();
		pnTitle.setBounds(0, 0, 1200, 30);
		pnTitle.setBackground(Color.CYAN);
		
		lblTitle = new JLabel("Quản lý Đĩa");
		lblTitle.setFont(new Font("Segoe UI", Font.BOLD, 18));
		
		pnTitle.add(lblTitle);
		
		panel.add(pnTitle);
		
		JScrollPane scrollPane = new JScrollPane();
		scrollPane.setBounds(10, 162, 1180, 615);
		panel.add(scrollPane);
		
		table = new JTable() {
			public Component prepareRenderer( TableCellRenderer renderer, int row, int col ) {
		        Component c = super.prepareRenderer(renderer, row, col);
		        if ( row % 2 == 0 && !isCellSelected(row, col)) {
		            c.setBackground( Color.decode("#F1F1F1") );
		        }
		        else 
		        	if(!isCellSelected(row, col)){
		        		c.setBackground( Color.decode("#D7F1FF") );
		        	}else {
		        		c.setBackground(Color.decode("#25C883"));
		        	}		        
		        return c;
		    }
			
		};
		table.setBorder(null);
		table.setFillsViewportHeight(true);
		table.setShowGrid(false);
		
		JTableHeader header = table.getTableHeader();
		header.setBackground(Color.decode("#007ECA"));
		header.setForeground(Color.white);
		header.setOpaque(false);
		
		table.setModel(tableModel = new DefaultTableModel(
			new Object[][] {
		
			},
			new String[] {
					"Mã đĩa", "trạng thái", "Tựa đĩa"
			}
		){
			boolean[] columnEditables = new boolean[] {
					false, false, false
			};
			public boolean isCellEditable(int row, int column) {
				return columnEditables[column];
			}
		
		});
		
		scrollPane.setViewportView(table);        
		table.setRowHeight(25);
		table.setSelectionMode(ListSelectionModel.SINGLE_SELECTION);
		table.getTableHeader().setReorderingAllowed(false);
		
		btnThemDia = new JButton("Thêm Đĩa");
		btnThemDia.setBounds(681, 81, 155, 41);
		btnThemDia.setContentAreaFilled(false);
		btnThemDia.setOpaque(true);
		btnThemDia.setForeground(Color.white);
		btnThemDia.setBorder(null);
		btnThemDia.setBackground(Color.decode("#4CAF50"));
		btnThemDia.setCursor(new Cursor(Cursor.HAND_CURSOR));
		btnThemDia.setFont(new Font("Segoe UI", Font.BOLD, 15));
		panel.add(btnThemDia);
				
		textField = new JTextField();
		textField.setBounds(10, 85, 661, 38);
		panel.add(textField);
		textField.setColumns(10);
		
		JLabel lblTimKhachHang = new JLabel(">>Tìm Đĩa");
		lblTimKhachHang.setBounds(10, 48, 600, 30);
		lblTimKhachHang.setFont(new Font("Segoe UI", Font.BOLD, 17));
		lblTimKhachHang.setForeground(new Color(255, 0, 255));
		panel.add(lblTimKhachHang);
		
		btnXoa = new JButton("Xóa Đĩa");
		btnXoa.setContentAreaFilled(false);
		btnXoa.setOpaque(true);
		btnXoa.setForeground(Color.white);
		btnXoa.setBorder(null);
		btnXoa.setCursor(new Cursor(Cursor.HAND_CURSOR));
		btnXoa.setFont(new Font("Segoe UI", Font.BOLD, 15));
		btnXoa.setBackground(Color.decode("#C2C018"));
		btnXoa.setBounds(846, 81, 155, 41);
		panel.add(btnXoa);
		
		textField.addKeyListener(this);
		btnThemDia.addActionListener(this);
		btnXoa.addActionListener(this);
		
		listdia = diacontrol.showAllDia();
		showAllDia(listdia);
	}
	
	public void showAllDia(ArrayList<Dia> list) {
		while(tableModel.getRowCount() >= 1)
			tableModel.removeRow(0);
		
		list.forEach(x->{
			String trangthai = "Đang trên kệ";
			if(x.getTrangthai().equals("H")) {
				trangthai = "Đã có người đặt";
			}
			
			if(x.getTrangthai().equals("R")) {
				trangthai = "Đã có người thuê";
			}
			
			Object[] tx = {x.getMadia(),trangthai,x.getTuadia().getTentua()};
			tableModel.addRow(tx);
		});
		
	}
	
	@Override
	public void actionPerformed(ActionEvent e) {
		Object o = e.getSource();
		if(o.equals(btnThemDia)) {
			themDiaDL = new ThemDiaDL(parent);
			themDiaDL.setVisible(true);
			
			listdia = diacontrol.showAllDia();
			showAllDia(listdia);
			String madia = themDiaDL.getMadia();
			if(table.getRowCount()>0) {
				for (int i = 0; i < table.getRowCount(); i++) {
					if(table.getValueAt(i, 0).equals(madia))
						table.setRowSelectionInterval(i, i);
				}
			}
		}
		
		if(o.equals(btnXoa))
		{
			
			if(table.getSelectedRow()>=0)
			{
				if (table.getValueAt(table.getSelectedRow(), 1).toString().equals("Đã có người đặt")||table.getValueAt(table.getSelectedRow(), 1).toString().equals("Đã có người thuê")) {
					JOptionPane.showMessageDialog(this, "Đĩa này đã có người đặt (thuê), không thể xóa!");
				}else {
					int reply = JOptionPane.showConfirmDialog(this, "Bạn có chắc xóa đĩa này ?","Xóa Đĩa", JOptionPane.YES_NO_OPTION);
					if(reply == JOptionPane.YES_OPTION)
					{
						if(diacontrol.xoaDia(table.getValueAt(table.getSelectedRow(), 0).toString())==false)
						{
							JOptionPane.showMessageDialog(this, "Đã có lỗi xảy ra !");
						}
						else
						{
							JOptionPane.showMessageDialog(this, "Xóa đĩa thành công !");
							listdia = diacontrol.showAllDia();
							showAllDia(listdia);
							textField.setText("");
						}
					}
					else
					{
						listdia = diacontrol.showAllDia();
						showAllDia(listdia);
					}
				}
			}
			else
			{
				JOptionPane.showMessageDialog(this, "Chọn đĩa để xóa !");
			}
		}
	}
	
	
	public void mouseEntered(MouseEvent e) {
		Object o = e.getSource();
		if(o.equals(btnThemDia))
			btnThemDia.setBackground(Color.decode("#66D856"));	
		
	}
	
	public void mouseExited(MouseEvent e) {
		Object o = e.getSource();
		if(o.equals(btnThemDia))
			btnThemDia.setBackground(Color.decode("#4CAF50"));	
		
	}

	@Override
	public void focusGained(FocusEvent e) {
		// TODO Auto-generated method stub
		Object o = e.getSource();
		if(o.equals(textField)&&textField.getText().equals("Nhập thông tin để tìm kiếm...")) {
			textField.setText("");
			textField.setForeground(Color.black);
		}
	}

	@Override
	public void focusLost(FocusEvent e) {
		// TODO Auto-generated method stub
		Object o = e.getSource();
		if(o.equals(textField)&&textField.getText().equals("")) {
			textField.setText("Nhập thông tin để tìm kiếm...");
			textField.setForeground(Color.LIGHT_GRAY);
		}
	}

	@Override
	public void keyPressed(KeyEvent e) {
		// TODO Auto-generated method stub
		Object o = e.getSource();
		if(o.equals(textField))
		{
			if(textField.getText().length()>100)
			{
				JOptionPane.showMessageDialog(this, "Bạn đã nhập quá nhiều!");
			}
		}
	}

	public void hienThiDiaTimKiem(String ttd) {
		ArrayList<Dia> list = diacontrol.timThongTinDia(ttd);
		if(list.size()>0)
		{
			tableModel.setNumRows(0);
			showAllDia(list);
		}
	}
	
	@Override
	public void keyReleased(KeyEvent e) {
		// TODO Auto-generated method stub
		Object o = e.getSource();
		if(o.equals(textField)) 
		{
			hienThiDiaTimKiem(textField.getText());
		}
	}

	@Override
	public void keyTyped(KeyEvent e) {
		// TODO Auto-generated method stub
		
	}
	
	
}
