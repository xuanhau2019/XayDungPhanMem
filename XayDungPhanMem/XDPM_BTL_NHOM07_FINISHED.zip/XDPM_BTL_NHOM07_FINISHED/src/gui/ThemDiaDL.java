package gui;

import java.awt.Color;
import java.awt.Cursor;
import java.awt.Font;
import java.awt.Image;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.KeyEvent;
import java.awt.event.KeyListener;
import java.awt.event.MouseEvent;
import java.awt.event.MouseListener;
import java.util.List;

import javax.swing.BorderFactory;
import javax.swing.DefaultListModel;
import javax.swing.ImageIcon;
import javax.swing.JButton;
import javax.swing.JDialog;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JList;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.JScrollPane;
import javax.swing.JTextField;
import javax.swing.ListSelectionModel;
import javax.swing.border.MatteBorder;

import control.DiaControl;
import control.TuaDiaControl;
import entities.Dia;
import entities.TuaDia;

@SuppressWarnings("serial")
public class ThemDiaDL extends JDialog implements ActionListener, KeyListener, MouseListener{

	TuaDiaControl tuadiacontrol = new TuaDiaControl();
	DiaControl diacontrol = new DiaControl();
	Dia dia = new Dia();
	private JTextField txtMadia;
	private JTextField txtMatua;
	private JButton btnHoanTat;
	private JButton btnHuy;
	QuanLyDia diaql;
	private JScrollPane scrollTimKiemTua;
	private DefaultListModel modelList;
	private JList dsTuaDia;
	private JLabel lblAnh;
	private TuaDia tuadiaDat;
	public String getMadia() {
		return this.dia.getMadia();
	}

	public ThemDiaDL(JFrame parent) {
		super(parent,true);
		setTitle("Thêm Đĩa");
		setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
		setSize(306, 494);
		setResizable(false);
		getContentPane().setLayout(null);
		setLocationRelativeTo(parent);
		setBackground(new Color(153, 204, 255));

		getContentPane().add(lblAnh = new JLabel(""));
		lblAnh.setBorder(BorderFactory.createLineBorder(Color.BLACK));
		lblAnh.setBounds(69, 170, 170, 220);

		JPanel panel = new JPanel();
		panel.setForeground(new Color(255, 51, 0));
		panel.setBorder(new MatteBorder(1, 1, 1, 1, (Color) new Color(0, 153, 255)));
		panel.setBackground(new Color(153, 204, 255));
		panel.setBounds(0, 0, 300, 34);
		getContentPane().add(panel);

		JLabel lblThemDia = new JLabel("Thêm Đĩa Mới");
		lblThemDia.setForeground(new Color(255, 102, 51));
		lblThemDia.setFont(new Font("Segoe UI", Font.BOLD, 17));
		panel.add(lblThemDia);

		JLabel lblMadia = new JLabel("Mã Đĩa");
		lblMadia.setFont(new Font("Segoe UI", Font.PLAIN, 15));
		lblMadia.setBounds(20, 35, 109, 21);
		getContentPane().add(lblMadia);

		txtMadia = new JTextField();
		txtMadia.setFont(new Font("Segoe UI", Font.PLAIN, 15));
		txtMadia.setColumns(10);
		txtMadia.setBounds(20, 60, 252, 25);
		txtMadia.setForeground(Color.LIGHT_GRAY);
		getContentPane().add(txtMadia);

		JLabel lblMatua = new JLabel("Tựa đĩa");
		lblMatua.setFont(new Font("Segoe UI", Font.PLAIN, 15));
		lblMatua.setBounds(20, 96, 91, 21);
		getContentPane().add(lblMatua);

		txtMatua = new JTextField();
		txtMatua.setFont(new Font("Segoe UI", Font.PLAIN, 15));
		txtMatua.setColumns(10);
		txtMatua.setBounds(20, 134, 252, 25);
		txtMatua.setForeground(Color.LIGHT_GRAY);
		getContentPane().add(txtMatua);

		getContentPane().add(scrollTimKiemTua = new JScrollPane());
		scrollTimKiemTua.setBounds(20, 159, 252, 100);
		modelList = new DefaultListModel<>();
		dsTuaDia = new JList<>();
		dsTuaDia.setModel(modelList);
		dsTuaDia.setFont(new Font("Segoe UI", Font.PLAIN, 15));
		dsTuaDia.setSelectionMode(ListSelectionModel.SINGLE_SELECTION);
		scrollTimKiemTua.setViewportView(dsTuaDia);
		scrollTimKiemTua.setVisible(false);


		btnHoanTat = new JButton("Thêm");
		btnHoanTat.setContentAreaFilled(false);
		btnHoanTat.setForeground(Color.white);
		btnHoanTat.setBorder(null);
		btnHoanTat.setBackground(Color.decode("#4CAF50"));
		btnHoanTat.setCursor(new Cursor(Cursor.HAND_CURSOR));
		btnHoanTat.setOpaque(true);
		btnHoanTat.setEnabled(false);
		btnHoanTat.setFont(new Font("Segoe UI", Font.BOLD, 15));
		btnHoanTat.setBounds(20, 413, 116, 30);
		getContentPane().add(btnHoanTat);

		btnHuy = new JButton("Hủy");
		btnHuy.setContentAreaFilled(false);
		btnHuy.setForeground(Color.white);
		btnHuy.setBorder(null);
		btnHuy.setBackground(Color.decode("#C14008")); 
		btnHuy.setCursor(new Cursor(Cursor.HAND_CURSOR));
		btnHuy.setFont(new Font("Segoe UI", Font.BOLD, 15));
		btnHuy.setOpaque(true);
		btnHuy.setBounds(174, 413, 116, 30);
		getContentPane().add(btnHuy);

		txtMadia.setBorder(null);
		txtMatua.setBorder(null);

		btnHuy.addActionListener(this);
		btnHoanTat.addActionListener(this);
		txtMadia.addKeyListener(this);
		txtMatua.addKeyListener(this);

		dsTuaDia.addMouseListener(this);
		scrollTimKiemTua.repaint();
	}

	@Override
	public void keyPressed(KeyEvent arg0) {
		// TODO Auto-generated method stub

	}
	@Override
	public void keyReleased(KeyEvent e) {
		// TODO Auto-generated method stub
		Object o = e.getSource();
		if(o.equals(txtMatua) )
		{
			if(txtMatua.getText().equals("") )
			{
				btnHoanTat.setEnabled(false);
				btnHoanTat.setBackground(Color.DARK_GRAY);
			}
			else
			{
				btnHoanTat.setEnabled(true);
				btnHoanTat.setBackground(Color.decode("#4CAF50"));
			}
		}	

		if(o.equals(txtMatua)) {
			if(!txtMatua.getText().equals("")) {
				List<TuaDia>listtd = tuadiacontrol.timThongTinTuaDia(txtMatua.getText());
				if(!listtd.isEmpty()) {
					modelList.removeAllElements();
					listtd.forEach(x->{
						modelList.addElement(x);
						dsTuaDia.setSelectedIndex(0);
						scrollTimKiemTua.setVisible(true);
						scrollTimKiemTua.repaint();
					});
				}else {
					scrollTimKiemTua.setVisible(false);
				}


			}else {
				scrollTimKiemTua.setVisible(false);
			}

		}

	}
	@Override
	public void keyTyped(KeyEvent arg0) {
		// TODO Auto-generated method stub

	}
	@Override
	public void actionPerformed(ActionEvent e) {
		// TODO Auto-generated method stub
		Object o = e.getSource();
		if(o.equals(btnHoanTat))
		{
			if(tuadiaDat != null) {
				String madia = txtMadia.getText();
				String matua = txtMatua.getText();
				if(txtMadia.getText().trim().equals("")) {
					JOptionPane.showMessageDialog(this, "Vui lòng nhập mã đĩa!");
				}else {
					if(!txtMatua.getText().equals(tuadiaDat.getTentua())) {
						int c = JOptionPane.showConfirmDialog(this, "Hệ thống sẽ lưu đĩa với tựa đĩa là " + tuadiaDat.getTentua());
						if(c == JOptionPane.YES_OPTION) {
							Dia d = new Dia(madia, "S", tuadiaDat);
							if(diacontrol.themDia(d)==true)
							{
								this.dia = d;
								JOptionPane.showMessageDialog(this, "Thêm đĩa thành công");
								dispose();
							}else {
								JOptionPane.showMessageDialog(this, "Đĩa này đã tồn tại");
							}

						}
					}else {
						Dia d = new Dia(madia, "s", tuadiaDat);
						if(diacontrol.themDia(d)==true)
						{
							this.dia = d;
							JOptionPane.showMessageDialog(this, "Thêm đĩa thành công");
							dispose();
						}else {
							JOptionPane.showMessageDialog(this, "Đĩa này đã tồn tại");
						}
					}
				}

			}else {
				JOptionPane.showMessageDialog(this, "Bạn chưa chọn tựa đĩa");
			}
		}
		if(o.equals(btnHuy))
		{
			dispose();	
		}
	}

	@Override
	public void mouseClicked(MouseEvent e) {
		// TODO Auto-generated method stub
		if(e.getSource() == dsTuaDia) {
			int row = dsTuaDia.getSelectedIndex();
			if(row != -1) {
				tuadiaDat = (TuaDia) dsTuaDia.getSelectedValue();
				lblAnh.setIcon(resizeImage("images/" + tuadiaDat.getAnh(), null));
				txtMatua.setText(tuadiaDat.getTentua());
				scrollTimKiemTua.setVisible(false);
			}
		}
	}
	public ImageIcon resizeImage(String imgPath, byte[] pic) {
		ImageIcon myImage = null;
		if (imgPath != null) {
			myImage = new ImageIcon(imgPath);
		}
		else {
			myImage = new ImageIcon(pic);
		}

		Image img1 = myImage.getImage();
		Image img2 = img1.getScaledInstance(lblAnh.getWidth(), lblAnh.getHeight(), Image.SCALE_SMOOTH);
		ImageIcon image = new ImageIcon(img2);
		return image;
	}

	@Override
	public void mousePressed(MouseEvent e) {
		// TODO Auto-generated method stub

	}

	@Override
	public void mouseReleased(MouseEvent e) {
		// TODO Auto-generated method stub

	}

	@Override
	public void mouseEntered(MouseEvent e) {
		// TODO Auto-generated method stub

	}

	@Override
	public void mouseExited(MouseEvent e) {
		// TODO Auto-generated method stub

	}
}