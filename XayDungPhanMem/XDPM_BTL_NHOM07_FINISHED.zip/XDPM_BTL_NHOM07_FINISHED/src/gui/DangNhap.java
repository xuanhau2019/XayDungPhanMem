package gui;

import java.awt.Color;
import java.awt.Cursor;
import java.awt.Font;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.FocusEvent;
import java.awt.event.FocusListener;
import java.awt.event.KeyEvent;
import java.awt.event.KeyListener;
import java.awt.event.MouseEvent;
import java.awt.event.MouseListener;

import javax.swing.ImageIcon;
import javax.swing.JButton;
import javax.swing.JDialog;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.JPasswordField;
import javax.swing.JTextField;
import javax.swing.border.EmptyBorder;

import control.TaiKhoanControl;
import entities.TaiKhoan;

@SuppressWarnings("serial")
public class DangNhap extends JDialog implements FocusListener, KeyListener, ActionListener, MouseListener {

	private JPanel contentPane;

	private JTextField txtUser;
	private JPasswordField txtPass;
	
	private JLabel lblImguser;
	private JLabel lblpassword;
	private JLabel lblNewLabel;
	private JLabel lblTittleBar;
	
	private JButton btnDangNhap;
	private JButton btnThoat;
	
	private TaiKhoanControl controlTaiKhoan = new TaiKhoanControl();

	public DangNhap(JFrame parent) {
		super(parent,true);
		setDefaultCloseOperation(DISPOSE_ON_CLOSE);
		setResizable(false);
		setSize(650, 840);
		setLocationRelativeTo(null);
		setUndecorated(true);
		
		createJFrame();
	}
	
	public void createJFrame() {
		
		contentPane = new JPanel();
		contentPane.setBackground(Color.decode("#F87C2C"));
		contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));
		setContentPane(contentPane);
		contentPane.setLayout(null);
		
		lblTittleBar = new JLabel("Phần mềm cho thuê băng đĩa");
		lblTittleBar.setFont(new Font("Segoe UI", Font.BOLD, 20));
		lblTittleBar.setBounds(220, -4, 300, 32);
		contentPane.add(lblTittleBar);
		
		JPanel panel = new JPanel();
		panel.setBounds(67, 143, 514, 580);
		panel.setBackground(new Color(240,248,255,100));
		panel.setLayout(null);
		contentPane.add(panel);
		
		txtUser = new JTextField("Mã nhân viên...");
		txtUser.setForeground(Color.LIGHT_GRAY);
		txtUser.setFont(new Font("Segoe UI", Font.ITALIC, 15));
		txtUser.setBorder(new EmptyBorder(5, 5, 5, 5));
		txtUser.setBounds(131, 243, 324, 55);
		panel.add(txtUser);
		txtUser.setColumns(10);
		
		txtPass = new JPasswordField("Mật khẩu...");
		txtUser.setForeground(Color.LIGHT_GRAY);
		txtPass.setFont(new Font("Segoe UI", Font.PLAIN, 25));
		txtPass.setBorder(new EmptyBorder(5, 5, 5, 5));
		txtPass.setBounds(131, 337, 324, 55);
		panel.add(txtPass);
		txtPass.setColumns(10);
		
		lblImguser = new JLabel("");
		lblImguser.setLayout(null);
		lblImguser.setOpaque(true);
		lblImguser.setIcon(new ImageIcon("images\\FormBackground\\IconUserName.png"));
		lblImguser.setBackground(Color.white);
		lblImguser.setBounds(77, 243, 55, 55);
		panel.add(lblImguser);
		
		lblpassword = new JLabel("");
		lblpassword.setOpaque(true);
		lblpassword.setIcon(new ImageIcon("images\\FormBackground\\IconPassword.png"));
		lblpassword.setBackground(Color.WHITE);
		lblpassword.setBounds(77, 337, 55, 55);
		panel.add(lblpassword);
		
		btnDangNhap = new JButton("\u0110\u0103ng nh\u1EADp");
		btnDangNhap.setBounds(77, 436, 376, 55);
		btnDangNhap.setContentAreaFilled(false);
		btnDangNhap.setForeground(Color.white);
		btnDangNhap.setBorder(null);
		btnDangNhap.setBackground(Color.decode("#009FFF"));
		btnDangNhap.setCursor(new Cursor(Cursor.HAND_CURSOR));
		btnDangNhap.setOpaque(true);
		btnDangNhap.setFont(new Font("Segoe UI", Font.BOLD, 20));
		
		panel.add(btnDangNhap);
		
		lblNewLabel = new JLabel("");
		lblNewLabel.setIcon(new ImageIcon("C:\\Users\\tranh\\workspace\\XDPM\\images\\FormBackground\\DangNhap_tittle.png"));
		lblNewLabel.setBounds(77, 75, 378, 157);
		panel.add(lblNewLabel);
		
		btnThoat = new JButton("Tho\u00E1t");
		btnThoat.setContentAreaFilled(false);
		btnThoat.setForeground(Color.white);
		btnThoat.setBorder(null);
		btnThoat.setBackground(Color.decode("#C14008"));
		btnThoat.setCursor(new Cursor(Cursor.HAND_CURSOR));
		btnThoat.setFont(new Font("Segoe UI", Font.BOLD, 15));
		btnThoat.setOpaque(true);
		btnThoat.setBounds(77, 502, 376, 55);
		btnThoat.setFont(new Font("Segoe UI", Font.BOLD, 20));
		panel.add(btnThoat);
		
		JLabel lbimg = new JLabel("");
		lbimg.setIcon(new ImageIcon("images\\FormBackground\\DangNhap_background.jpg"));
		lbimg.setBounds(0, 28, 650, 812);
		contentPane.add(lbimg);
		
		txtUser.addFocusListener(this);
		txtPass.addFocusListener(this);
		
		txtUser.addKeyListener(this);
		txtPass.addKeyListener(this);
		
		btnDangNhap.addActionListener(this);
		btnThoat.addActionListener(this);
		
		btnDangNhap.addMouseListener(this);
		btnThoat.addMouseListener(this);
	}

	@SuppressWarnings("deprecation")
	@Override
	public void focusGained(FocusEvent e) {
		Object o = e.getSource();
		if(o.equals(txtUser) && txtUser.getText().equals("Mã nhân viên...")) {
			txtUser.setText("");
			txtUser.setFont(new Font("Segoe UI", Font.PLAIN, 25));
			txtUser.setForeground(Color.black);
		}
		
		if(o.equals(txtPass) && txtPass.getText().equals("Mật khẩu...")) {
			txtPass.setText("");
			txtPass.setForeground(Color.black);
		}
	}

	@SuppressWarnings("deprecation")
	@Override
	public void focusLost(FocusEvent e) {
		Object o = e.getSource();
		if(o.equals(txtUser) && txtUser.getText().equals("")) {
			txtUser.setText("Mã nhân viên...");
			txtUser.setFont(new Font("Segoe UI", Font.ITALIC, 15));
			txtUser.setForeground(Color.LIGHT_GRAY);
		}
		
		if(o.equals(txtPass) && txtPass.getText().equals("")) {
			txtPass.setText("Mật khẩu...");
			txtPass.setForeground(Color.LIGHT_GRAY);
			
		}
		
	}
	
	@SuppressWarnings("deprecation")
	public void kiemtraDangNhap() {
		String user = txtUser.getText();
		String pass = txtPass.getText();
		
		if(user.equals("")) {
			JOptionPane.showMessageDialog(this, "Tên đăng nhập không được rỗng");
			txtUser.requestFocus();
			return;
		}
		else if(user.length() > 20) {
			JOptionPane.showMessageDialog(this, "Tên đăng nhập không vượt quá 20 ký tự");
			txtUser.selectAll();
			txtUser.requestFocus();
			return;
		}
		
		if(pass.equals("")) {
			JOptionPane.showMessageDialog(this, "Mật khẩu không được rỗng");
			txtPass.requestFocus();
			return;
		}
		else if(pass.length() > 100) {
			JOptionPane.showMessageDialog(this, "Mật khẩu không vượt quá 100 ký tự");
			txtPass.selectAll();
			txtPass.requestFocus();
			return;
		}
		
		TaiKhoan taikhoan = controlTaiKhoan.dangNhap(user, pass);
		if(taikhoan != null) {
			this.dispose();
			GUIChinh.mnTuyChon.setText("   Admin   ");
			GUIChinh.mntmDangXuat.setText("Đăng xuất");
			GUIChinh.user = taikhoan;
		}
		else {
			JOptionPane.showMessageDialog(this, "Tên đăng nhập hoặc mật khẩu không đúng");
			txtUser.selectAll();
			txtUser.requestFocus();
			return;
		}
	}

	@Override
	public void keyTyped(KeyEvent e) {}

	@Override
	public void keyPressed(KeyEvent e) {
		if(e.getKeyCode() == KeyEvent.VK_ENTER) {
			Object o = e.getSource();
			if(o.equals(txtPass) || o.equals(txtUser))
				kiemtraDangNhap();
		}
	}

	@Override
	public void keyReleased(KeyEvent e) {}

	@Override
	public void actionPerformed(ActionEvent e) {
		Object o = e.getSource();
		if(o.equals(btnThoat))
			this.dispose();

		else if(o.equals(btnDangNhap))
			kiemtraDangNhap();
	}

	@Override
	public void mouseClicked(MouseEvent e) {}

	@Override
	public void mousePressed(MouseEvent e) {}

	@Override
	public void mouseReleased(MouseEvent e) {}

	@Override
	public void mouseEntered(MouseEvent e) {
		Object o = e.getSource();
		if(o.equals(btnDangNhap))
			btnDangNhap.setBackground(Color.decode("#00FFFF"));	
		if(o.equals(btnThoat))
			btnThoat.setBackground(Color.decode("#FF9454"));	
		
	}

	@Override
	public void mouseExited(MouseEvent e) {
		Object o = e.getSource();
		if(o.equals(btnDangNhap))
			btnDangNhap.setBackground(Color.decode("#009FFF"));	
		if(o.equals(btnThoat))
			btnThoat.setBackground(Color.decode("#C14008"));			
	}
}
