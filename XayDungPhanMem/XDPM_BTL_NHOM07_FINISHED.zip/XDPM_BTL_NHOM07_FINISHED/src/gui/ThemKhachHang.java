package gui;

import java.awt.Color;
import java.awt.Cursor;
import java.awt.Font;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.KeyEvent;
import java.awt.event.KeyListener;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

import javax.swing.JButton;
import javax.swing.JDialog;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.JTextField;
import javax.swing.border.MatteBorder;

import control.KhachHangControl;
import entities.KhachHang;

@SuppressWarnings("serial")
public class ThemKhachHang extends JDialog implements ActionListener,KeyListener {

	String makh;
	KhachHangControl khcon = new KhachHangControl();
	KhachHang khachHang = new KhachHang();
	private JTextField txtMakh;
	private JTextField txtTenKh;
	private JTextField txtSodt;
	private JButton btnHoanTat;
	private JButton btnHuy;
	private JTextField txtDiaChi;
	QuanLyKhachHang khql;
	public String getMakh() {
		return this.makh;
	}

	public ThemKhachHang(JFrame parent, KhachHang kh) {
		super(parent,true);
		
		setTitle("Thêm Khách Hàng");
		setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
		setSize(435, 395);
		setResizable(false);
		getContentPane().setLayout(null);
		setLocationRelativeTo(parent);
		setBackground(new Color(153, 204, 255));
		
		JPanel panel = new JPanel();
		panel.setForeground(new Color(255, 51, 0));
		panel.setBorder(new MatteBorder(1, 1, 1, 1, (Color) new Color(0, 153, 255)));
		panel.setBackground(new Color(153, 204, 255));
		panel.setBounds(0, 0, 435, 34);
		getContentPane().add(panel);
		
		JLabel lblThemKH = new JLabel("Thêm Khách Hàng Mới");
		lblThemKH.setForeground(new Color(255, 102, 51));
		lblThemKH.setFont(new Font("Segoe UI", Font.BOLD, 17));
		if(kh != null)
			lblThemKH.setText("Sửa khách hàng");
		panel.add(lblThemKH);
		
		JLabel lblMakh = new JLabel("Mã Khách Hàng");
		lblMakh.setFont(new Font("Segoe UI", Font.PLAIN, 15));
		lblMakh.setBounds(20, 35, 109, 21);
		getContentPane().add(lblMakh);
		
		txtMakh = new JTextField();
		txtMakh.setFont(new Font("Segoe UI", Font.PLAIN, 15));
		txtMakh.setColumns(10);
		txtMakh.setBounds(20, 60, 386, 25);
		txtMakh.setForeground(Color.LIGHT_GRAY);
		getContentPane().add(txtMakh);
		
		JLabel lblTenKh = new JLabel("Tên Khách hàng");
		lblTenKh.setFont(new Font("Segoe UI", Font.PLAIN, 15));
		lblTenKh.setBounds(20, 100, 110, 21);
		getContentPane().add(lblTenKh);
		
		txtTenKh = new JTextField();
		txtTenKh.setFont(new Font("Segoe UI", Font.PLAIN, 15));
		txtTenKh.setColumns(10);
		txtTenKh.setBounds(20, 125, 386, 25);
		txtTenKh.setForeground(Color.LIGHT_GRAY);
		getContentPane().add(txtTenKh);
		
		JLabel lblSoDT = new JLabel("Số điện thoại");
		lblSoDT.setFont(new Font("Segoe UI", Font.PLAIN, 15));
		lblSoDT.setBounds(20, 165, 91, 21);
		getContentPane().add(lblSoDT);
		
		txtSodt = new JTextField();
		txtSodt.setFont(new Font("Segoe UI", Font.PLAIN, 15));
		txtSodt.setColumns(10);
		txtSodt.setBounds(20, 190, 386, 25);
		txtSodt.setForeground(Color.LIGHT_GRAY);
		getContentPane().add(txtSodt);
		
		
		JLabel lblDiaChi = new JLabel("Địa chỉ");
		lblDiaChi.setFont(new Font("Segoe UI", Font.PLAIN, 15));
		lblDiaChi.setBounds(20, 226, 109, 21);
		getContentPane().add(lblDiaChi);
		
		txtDiaChi = new JTextField();
		txtDiaChi.setFont(new Font("Segoe UI", Font.PLAIN, 15));
		txtDiaChi.setColumns(10);
		txtDiaChi.setBounds(20, 258, 386,25);
		txtDiaChi.setForeground(Color.LIGHT_GRAY);
		getContentPane().add(txtDiaChi);	
		
		btnHoanTat = new JButton("Thêm");
		btnHoanTat.setContentAreaFilled(false);
		btnHoanTat.setForeground(Color.white);
		btnHoanTat.setBorder(null);
		btnHoanTat.setBackground(Color.decode("#4CAF50"));
		btnHoanTat.setCursor(new Cursor(Cursor.HAND_CURSOR));
		btnHoanTat.setOpaque(true);
		btnHoanTat.setEnabled(false);
		btnHoanTat.setFont(new Font("Segoe UI", Font.BOLD, 15));
		btnHoanTat.setBounds(49, 311, 116, 30);
		getContentPane().add(btnHoanTat);
		
		btnHuy = new JButton("Hủy");
		btnHuy.setContentAreaFilled(false);
		btnHuy.setForeground(Color.white);
		btnHuy.setBorder(null);
		btnHuy.setBackground(Color.decode("#C14008"));
		btnHuy.setCursor(new Cursor(Cursor.HAND_CURSOR));
		btnHuy.setFont(new Font("Segoe UI", Font.BOLD, 15));
		btnHuy.setOpaque(true);
		btnHuy.setBounds(228, 311, 116, 30);
		getContentPane().add(btnHuy);
		
		
				
		txtMakh.setBorder(null);
		txtTenKh.setBorder(null);
		txtSodt.setBorder(null);
		txtDiaChi.setBorder(null);
		
		if(kh != null) { // nếu có khách hàng truyền vào diaglog sẽ trở thành chức năng sửa khách hàng
				setTitle("Sửa khách hàng");
				txtMakh.setText(kh.getIdkh());
				txtMakh.setForeground(Color.black);
				txtMakh.setEditable(false);
				
				txtSodt.setText(kh.getSodt());
				txtSodt.setForeground(Color.black);
				
				txtDiaChi.setText(kh.getDiachi());
				txtDiaChi.setForeground(Color.black);

				txtTenKh.setText(kh.getTenkh());
				txtTenKh.setForeground(Color.black);
				
				
				btnHoanTat.setText("Sửa");
				btnHoanTat.setBackground(Color.decode("#4CAF50"));
				btnHoanTat.setEnabled(true);
		}
		if(kh==null)
		{
			setTxtMakh();
			txtMakh.setEditable(false);
		}
		btnHuy.addActionListener(this);
		btnHoanTat.addActionListener(this);
		txtTenKh.addKeyListener(this);
		txtDiaChi.addKeyListener(this);
		txtSodt.addKeyListener(this);
	}

	public void setTxtMakh() {
		String makh = khcon.getMaKHMAX();
		if(makh == null)
			makh = "KH_000001";
		else {
			int stt = Integer.parseInt(makh.replaceAll("KH_", "")) + 1;
			if(stt < 10)
				makh = "KH_00000" + stt;
			else if(stt < 100)
				makh = "KH_0000" + stt;
			else if(stt < 1000)
				makh = "KH_000" + stt;
			else if(stt < 10000)
				makh = "KH_00" + stt;
			else if(stt < 100000)
				makh = "KH_0" + stt;
			else if(stt < 1000000)
				makh = "KH_" + stt;
		}
		txtMakh.setText(makh);
	}

	@Override
	public void actionPerformed(ActionEvent e) {
		Object o = e.getSource();
		if(o.equals(btnHoanTat))
		{
			String maKh = txtMakh.getText();
			String tenKh = txtTenKh.getText();
			String sDT = txtSodt.getText();
			String diaChi = txtDiaChi.getText();
			KhachHang kh = new KhachHang(maKh,tenKh,sDT,diaChi);
			Pattern pt = Pattern.compile("^[0-9]{10}$");
			Matcher mc = pt.matcher(txtSodt.getText());
			if(!mc.find())
			{
				JOptionPane.showMessageDialog(this, "Số điện thoại là số và bao gồm 10 chữ số bắt đầu bằng 0");
				txtSodt.selectAll();
				txtSodt.requestFocus();
			}
			else
			{
				if(btnHoanTat.getText().equals("Thêm"))
				{
					if(khcon.themKH(kh)==true)
					{
						this.khachHang = kh;
						JOptionPane.showMessageDialog(this, "Thêm khách hàng thành công");
						dispose();
					}
				}
				else
				{
					if(khcon.suaKH(kh)==true);
					{
						this.khachHang = kh;
						JOptionPane.showMessageDialog(this, "Sửa khách hàng thành công");
						dispose();	
					}
				}
			}
		}
		if(o.equals(btnHuy))
		{
			dispose();	
		}
	}

	@Override
	public void keyPressed(KeyEvent e) {
	}
	@Override
	public void keyReleased(KeyEvent e) {
		Object o = e.getSource();
		if(o.equals(txtTenKh) || o.equals(txtSodt) || o.equals(txtDiaChi))
		{
			if(txtTenKh.getText().equals("") || txtSodt.getText().equals("") || txtDiaChi.getText().equals(""))
			{
				btnHoanTat.setEnabled(false);
			}
			else
			{
				btnHoanTat.setEnabled(true);
			}
		}
	}

	@Override
	public void keyTyped(KeyEvent e) {
		// TODO Auto-generated method stub
		
	}
}
