package gui;

import java.awt.BorderLayout;
import java.awt.Color;
import java.awt.Dimension;
import java.awt.Font;
import java.awt.Image;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.KeyEvent;
import java.awt.event.KeyListener;
import java.awt.event.MouseEvent;
import java.awt.event.MouseListener;
import java.text.DecimalFormat;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.Date;

import javax.swing.BorderFactory;
import javax.swing.Box;
import javax.swing.DefaultListModel;
import javax.swing.ImageIcon;
import javax.swing.JButton;
import javax.swing.JLabel;
import javax.swing.JList;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.JScrollPane;
import javax.swing.JTextField;
import javax.swing.ListSelectionModel;

import control.DatDiaControl;
import control.DiaControl;
import control.PhiTreHanControl;
import control.PhieuThueControl;
import control.PhieuTraControl;
import control.ThanhToanTreHanControl;
import entities.ChiTietPhieuThue;
import entities.DatDia;
import entities.Dia;
import entities.KhachHang;
import entities.PhiTreHan;
import entities.PhieuThue;
import entities.PhieuTra;
import entities.ThanhToanTreHan;

@SuppressWarnings("serial")
public class TraDia extends JPanel implements ActionListener, KeyListener, MouseListener {

	JLabel lblTD, lblMaPTra, lblNgayTra, lblMaDia, lblTenTua, lblLoai, lblMaPThue, lblNgayThue, lblHanTraDia, lblPhiTreHan,
	lblMaKH, lblTenKH, lblSodt, lblDiaChi, lblAnh, lblTienTre;
	JTextField txtMaPTra, txtNgayTra, txtMaDia, txtTenTua, txtLoai, txtMaPThue, txtNgayThue, txtHanTraDia, txtPhiTreHan,
	txtMaKH, txtTenKH, txtSodt, txtDiaChi, txtTienTre;
	JButton btnLuu, btnHuy, btnTim;
	
	JList<Dia> listDia;
	DefaultListModel<Dia> modelList;
	JScrollPane scrollTimKiemDia;

	DecimalFormat dmf = new DecimalFormat("#,##0");
	SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd");
	Date nowday = new Date();
	KhachHang khTraDia = new KhachHang();
	Dia diaTra = new Dia();
	PhieuThue pthue = new PhieuThue();
	boolean coKhachDatDia = false;												// nếu là false thì khách hàng hủy đặt trước

	PhieuTraControl ptraCon = new PhieuTraControl();
	DiaControl diacon = new DiaControl();
	DatDiaControl datdiaControl = new DatDiaControl();
	PhieuThueControl pthueControl = new PhieuThueControl();
	
	/**
	 * Create the panel.
	 */
	public TraDia() {
		setLayout(null);
		JPanel panel = new JPanel();
		panel.setBounds(0, 0, 1200, 788);
		setBounds(0, 0, 1200, 788);
		add(panel);

		// ------------------ NORTH ------------------ //
		JPanel pNorth = new JPanel();
		pNorth.setBackground(Color.CYAN);
		pNorth.setLayout(new BorderLayout());
		pNorth.setPreferredSize(new Dimension(1200, 35));
		pNorth.add(lblTD = new JLabel("PHIẾU TRẢ", JLabel.CENTER));
		lblTD.setFont(new Font("Calibri Light", Font.BOLD, 27));
		panel.add(pNorth, BorderLayout.NORTH);

		// ------------------ CENTER ------------------ //
		JPanel pnCenMid = new JPanel();
		pnCenMid.setLayout(new BorderLayout());
		JPanel pnContain = new JPanel();
		pnContain.setLayout(new BorderLayout());
		JPanel pnConNor = new JPanel();
		pnConNor.setLayout(new BorderLayout());
		pnConNor.setPreferredSize(new Dimension(1200,210));
		pnConNor.setBorder(BorderFactory.createTitledBorder("Phiếu trả"));
		JPanel pnBoxNor = new JPanel();
		pnBoxNor.setLayout(null);
		pnBoxNor.add(lblMaPTra = new JLabel("Mã phiếu trả"));
		pnBoxNor.add(txtMaPTra = new JTextField());
		lblMaPTra.setBounds(100, 5, 90, 20);
		txtMaPTra.setBounds(195, 5, 200, 25);
		pnBoxNor.add(lblNgayTra = new JLabel("Ngày lập"));
		pnBoxNor.add(txtNgayTra = new JTextField());
		lblNgayTra.setBounds(440, 5, 100, 20);
		txtNgayTra.setBounds(510, 5, 200, 25);

		pnBoxNor.add(lblMaDia = new JLabel("Mã đĩa", JLabel.CENTER));
		pnBoxNor.add(txtMaDia = new JTextField());
		lblMaDia.setBounds(100, 45, 90, 20);
		txtMaDia.setBounds(195, 45, 200, 25);
		pnBoxNor.add(btnTim = new JButton("    Tìm mã đĩa", new ImageIcon("images/search.png")));
		btnTim.setBounds(420, 43, 125, 28);
		pnBoxNor.add(scrollTimKiemDia = new JScrollPane());
		scrollTimKiemDia.setBounds(195, 71, 200, 80);
		modelList = new DefaultListModel<>();
		listDia = new JList<>();
		listDia.setModel(modelList);
		listDia.setFont(new Font("Segoe UI", Font.PLAIN, 15));
		listDia.setSelectionMode(ListSelectionModel.SINGLE_SELECTION);
		scrollTimKiemDia.setViewportView(listDia);
		scrollTimKiemDia.setVisible(false);
		
		pnBoxNor.add(lblMaKH = new JLabel("Mã khách hàng", JLabel.CENTER));
		pnBoxNor.add(txtMaKH = new JTextField());
		lblMaKH.setBounds(100, 85, 90, 20);
		txtMaKH.setBounds(195, 85, 200, 25);
		pnBoxNor.add(lblTenKH = new JLabel("Khách hàng"));
		pnBoxNor.add(txtTenKH = new JTextField());
		lblTenKH.setBounds(440, 85, 100, 20);
		txtTenKH.setBounds(510, 85, 200, 25);

		pnBoxNor.add(lblSodt = new JLabel("Số điện thoại", JLabel.CENTER));
		pnBoxNor.add(txtSodt = new JTextField());
		lblSodt.setBounds(100, 125, 90, 20);
		txtSodt.setBounds(195, 125, 200, 25);
		pnBoxNor.add(lblDiaChi = new JLabel("Địa chỉ"));
		pnBoxNor.add(txtDiaChi = new JTextField());
		lblDiaChi.setBounds(440, 125, 100, 20);
		txtDiaChi.setBounds(510, 125, 200, 25);
		
		pnConNor.add(pnBoxNor);
		pnContain.add(pnConNor, BorderLayout.NORTH);

//		JPanel pnConCenter = new JPanel();
//		pnConCenter.setLayout(new BorderLayout());
//		pnConCenter.setPreferredSize(new Dimension(1200,105));
//		pnConCenter.setBorder(BorderFactory.createTitledBorder("Khách hàng trả đĩa"));
//		JPanel pnBoxConCenter = new JPanel();
//		pnBoxConCenter.setLayout(null);
//		pnBoxConCenter.add(lblMaKH = new JLabel("Mã khách hàng", JLabel.CENTER));
//		pnBoxConCenter.add(txtMaKH = new JTextField());
//		lblMaKH.setBounds(100, 5, 90, 20);
//		txtMaKH.setBounds(195, 5, 200, 25);
//		pnBoxConCenter.add(lblTenKH = new JLabel("Khách hàng"));
//		pnBoxConCenter.add(txtTenKH = new JTextField());
//		lblTenKH.setBounds(440, 5, 100, 20);
//		txtTenKH.setBounds(510, 5, 200, 25);
//
//		pnBoxConCenter.add(lblSodt = new JLabel("Số điện thoại", JLabel.CENTER));
//		pnBoxConCenter.add(txtSodt = new JTextField());
//		lblSodt.setBounds(100, 45, 90, 20);
//		txtSodt.setBounds(195, 45, 200, 25);
//		pnBoxConCenter.add(lblDiaChi = new JLabel("Địa chỉ"));
//		pnBoxConCenter.add(txtDiaChi = new JTextField());
//		lblDiaChi.setBounds(440, 45, 100, 20);
//		txtDiaChi.setBounds(510, 45, 200, 25);
//		pnConCenter.add(pnBoxConCenter);
//		pnContain.add(pnConCenter, BorderLayout.CENTER);
		pnCenMid.add(pnContain, BorderLayout.NORTH);

		JPanel pnMiddel = new JPanel();
		pnMiddel.setLayout(new BorderLayout());
		pnMiddel.setPreferredSize(new Dimension(1200,230));
		pnMiddel.setBorder(BorderFactory.createTitledBorder("Chi tiết phiếu thuê"));
		JPanel pnBoxMiddel = new JPanel();
		pnBoxMiddel.setLayout(null);
		pnBoxMiddel.add(lblMaPThue = new JLabel("Mã phiếu thuê", JLabel.CENTER));
		pnBoxMiddel.add(txtMaPThue = new JTextField());
		lblMaPThue.setBounds(100, 7, 90, 20);
		txtMaPThue.setBounds(195, 7, 200, 25);
		pnBoxMiddel.add(lblNgayThue = new JLabel("Ngày thuê"));
		pnBoxMiddel.add(txtNgayThue = new JTextField());
		lblNgayThue.setBounds(440, 7, 100, 20);
		txtNgayThue.setBounds(510, 7, 200, 25);

		pnBoxMiddel.add(lblTenTua = new JLabel("Tên tựa đĩa", JLabel.CENTER));
		pnBoxMiddel.add(txtTenTua = new JTextField());
		lblTenTua.setBounds(100, 50, 100, 20);
		txtTenTua.setBounds(195, 50, 200, 25);
		pnBoxMiddel.add(lblLoai = new JLabel("Loại đĩa"));
		pnBoxMiddel.add(txtLoai = new JTextField());
		lblLoai.setBounds(440, 50, 100, 20);
		txtLoai.setBounds(510, 50, 200, 25);

		pnBoxMiddel.add(lblHanTraDia = new JLabel("Hạn trả đĩa (ngày)", JLabel.CENTER));
		pnBoxMiddel.add(txtHanTraDia = new JTextField());
		lblHanTraDia.setBounds(95, 90, 90, 20);
		txtHanTraDia.setBounds(195, 90, 200, 25);
		pnBoxMiddel.add(lblPhiTreHan = new JLabel("Phí trễ hạn"));
		pnBoxMiddel.add(txtPhiTreHan = new JTextField());
		lblPhiTreHan.setBounds(440, 90, 100, 20);
		txtPhiTreHan.setBounds(510, 90, 200, 25);

		pnBoxMiddel.add(lblTienTre = new JLabel("Tiền trễ hạn", JLabel.CENTER));
		pnBoxMiddel.add(txtTienTre = new JTextField());
		lblTienTre.setBounds(85, 130, 110, 20);
		txtTienTre.setBounds(195, 130, 200, 25);
		txtTienTre.setBorder(BorderFactory.createLineBorder(Color.GRAY));
		pnBoxMiddel.add(lblAnh = new JLabel());
		lblAnh.setBorder(BorderFactory.createLineBorder(Color.BLACK));
		lblAnh.setBounds(820, 7, 260, 180);

		pnMiddel.add(pnBoxMiddel, BorderLayout.CENTER);
		pnCenMid.add(pnMiddel, BorderLayout.CENTER);
		panel.add(pnCenMid, BorderLayout.CENTER);

		// ------------------ SOUTH ------------------ //
		JPanel pSouth = new JPanel();
		pSouth.setLayout(new BorderLayout());
		Box boxSou = Box.createVerticalBox();
		boxSou.add(Box.createVerticalStrut(-10));
		Box boxSouContain = Box.createHorizontalBox();
		boxSouContain.add(Box.createHorizontalStrut(60));
		boxSouContain.add(btnLuu = new JButton("   Lưu phiếu trả", new ImageIcon("images/save.png")));
		boxSouContain.add(Box.createHorizontalStrut(30));
		boxSouContain.add(btnHuy = new JButton("   Hủy phiếu trả", new ImageIcon("images/cancal.png")));
		boxSouContain.add(Box.createHorizontalStrut(60));
		btnLuu.setPreferredSize(new Dimension(200, 150));
		btnHuy.setPreferredSize(btnLuu.getPreferredSize());
		boxSou.add(boxSouContain);
		pSouth.add(boxSou);
		panel.add(pSouth, BorderLayout.SOUTH);

		eventAction();
		eventTextField();
		hiddenTextField(false);

		capnhatMaPhieuTra();				// gán mã phiếu thuê
		txtNgayTra.setText(sdf.format(nowday));
	}

	// Resize image
	public ImageIcon resizeImage(String imgPath, byte[] pic) {
		ImageIcon myImage = null;
		if (imgPath != null) {
			myImage = new ImageIcon(imgPath);
		}
		else {
			myImage = new ImageIcon(pic);
		}

		Image img1 = myImage.getImage();
		Image img2 = img1.getScaledInstance(lblAnh.getWidth(), lblAnh.getHeight(), Image.SCALE_SMOOTH);
		ImageIcon image = new ImageIcon(img2);
		return image;
	}

	// Tự cập nhật phiếu tra
	public void capnhatMaPhieuTra() {
		String maptra = ptraCon.getLastMaPhieuTra();
		if(maptra == null)
			txtMaPTra.setText("PTRA_0000001");
		else {
			int stt = Integer.parseInt(maptra.replaceAll("PTRA_", "")) + 1;
			if(stt < 10)
				txtMaPTra.setText("PTRA_000000" + stt);
			else if(stt < 100)
				txtMaPTra.setText("PTRA_00000" + stt);
			else if(stt < 1000)
				txtMaPTra.setText("PTRA_0000" + stt);
			else if(stt < 10000)
				txtMaPTra.setText("PTRA_000" + stt);
			else if(stt < 100000)
				txtMaPTra.setText("PTRA_00" + stt);
			else if(stt < 1000000)
				txtMaPTra.setText("PTRA_0" + stt);
			else
				txtMaPTra.setText("PTRA_" + stt);
		}
	}

	// Bắt sự kiện button
	public void eventAction() {
		btnTim.addActionListener(this);
		btnLuu.addActionListener(this);
		btnHuy.addActionListener(this);
		
		listDia.addMouseListener(this);
	}

	// Bắt sự kiện text field
	public void eventTextField() {
		txtMaDia.addKeyListener(this);
	}

	// Ẩn textfield
	public void hiddenTextField(boolean b) {
		txtMaPTra.setEditable(b);
		txtNgayTra.setEditable(b);
		txtMaKH.setEditable(b);
		txtTenKH.setEditable(b);
		txtSodt.setEditable(b);
		txtDiaChi.setEditable(b);
		txtMaPThue.setEditable(b);
		txtNgayThue.setEditable(b);
		txtTenTua.setEditable(b);
		txtLoai.setEditable(b);
		txtHanTraDia.setEditable(b);
		txtPhiTreHan.setEditable(b);
		txtTienTre.setEditable(b);
	}

	// Xóa trắng TextField Khách hàng
	public void xoatrangField() {
		capnhatMaPhieuTra();
		
		txtMaKH.setText("");
		txtTenKH.setText("");
		txtSodt.setText("");
		txtDiaChi.setText("");
		txtMaPThue.setText("");
		txtNgayThue.setText("");
		txtMaDia.setText("");
		txtTenTua.setText("");
		txtLoai.setText("");
		txtHanTraDia.setText("");
		txtPhiTreHan.setText("");
		txtTienTre.setText("");
		lblAnh.setIcon(null);
	}

	// đưa thông tin khách hàng vào TextField
	public void duaThongTinKHvaoTextField(KhachHang kh) {
		txtMaKH.setText(kh.getIdkh());
		txtTenKH.setText(kh.getTenkh());
		txtSodt.setText(kh.getSodt());
		txtDiaChi.setText(kh.getDiachi());
	}

	public void duaDiaVaoJList(ArrayList<Dia> list) {
		for (Dia dia : list) {
			modelList.addElement(dia);
			listDia.setSelectedIndex(0);
		}
	}
	public void chonDiaTrongJList() {
		diaTra = listDia.getSelectedValue();
		duaChiTietPhieuThueVaoTextField(diaTra);

		scrollTimKiemDia.setVisible(false);
		modelList.removeAllElements();
	}
	
	// tìm đĩa trong chi tiết phiếu thuê để đưa vào textField
	public void duaChiTietPhieuThueVaoTextField(Dia dia) {
//		ArrayList<Dia> arrdia = diacon.timThongTinDia(madia);
//		if(arrdia.size() > 0) {
//			ArrayList<ChiTietPhieuThue> arrCTPT = pthueControl.timChiTietPhieuThue(null, arrdia.get(0));
		ArrayList<ChiTietPhieuThue> arrCTPT = pthueControl.timChiTietPhieuThue(null, dia);
			if(arrCTPT.size() > 0) {
				ChiTietPhieuThue ctpt = arrCTPT.get(0);
				diaTra = ctpt.getDia();
				pthue = pthueControl.timPhieuThueTheoMaPT(ctpt.getPhieuthue().getMaphieuthue());
				if(pthue == null) {
					JOptionPane.showMessageDialog(this, "Đĩa này đang được giữ cho khách hàng");
					txtMaDia.selectAll();
					txtMaDia.requestFocus();
				}
				else {
					khTraDia = pthue.getKh();
					duaThongTinKHvaoTextField(khTraDia);
					txtMaPThue.setText(pthue.getMaphieuthue());
					txtNgayThue.setText(sdf.format(pthue.getNgaythue()));
					txtTenTua.setText(diaTra.getTuadia().getTentua());
					txtLoai.setText(diaTra.getTuadia().getLoaidia().getTenloaidia());
					txtHanTraDia.setText(Integer.toString(ctpt.getHantradia()));
					txtPhiTreHan.setText(dmf.format(ctpt.getPhitrehan()) + "  VNĐ");
					lblAnh.setIcon(resizeImage("images/"+ diaTra.getTuadia().getAnh(), null));

					int soNgayTre = tinhTienTreHan(pthue.getNgaythue(), nowday);
					// Nếu trả quá ngày thì tính tiền trễ hạn của Khách hàng tiền trễ hạn = số ngày trễ * phí trễ hạn
					if(soNgayTre > ctpt.getHantradia()) {
						double tienTreHan = soNgayTre * ctpt.getPhitrehan();
						txtTienTre.setText(dmf.format(tienTreHan) + "  VNĐ");
						txtTienTre.setBorder(BorderFactory.createLineBorder(Color.RED));
					}
					else {
						txtTienTre.setText("0");
						txtTienTre.setBorder(BorderFactory.createLineBorder(Color.GRAY));
					}
					txtMaDia.setText(diaTra.getMadia());
					txtTenTua.requestFocus();
				}
			}
			else {
				JOptionPane.showMessageDialog(this, "Đĩa này chưa cho thuê");
				txtMaDia.selectAll();
				txtMaDia.requestFocus();
			}
//		}
//		else {
//			JOptionPane.showMessageDialog(this, "Đĩa này không có trong kho");
//			txtMaDia.selectAll();
//			txtMaDia.requestFocus();
//		}
	}

	/**
	 * Tính khoản cách ngày trả và ngày thuê
	 * @param ngayThue
	 * @param ngayTra
	 * @return
	 */
	public int tinhTienTreHan(Date ngayThue, Date ngayTra) {
		Calendar c1 = Calendar.getInstance();
		Calendar c2 = Calendar.getInstance();

		c1.setTime(ngayThue);
		c2.setTime(ngayTra);

		int day = (int) ((c2.getTime().getTime() - c1.getTime().getTime()) / (24 * 3600 * 1000));

		return day;
	}

	// Tự cập nhật phiếu tra
	public String layMaPhiTreHanCuoiCung(String matrehan) {
		if(matrehan == null)
			matrehan = "TRE_0000001";
		else {
			int stt = Integer.parseInt(matrehan.replaceAll("TRE_", "")) + 1;
			if(stt < 10)
				matrehan = "TRE_000000" + stt;
			else if(stt < 100)
				matrehan = "TRE_00000" + stt;
			else if(stt < 1000)
				matrehan = "TRE_0000" + stt;
			else if(stt < 10000)
				matrehan = "TRE_000" + stt;
			else if(stt < 100000)
				matrehan = "TRE_00" + stt;
			else if(stt < 1000000)
				matrehan = "TRE_0" + stt;
			else
				matrehan = "TRE_" + stt;
		}
		return matrehan;
	}
	
	// Lấy mã thanh toán cuối cùng và tăng lên 1
	public String layMaThanhToanTreHan(String matt) {
		if(matt == null)
			matt = "TT_0000001";
		else {
			int stt = Integer.parseInt(matt.replaceAll("TT_", "")) + 1;
			if(stt < 10)
				matt = "TT_000000" + stt;
			else if(stt < 100)
				matt = "TT_00000" + stt;
			else if(stt < 1000)
				matt = "TT_0000" + stt;
			else if(stt < 10000)
				matt = "TT_000" + stt;
			else if(stt < 100000)
				matt = "TT_00" + stt;
			else if(stt < 1000000)
				matt = "TT_0" + stt;
			else
				matt = "TT_" + stt;
		}
		return matt;
	}
	// lấy phiếu thuê cuối cùng và tăng lên 1  
	public String layMaPhieuThue() {
		String mapt = pthueControl.getLastMaPhieuThue();
		if(mapt == null)
			mapt = "PTHUE_0000001";
		else {
			int stt = Integer.parseInt(mapt.replaceAll("PTHUE_", "")) + 1;
			if(stt < 10)
				mapt = "PTHUE_000000" + stt;
			else if(stt < 100)
				mapt = "PTHUE_00000" + stt;
			else if(stt < 1000)
				mapt = "PTHUE_0000" + stt;
			else if(stt < 10000)
				mapt = "PTHUE_000" + stt;
			else if(stt < 100000)
				mapt = "PTHUE_00" + stt;
			else if(stt < 1000000)
				mapt = "PTHUE_0" + stt;
			else
				mapt = "PTHUE_" + stt;
		}
		return mapt;
	}
	
	/**
	 * Sử dụng đệ quy để tìm khách hàng đặt đĩa
	 * @param tuaDia
	 */
	public void ktDiaDatTruoc(String tuaDia) {

		DatDia datdia = datdiaControl.getKhachHangDatDiaDauTien(tuaDia);
		
		if(datdia != null) {
			if(JOptionPane.showConfirmDialog(this, "Liên hệ: " + datdia.getKh().getTenkh() + " -> Số điện thoại: " + datdia.getKh().getSodt()
				+ "\nCó muốn đặt Tựa: " + datdia.getTuadia().getTentua() + " hay không?", "Thông báo có khách đặt đĩa", JOptionPane.YES_NO_OPTION) == JOptionPane.YES_OPTION) {
				
				// Xem lại việc gán đĩa
			
				datdia.setGanDia(diaTra);
				datdiaControl.ganDiaChoKhachHang(datdia);
				
				JOptionPane.showMessageDialog(this, "Đĩa đã được giữ lại cho khách hàng " + datdia.getKh().getTenkh());
				
				coKhachDatDia = true;
			}
			else {
				// Nếu khách hàng không đồng ý thì xóa đặt đĩa của khách hàng này
				datdiaControl.xoaDatDia(datdia.getKh().getIdkh(), datdia.getTuadia().getMatua());
				ktDiaDatTruoc(tuaDia);
			}
		}
	}

	/**
	 * Lưu phiếu trả vào CSDL
	 */
	public void luuPhieuTra(PhieuTra ptra) {
		if(ptra != null) {
			if(ptraCon.themPhieuTra(ptra)) {				
				
				// cập nhật chi tiết phiếu thuê là đĩa này đã được trả
				pthueControl.capnhatChiTietPhieuThue(pthue, diaTra, "R");
				
				String soTien = txtTienTre.getText().replaceAll(",", "");
				double tientrehan = Double.parseDouble(soTien.replaceAll("  VNĐ", ""));
				// kiểm tra tiền trễ hạn > 0 hay không?
				if(tientrehan > 0) {
					PhiTreHanControl ptrehanCon = new PhiTreHanControl();
					
					String matrehan = ptrehanCon.getLastMaPhiTreHan();
					PhiTreHan ptreHan = new PhiTreHan(layMaPhiTreHanCuoiCung(matrehan), ptra, tientrehan);
					
					// thêm phí trễ hạn
					ptrehanCon.themPhiTreHan(ptreHan);

					// Nếu nhân viên nhấn "Yes" thì lưu lại thanh toán của khách hàng
					if(JOptionPane.showConfirmDialog(this, "Có thanh toán tiền trễ hạn luôn không?", "Thông báo",
							JOptionPane.YES_NO_OPTION) == JOptionPane.YES_OPTION) {
						
						ThanhToanTreHanControl ttTreHanCon = new ThanhToanTreHanControl();
						String matt = ttTreHanCon.getLastMaThanhToanTreHan();
						
						ThanhToanTreHan tt = new ThanhToanTreHan(layMaThanhToanTreHan(matt), ptreHan, nowday);
						ttTreHanCon.themThanhToanTreHan(tt);
					}
					
					JOptionPane.showMessageDialog(this, "Lưu phiếu trả thành công");
				}
				xoatrangField();
				capnhatMaPhieuTra();
				
				/*
				 * kiểm tra Khách hàng có đặt đĩa này hay không?
				 * Sau đó cập nhật lại trạng thái của đĩa là trên kệ
				 */
				ktDiaDatTruoc(diaTra.getTuadia().getTentua());
				
				if(coKhachDatDia == false)
					diaTra.setTrangthai("S");
				else
					diaTra.setTrangthai("H");

				diacon.capnhatThongTinDia(diaTra);
				coKhachDatDia = false;
			}
		}
	}

	@Override
	public void actionPerformed(ActionEvent e) {

		Object ob = e.getSource();
		if(ob == btnTim) {
			String madia = txtMaDia.getText();
			// bắt lỗi nhập sai mã
			if(madia.equals("")) {
				JOptionPane.showMessageDialog(this, "Mã đĩa không được rỗng");
				txtMaDia.requestFocus();
				return;
			}
			Dia diaTim = diacon.timDiaTheoMa(madia);
			if(diaTim != null)
				duaChiTietPhieuThueVaoTextField(diaTim);
			else {
				JOptionPane.showMessageDialog(this, "Đĩa này không có trong kho");
				txtMaDia.selectAll();
				txtMaDia.requestFocus();
			}
			
		}
		else if(ob == btnLuu) {
			if(!txtTenTua.getText().equals("")) {
				PhieuTra ptra = new PhieuTra(txtMaPTra.getText(), nowday, pthue, diaTra);
				luuPhieuTra(ptra);
			}
			else
				JOptionPane.showMessageDialog(this, "Chưa có thông tin phiếu trả");
		}
		else if(ob == btnHuy)
			xoatrangField();

	}

	@Override
	public void keyPressed(KeyEvent e) {
		if(e.getKeyCode() == KeyEvent.VK_ENTER) {
			Object ob = e.getSource();
			if(ob == txtMaDia) {
				String madia = txtMaDia.getText();
				// bắt lỗi nhập sai mã
				if(madia.equals("")) {
					JOptionPane.showMessageDialog(this, "Mã đĩa không được rỗng");
					txtMaDia.requestFocus();
					xoatrangField();
					return;
				}
				else {
					if(listDia.getSelectedIndex() != -1)
						chonDiaTrongJList();
					else {
						JOptionPane.showMessageDialog(this, "Mã đĩa không đúng");
						txtMaDia.selectAll();
						txtMaDia.requestFocus();
					}
				}
//				if(!txtMaDia.getText().equals(""))
//					duaChiTietPhieuThueVaoTextField(txtMaDia.getText());
			}
		}
	}
	
	public boolean timThongTinDia(String madia) {
		ArrayList<Dia> arrayDia = new ArrayList<>();
		arrayDia = diacon.soKhopMaDia(madia);
		if(arrayDia.size() > 0) {
			modelList.removeAllElements();
			duaDiaVaoJList(arrayDia);
			return true;
		}
		return false;
	}

	@Override
	public void keyReleased(KeyEvent e) {
		if(e.getSource() == txtMaDia) {
			if(!txtMaDia.getText().equals("")) {
				boolean bTimDia = timThongTinDia(txtMaDia.getText());
				if(bTimDia == true)
					scrollTimKiemDia.setVisible(true);
				else
					scrollTimKiemDia.setVisible(false);
			}
			else {
				scrollTimKiemDia.setVisible(false);
				xoatrangField();
			}
		}
	}

	@Override
	public void keyTyped(KeyEvent e) {}

	@Override
	public void mouseClicked(MouseEvent e) {
		if(e.getSource() == listDia) {
			int row = listDia.getSelectedIndex();
			if(row != -1)
				chonDiaTrongJList();
		}
	}

	@Override
	public void mouseEntered(MouseEvent e) {
		// TODO Auto-generated method stub
		
	}

	@Override
	public void mouseExited(MouseEvent e) {
		// TODO Auto-generated method stub
		
	}

	@Override
	public void mousePressed(MouseEvent e) {
		// TODO Auto-generated method stub
		
	}

	@Override
	public void mouseReleased(MouseEvent e) {
		// TODO Auto-generated method stub
		
	}

}
