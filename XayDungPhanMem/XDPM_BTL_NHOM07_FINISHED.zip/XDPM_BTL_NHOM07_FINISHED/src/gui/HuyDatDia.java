package gui;

import java.awt.Color;
import java.awt.Component;
import java.awt.Cursor;
import java.awt.Dimension;
import java.awt.Font;
import java.awt.Image;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.FocusEvent;
import java.awt.event.FocusListener;
import java.awt.event.KeyEvent;
import java.awt.event.KeyListener;
import java.awt.event.MouseEvent;
import java.awt.event.MouseListener;
import java.util.ArrayList;

import javax.swing.DefaultListModel;
import javax.swing.Icon;
import javax.swing.ImageIcon;
import javax.swing.JButton;
import javax.swing.JLabel;
import javax.swing.JList;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.JScrollPane;
import javax.swing.JTable;
import javax.swing.JTextField;
import javax.swing.ListSelectionModel;
import javax.swing.table.DefaultTableModel;
import javax.swing.table.JTableHeader;
import javax.swing.table.TableCellRenderer;

import control.DatDiaControl;
import control.DiaControl;
import control.KhachHangControl;
import entities.DatDia;
import entities.Dia;
import entities.KhachHang;

@SuppressWarnings("serial")
public class HuyDatDia extends JPanel implements ActionListener, MouseListener, KeyListener, FocusListener {

	JLabel lblTitle;
	JTextField txtTim;
	JButton btnTim, btnHuyDat;
	DefaultTableModel tableModel;
	JTable tableDiaDat;
	JList<KhachHang> dsKhachHang;
	DefaultListModel<KhachHang> modelList;
	JScrollPane scrollTimKiemDiaDat;
	
	KhachHangControl khCon = new KhachHangControl();
	DatDiaControl 	 datDiaCon = new DatDiaControl();
	
	int rollOverRowIndex = -1;
	boolean coKhachDatDia = false;
	KhachHang khachHang = null;
	ArrayList<DatDia> dsDiaGanChoKhach = new ArrayList<>();
	
	public HuyDatDia() {
		setLayout(null);
		JPanel panel = new JPanel();
		panel.setBackground(Color.WHITE);
		panel.setBounds(0, 0, 1200, 588);
		setBounds(0, 0, 1200, 588);
		add(panel);
		panel.setLayout(null);
		
		JPanel pnTitle = new JPanel();
		pnTitle.setBounds(0, 0, 1200, 35);
		pnTitle.setBackground(Color.CYAN);
		
		pnTitle.add(lblTitle = new JLabel("HỦY ĐẶT ĐĨA"));
		lblTitle.setFont(new Font("Segoe UI", Font.BOLD, 18));
		panel.add(pnTitle);
		
		txtTim = new JTextField();
		txtTim.setBounds(10, 60, 690, 34);
		txtTim.setText("Nhập thông tin khách hàng để tìm đĩa gán...");
		txtTim.setForeground(Color.LIGHT_GRAY);
		txtTim.setFont(new Font("Segoe UI", Font.BOLD, 15));
		txtTim.setColumns(10);
		txtTim.setForeground(Color.decode("#9E9E9E"));
		panel.add(txtTim);
		
		panel.add(scrollTimKiemDiaDat = new JScrollPane());
		scrollTimKiemDiaDat.setBounds(10, 96, 690, 100);
		modelList = new DefaultListModel<>();
		dsKhachHang = new JList<>();
		dsKhachHang.setModel(modelList);
		dsKhachHang.setFont(new Font("Segoe UI", Font.PLAIN, 15));
		dsKhachHang.setSelectionMode(ListSelectionModel.SINGLE_SELECTION);
		scrollTimKiemDiaDat.setViewportView(dsKhachHang);
		scrollTimKiemDiaDat.setVisible(false);
		
		panel.add(btnTim = new JButton("Kiểm tra"));
		btnTim.setContentAreaFilled(false);
		btnTim.setOpaque(true);
		btnTim.setForeground(Color.white);
		btnTim.setBorder(null);
		btnTim.setBackground(Color.decode("#4CAF50"));
		btnTim.setCursor(new Cursor(Cursor.HAND_CURSOR));
		btnTim.setFont(new Font("Segoe UI", Font.BOLD, 15));
		btnTim.setBounds(720, 56, 155, 41);
		
		panel.add(btnHuyDat = new JButton("Hủy đặt"));
		btnHuyDat.setContentAreaFilled(false);
		btnHuyDat.setOpaque(true);
		btnHuyDat.setForeground(Color.white);
		btnHuyDat.setBorder(null);
		btnHuyDat.setCursor(new Cursor(Cursor.HAND_CURSOR));
		btnHuyDat.setFont(new Font("Segoe UI", Font.BOLD, 15));
		btnHuyDat.setBackground(Color.decode("#C2C018"));
		btnHuyDat.setBounds(915, 56, 155, 41);
		
		JScrollPane scrollPane = new JScrollPane();
		scrollPane.setBounds(10, 108, 1180, 469);
		panel.add(scrollPane);
		
		tableDiaDat = new JTable() {

			public Component prepareRenderer( TableCellRenderer renderer, int row, int col ) {
		        Component c = super.prepareRenderer(renderer, row, col);
		        c.setFont(new Font("Segoe UI", Font.BOLD, 15));
		        if ( row % 2 == 0 && !isCellSelected(row, col)) {
		            c.setBackground( Color.white );
		        }
		        else 
		        	if(!isCellSelected(row, col)){
		        		c.setBackground( Color.decode("#F1F1F1") );
		        	}else {
		        		c.setBackground(Color.decode("#009FFF"));
		        	}
		        if( isRowSelected(row) || (row == rollOverRowIndex) ) {
		        	c.setForeground(Color.black);
		            c.setBackground(Color.decode("#A9DFFF"));
		        }
		        else {
		            c.setBackground(getBackground());
		        }
		        return c;
		        
		    }
		};
		tableDiaDat.setBorder(null);
		tableDiaDat.setFillsViewportHeight(true);
		tableDiaDat.setShowGrid(false);
		tableDiaDat.setIntercellSpacing(new Dimension(0, 5));
		
		JTableHeader header = tableDiaDat.getTableHeader();
		header.setBackground(Color.decode("#007ECA"));
		header.setForeground(Color.white);
		header.setOpaque(false);
		
		tableDiaDat.setModel(tableModel = new DefaultTableModel(
			new Object[][] {
		
			},
			new String[] {
					"Avatar", "Mã đĩa", "Tên Tựa", "Loại", "Khách hàng", "Số điện thoại"
			}
		){
			boolean[] columnEditables = new boolean[] {
					false, false, false, false, false, false, false,false
			};
			public boolean isCellEditable(int row, int column) {
				return columnEditables[column];
			}
			  @SuppressWarnings({ "unchecked", "rawtypes" })
			public Class getColumnClass(int column) {
			        return (column == 0) ? Icon.class : Object.class;
			      }
		
		});
		tableDiaDat.setPreferredScrollableViewportSize(tableDiaDat.getPreferredSize());
		scrollPane.setViewportView(tableDiaDat);        
		tableDiaDat.setRowHeight(280);
		tableDiaDat.getColumnModel().getColumn(0).setPreferredWidth(81);
		tableDiaDat.setSelectionMode(ListSelectionModel.SINGLE_SELECTION);
		tableDiaDat.getTableHeader().setReorderingAllowed(false);
//		DefaultTableCellRenderer centerRenderer = new DefaultTableCellRenderer();
//		centerRenderer.setHorizontalAlignment(JLabel.CENTER );
//		tableDiaDat.getColumnModel().getColumn(2).setCellRenderer( centerRenderer );
		
		btnTim.setEnabled(false);
		btnHuyDat.setEnabled(false);
		
		btnTim.addActionListener(this);
		btnHuyDat.addActionListener(this);
		txtTim.addFocusListener(this);
		txtTim.addKeyListener(this);
		dsKhachHang.addMouseListener(this);
		this.addMouseListener(this);
		
		dsDiaGanChoKhach = datDiaCon.getAllKhachHangDatDia();
		duaDuLieuVaoTable(dsDiaGanChoKhach);
	}
	
	public void duaKhachHangVaoJList(ArrayList<KhachHang> list) {
		for (KhachHang kh : list) {
			modelList.addElement(kh);
			dsKhachHang.setSelectedIndex(0);
		}
	}
	
	public void chonKhachHangTrongJList() {
		khachHang = dsKhachHang.getSelectedValue();
		txtTim.setText(khachHang.getIdkh());
		scrollTimKiemDiaDat.setVisible(false);
		btnTim.setEnabled(true);
	}
	
	public void duaDuLieuVaoTable(ArrayList<DatDia> list) {
		tableModel.setNumRows(0);
		for (DatDia datDia : list) {
			ImageIcon img = new ImageIcon(new ImageIcon("images/"+datDia.getTuadia().getAnh()).getImage().getScaledInstance(170, 280, Image.SCALE_AREA_AVERAGING));
			Object[] array = {img, "Chờ gán đĩa", datDia.getTuadia().getTentua(), datDia.getTuadia().getLoaidia().getTenloaidia(),
								datDia.getKh().getTenkh(), datDia.getKh().getSodt()};
			if(datDia.getGanDia() != null)
				array[1] = datDia.getGanDia().getMadia();
			
			tableModel.addRow(array);
		}
	}
	
	public void kiemTraDiaKhachHangDat() {
		tableModel.setNumRows(0);
		if(txtTim.getText().equals("") && txtTim.getText().equals("Nhập thông tin khách hàng để tìm đĩa gán...")) {
			JOptionPane.showMessageDialog(this, "Chưa nhập thông tin để kiểm tra");
			txtTim.requestFocus();
			return;
		}
		
		dsDiaGanChoKhach = datDiaCon.timKhachHangDaDatDia(khachHang);
		if(dsDiaGanChoKhach.size() > 0) {
			duaDuLieuVaoTable(dsDiaGanChoKhach);
			btnHuyDat.setEnabled(true);
		}
		else {
			JOptionPane.showMessageDialog(this, "Khách hàng này chưa đặt đĩa");
			txtTim.selectAll();
			txtTim.requestFocus();
			btnHuyDat.setEnabled(false);
		}
	}
	
	public boolean timKhachHang(String ttTim) {
		ArrayList<KhachHang> arrKhachHang = new ArrayList<>();
		arrKhachHang = khCon.timKhachHang(ttTim);
		if(arrKhachHang.size() > 0) {
			modelList.removeAllElements();
			duaKhachHangVaoJList(arrKhachHang);
			return true;
		}
		return false;
	}
	
	/**
	 * Sử dụng đệ quy để tìm khách hàng đặt đĩa
	 * @param tuaDia
	 */
	public void ktDiaDatTruoc(Dia diaHuy) {

		DatDia datdia = datDiaCon.getKhachHangDatDiaDauTien(diaHuy.getTuadia().getTentua());
		
		if(datdia != null) {
			if(JOptionPane.showConfirmDialog(this, "Liên hệ: " + datdia.getKh().getTenkh() + " -> Số điện thoại: " + datdia.getKh().getSodt()
				+ "\nCó muốn đặt Tựa: " + datdia.getTuadia().getTentua() + " hay không?", "Thông báo có khách đặt đĩa", JOptionPane.YES_NO_OPTION) == JOptionPane.YES_OPTION) {
				
				// Xem lại việc gán đĩa
			
				datdia.setGanDia(diaHuy);
				datDiaCon.ganDiaChoKhachHang(datdia);
				
				JOptionPane.showMessageDialog(this, "Đĩa đã được giữ lại cho khách hàng " + datdia.getKh().getTenkh());
				
				coKhachDatDia = true;
			}
			else {
				// Nếu khách hàng không đồng ý thì xóa đặt đĩa của khách hàng này
				datDiaCon.xoaDatDia(datdia.getKh().getIdkh(), datdia.getTuadia().getMatua());
				ktDiaDatTruoc(diaHuy);
			}
		}
	}
	
	public void huyDiaDatDat() {
		int row = tableDiaDat.getSelectedRow();
		if(row != -1) {
			tableModel.removeRow(row);
			datDiaCon.xoaDatDia(khachHang.getIdkh(), dsDiaGanChoKhach.get(row).getTuadia().getMatua());
			JOptionPane.showMessageDialog(this, "Đã hủy thành công đĩa khách hàng đã đặt");
			
			Dia diaHuy = dsDiaGanChoKhach.get(row).getGanDia();
			
			//nếu khách hàng này đã được gán đĩa thì thực hiện gán đĩa cho khách hàng tiếp theo
			if (diaHuy!=null) {
				ktDiaDatTruoc(diaHuy);
				
				if(coKhachDatDia == false)
					diaHuy.setTrangthai("S");
				else
					diaHuy.setTrangthai("H");
				
				DiaControl diacon = new DiaControl();
				diacon.capnhatThongTinDia(diaHuy);
				coKhachDatDia = false;
			}
		}
		else
			JOptionPane.showMessageDialog(this, "Chưa chọn đĩa cần hủy");
	}

	@Override
	public void actionPerformed(ActionEvent e) {
		Object ob = e.getSource();
		
		if(ob == btnTim)
			kiemTraDiaKhachHangDat();
		else if(ob == btnHuyDat)
			huyDiaDatDat();
	}
	
	@Override
	public void keyPressed(KeyEvent e) {
		if(e.getKeyCode() == KeyEvent.VK_ENTER) {
			if(!txtTim.getText().equals("")) {
				if(dsKhachHang.getSelectedIndex() != -1)
					chonKhachHangTrongJList();
			}
				
		}
	}

	@Override
	public void keyReleased(KeyEvent e) {
		Object ob = e.getSource();
		
		if(ob == txtTim) {
			if(!txtTim.getText().equals("")) {
				boolean bTimKH = timKhachHang(txtTim.getText());
				if(bTimKH == true)
					scrollTimKiemDiaDat.setVisible(true);
				else {
					scrollTimKiemDiaDat.setVisible(false);
					btnTim.setEnabled(false);
				}
			}
			else {
				dsDiaGanChoKhach = datDiaCon.getAllKhachHangDatDia();
				duaDuLieuVaoTable(dsDiaGanChoKhach);
				scrollTimKiemDiaDat.setVisible(false);
				btnTim.setEnabled(false);
			}
		}
	}

	@Override
	public void keyTyped(KeyEvent e) {
		// TODO Auto-generated method stub
		
	}

	@Override
	public void mouseClicked(MouseEvent e) {
		Object ob = e.getSource();
		if(ob == dsKhachHang) {
			int row = dsKhachHang.getSelectedIndex();
			if(row != -1)
				chonKhachHangTrongJList();
		}
		else {
			scrollTimKiemDiaDat.setVisible(false);
		}
	}

	@Override
	public void mouseEntered(MouseEvent e) {
		// TODO Auto-generated method stub
		
	}

	@Override
	public void mouseExited(MouseEvent e) {
		// TODO Auto-generated method stub
		
	}

	@Override
	public void mousePressed(MouseEvent e) {
		// TODO Auto-generated method stub
		
	}

	@Override
	public void mouseReleased(MouseEvent e) {
		// TODO Auto-generated method stub
		
	}

	@Override
	public void focusGained(FocusEvent e) {
		if(e.getSource() == txtTim) {
			if(txtTim.getText().equals("Nhập thông tin khách hàng để tìm đĩa gán...")) {
				txtTim.setText("");
				txtTim.setForeground(Color.black);
			}
		}
	}

	@Override
	public void focusLost(FocusEvent e) {
		if(e.getSource() == txtTim) {
			if(txtTim.getText().equals("")) {
				txtTim.setText("Nhập thông tin khách hàng để tìm đĩa gán...");
				txtTim.setForeground(Color.LIGHT_GRAY);
			}
		}
	}
}
