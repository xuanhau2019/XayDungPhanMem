package gui;

import java.awt.BorderLayout;
import java.awt.Color;
import java.awt.Component;
import java.awt.Font;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.util.ArrayList;

import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.JScrollPane;
import javax.swing.JTable;
import javax.swing.table.DefaultTableModel;
import javax.swing.table.JTableHeader;
import javax.swing.table.TableCellRenderer;

import entities.Dia;

@SuppressWarnings("serial")
public class Form_XemTrangThaiDia extends JFrame implements ActionListener {

	JLabel lblTD;
	JButton btnOk;
	DefaultTableModel modDia;
	JTable tabDia;

	public Form_XemTrangThaiDia(ArrayList<Dia> array) {
		setTitle("Trạng thái đĩa");
		setSize(500,400);
		setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
		setLocationRelativeTo(null);
		setResizable(false);
		
		// Tạo frame trạng thái đĩa
		JPanel pNorth = new JPanel();
		pNorth.setBackground(Color.CYAN);
		pNorth.add(lblTD = new JLabel("Xem các bản sao của tựa " + array.get(0).getTuadia().getTentua()));
		lblTD.setFont(new Font("Calibri Light", Font.BOLD, 25));
		add(pNorth, BorderLayout.NORTH);

		JPanel pCenter = new JPanel();
		pCenter.setLayout(new BorderLayout());
		String[] arr1 = {"STT", "Mã đĩa", "Loại đĩa", "Trạng thái"};
		modDia = new DefaultTableModel(arr1, 0);
		tabDia = new JTable(modDia) {
			public boolean isCellEditable(int rowIndex, int colIndex) {
				return false;   //Disallow the editing of any cell
			}
			// Chỉnh màu cho body table
			public Component prepareRenderer(TableCellRenderer renderer, int row, int col) {
				Component c = super.prepareRenderer(renderer, row, col);
				if(row % 2 == 0 && !isCellSelected(row,col))
					c.setBackground(Color.decode("#F1F1F1"));
				else
					if(!isCellSelected(row,col))
						c.setBackground(Color.decode("#D7F1FF"));
					else
						c.setBackground(Color.decode("#25C883"));
				return c;
			}
		};
		// Chỉnh màu cho tiêu đề table
		JTableHeader header2 = tabDia.getTableHeader();
		header2.setBackground(Color.decode("#007ECA"));
		header2.setForeground(Color.WHITE);
		header2.setFont(new Font("Calibri Light", Font.ITALIC, 16));
		header2.setOpaque(false);

		tabDia.setRowHeight(25);
		tabDia.getColumnModel().getColumn(0).setPreferredWidth(1);
		tabDia.setAutoCreateRowSorter(true);					// sắp xếp
		JScrollPane scoll1 = new JScrollPane(tabDia);
		pCenter.add(scoll1);
		add(pCenter, BorderLayout.CENTER);

		JPanel pSouth = new JPanel();
		pSouth.add(btnOk = new JButton("  OK  "));
		add(pSouth, BorderLayout.SOUTH);

		duaThongTinDiaVaoTable(array);
		
		btnOk.addActionListener(this);
	}

	public void duaThongTinDiaVaoTable(ArrayList<Dia> list) {
		int i = 0;
		String trangthai = "";
		for (Dia dia : list) {
			if(dia.getTrangthai().equals("S"))
				trangthai = "Trên kệ";
			else if(dia.getTrangthai().equals("H"))
				trangthai = "Giữ cho khách";
			else
				trangthai = "Đã thuê";
			String[] a = {Integer.toString(i + 1), dia.getMadia(), dia.getTuadia().getLoaidia().getTenloaidia(),trangthai};
			modDia.addRow(a);
			i++;
		}
	}

	@Override
	public void actionPerformed(ActionEvent e) {
		if(e.getSource() == btnOk)
			this.dispose();
	}
}
