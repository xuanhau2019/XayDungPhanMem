package gui;

import java.awt.BorderLayout;
import java.awt.Color;
import java.awt.Component;
import java.awt.Cursor;
import java.awt.Dimension;
import java.awt.Font;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.FocusEvent;
import java.awt.event.FocusListener;
import java.awt.event.MouseEvent;
import java.awt.event.MouseListener;
import java.text.DecimalFormat;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;

import javax.swing.Box;
import javax.swing.ImageIcon;
import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.JScrollPane;
import javax.swing.JTable;
import javax.swing.JTextField;
import javax.swing.table.DefaultTableModel;
import javax.swing.table.JTableHeader;
import javax.swing.table.TableCellRenderer;

import control.KhachHangControl;
import control.PhiTreHanControl;
import control.PhieuThueControl;
import control.ThanhToanTreHanControl;
import entities.ChiTietPhieuThue;
import entities.KhachHang;
import entities.PhiTreHan;
import entities.ThanhToanTreHan;

@SuppressWarnings("serial")
public class ThanhToanPhiTreHan extends JPanel implements ActionListener, MouseListener, FocusListener {

	JLabel lblTD, lblTenKH, lblSodt, lblDiaChi, lblTongTien;
	JLabel lblgtTenKH, lblgtSodt, lblgtDiachi;
	JTextField txtTim, txtTongTien;
	JButton btnTT, btnXoaPhiTreHan, btnXemChiTiet, btnTim, btnCapNhat;
	DefaultTableModel modPTreHan;
	JTable tabPTreHan;

	PhiTreHanControl ptreCon = new PhiTreHanControl();
	ThanhToanTreHanControl ttTreHanCon = new ThanhToanTreHanControl();
	KhachHangControl khachHangCon = new KhachHangControl();
	
	double sumTien = 0;
	ArrayList<PhiTreHan> listPhiTreHan = new ArrayList<>();
	DecimalFormat dmf = new DecimalFormat("#,##0");
	SimpleDateFormat sd = new SimpleDateFormat("yyyy-MM-dd");
	
	JFrame jframe;

	GUIChinh guiChinh;
	
	public ThanhToanPhiTreHan(GUIChinh guichinh) {
		setLayout(null);
		JPanel panel = new JPanel();
		panel.setBounds(0, 0, 1200, 588);
		setBounds(0, 0, 1200, 588);
		add(panel);
		this.guiChinh = guichinh;

		// Tạo frame thanh toán
		JPanel pNorth = new JPanel();
		pNorth.setBackground(Color.CYAN);
		pNorth.setLayout(new BorderLayout());
		pNorth.setPreferredSize(new Dimension(1200, 35));
		pNorth.add(lblTD = new JLabel("THANH TOÁN PHÍ TRỄ HẠN", JLabel.CENTER));
		lblTD.setFont(new Font("Calibri Light", Font.BOLD, 25));
		panel.add(pNorth, BorderLayout.NORTH);

		JPanel pnCenter = new JPanel();
		pnCenter.setLayout(new BorderLayout());
		pnCenter.setPreferredSize(new Dimension(1200, 400));
		
		JPanel pnCenNorth = new JPanel();
		pnCenNorth.setLayout(new BorderLayout());
		pnCenNorth.setPreferredSize(new Dimension(1200, 60));
		JPanel pnContain = new JPanel();
		pnContain.setLayout(null);
		txtTim = new JTextField();
		txtTim.setBounds(10, 10, 690, 34);
		txtTim.setText("Nhập ID khách hàng để tìm phí trễ hạn...");
		txtTim.setForeground(Color.LIGHT_GRAY);
		txtTim.setFont(new Font("Segoe UI", Font.BOLD, 15));
		txtTim.setColumns(10);
		txtTim.setForeground(Color.decode("#9E9E9E"));
		pnContain.add(txtTim);
		pnContain.add(btnTim = new JButton("Tìm khiếm"));
		btnTim.setContentAreaFilled(false);
		btnTim.setOpaque(true);
		btnTim.setForeground(Color.white);
		btnTim.setBorder(null);
		btnTim.setBackground(Color.decode("#4CAF50"));
		btnTim.setCursor(new Cursor(Cursor.HAND_CURSOR));
		btnTim.setFont(new Font("Segoe UI", Font.BOLD, 15));
		btnTim.setBounds(720, 6, 155, 40);
		pnContain.add(btnCapNhat = new JButton("Cập nhật"));
		btnCapNhat.setContentAreaFilled(false);
		btnCapNhat.setOpaque(true);
		btnCapNhat.setForeground(Color.white);
		btnCapNhat.setBorder(null);
		btnCapNhat.setCursor(new Cursor(Cursor.HAND_CURSOR));
		btnCapNhat.setFont(new Font("Segoe UI", Font.BOLD, 15));
		btnCapNhat.setBackground(Color.decode("#C2C018"));
		btnCapNhat.setBounds(915, 6, 155, 41);
		
		pnCenNorth.add(pnContain);
		pnCenter.add(pnCenNorth, BorderLayout.NORTH);
		
		JPanel pnCenMid = new JPanel();
		pnCenMid.setLayout(new BorderLayout());
		String[] tieude = {"STT", "Mã trễ hạn", "Khách hàng", "Số điện thoại", "Mã đĩa", "Tựa đĩa", "Tiền nợ"};
		modPTreHan = new DefaultTableModel(tieude, 0);
		tabPTreHan = new JTable(modPTreHan) {
			public boolean isCellEditable(int rowIndex, int colIndex) {
				return false;   //Disallow the editing of any cell
			}
			// Chỉnh màu cho body table
			public Component prepareRenderer(TableCellRenderer renderer, int row, int col) {
				Component c = super.prepareRenderer(renderer, row, col);
				if(row % 2 == 0 && !isCellSelected(row,col))
					c.setBackground(Color.decode("#F1F1F1"));
				else
					if(!isCellSelected(row,col))
						c.setBackground(Color.decode("#D7F1FF"));
					else
						c.setBackground(Color.decode("#25C883"));
				return c;
			}
		};
		// Chỉnh màu cho tiêu đề table
		JTableHeader header2 = tabPTreHan.getTableHeader();
		header2.setBackground(Color.decode("#007ECA"));
		header2.setForeground(Color.WHITE);
		header2.setFont(new Font("Calibri Light", Font.ITALIC, 16));
		header2.setOpaque(false);

		tabPTreHan.setRowHeight(25);
		tabPTreHan.getColumnModel().getColumn(0).setPreferredWidth(-10);
		tabPTreHan.setAutoCreateRowSorter(true);					// sắp xếp
		JScrollPane scoll1 = new JScrollPane(tabPTreHan);
		pnCenMid.add(scoll1, BorderLayout.CENTER);
		pnCenter.add(pnCenMid, BorderLayout.CENTER);
		
		panel.add(pnCenter, BorderLayout.CENTER);

		JPanel pSouth = new JPanel();
//		pSouth.setLayout(new BorderLayout());
		Box bSou = Box.createVerticalBox();
		bSou.add(Box.createVerticalStrut(10));
		Box b8, b9;
		bSou.add(b8 = Box.createHorizontalBox());
		b8.add(Box.createVerticalStrut(15));
		b8.add(Box.createHorizontalStrut(740));
		b8.add(lblTongTien = new JLabel("Tổng tiền khách hàng nợ"));
		lblTongTien.setFont(new Font("Segoe UI", Font.BOLD, 15));
		b8.add(Box.createHorizontalStrut(15));
		b8.add(txtTongTien = new JTextField(15));
		txtTongTien.setPreferredSize(new Dimension(0, 30));
		txtTongTien.setEditable(false);
		txtTongTien.setText("0");
		txtTongTien.setFont(new Font("Segoe UI", Font.BOLD, 12));
		b8.add(Box.createHorizontalStrut(20));
		JLabel lblDonViVND = new JLabel("VND");
		b8.add(lblDonViVND);
		lblDonViVND.setFont(new Font("Segoe UI", Font.BOLD, 15));
		b8.add(Box.createHorizontalStrut(2));
		bSou.add(Box.createVerticalStrut(20));
		bSou.add(b9 = Box.createHorizontalBox());
		b9.add(Box.createHorizontalStrut(330));
		b9.add(btnTT = new JButton("Thanh toán", new ImageIcon("images/thanhtoan.png")));
		b9.add(Box.createHorizontalStrut(30));
		b9.add(btnXemChiTiet = new JButton(new ImageIcon("images/chitiet.png")));
		b9.add(Box.createHorizontalStrut(30));
		b9.add(btnXoaPhiTreHan = new JButton("Xóa phí trễ hạn", new ImageIcon("images/cancal.png")));
		b9.add(Box.createVerticalStrut(5));
		btnTT.setPreferredSize(new Dimension(150, 100));
		btnXemChiTiet.setPreferredSize(btnTT.getPreferredSize());
		btnXoaPhiTreHan.setPreferredSize(btnTT.getPreferredSize());
		pSouth.add(bSou);
		panel.add(pSouth, BorderLayout.SOUTH);

		btnCapNhat.addActionListener(this);
		btnTim.addActionListener(this);
		btnTT.addActionListener(this);
		btnXoaPhiTreHan.addActionListener(this);
		btnXemChiTiet.addActionListener(this);
		tabPTreHan.addMouseListener(this);
		txtTim.addFocusListener(this);

		lamMoiDuLieu();
	}
	
	public void lamMoiDuLieu() {
		modPTreHan.setNumRows(0);
		listPhiTreHan = ptreCon.layTatCaPhiTreHan();
		duaPhiTreHanVaoTable(listPhiTreHan);
	}
	
	public void duaPhiTreHanVaoTable(ArrayList<PhiTreHan> list) {
		modPTreHan.setNumRows(0);
		sumTien = 0;
		
		if(list.size() > 0) {
			PhieuThueControl pthueCon = new PhieuThueControl();
			PhiTreHan ptre = new PhiTreHan();
			ChiTietPhieuThue ctpt = new ChiTietPhieuThue();
			KhachHang kh = null;
			
			for(int i =  0; i < list.size(); i++) {
				ptre = list.get(i);
				kh = ptre.getPhieutra().getPhieuthue().getKh();
				ctpt = pthueCon.timChiTietPhieuThue(ptre.getPhieutra().getPhieuthue(),ptre.getPhieutra().getDia()).get(0);
				String[] a = {Integer.toString(i + 1), ptre.getMatrehan(), kh.getTenkh(), kh.getSodt(), ctpt.getDia().getMadia(),
								ctpt.getDia().getTuadia().getTentua(), dmf.format(ptre.getTienno())};
				modPTreHan.addRow(a);
				sumTien += ptre.getTienno();
			}
		}
		
		txtTongTien.setText(dmf.format(sumTien));
	}
	
	public void timPhiTreHanCuaKhachHang() {
		if(txtTim.getText().equals("") || txtTim.getText().equals("Nhập ID khách hàng để tìm phí trễ hạn...")) {
			JOptionPane.showMessageDialog(this, "Chưa nhập số ID của khách hàng");
			txtTim.requestFocus();
		}
		else {
			KhachHang kh = khachHangCon.timKhachHangTheoID(txtTim.getText());
			if(kh != null) {
				listPhiTreHan = ptreCon.layPhiTreHanCuaKhachHang(kh.getIdkh());
				if(listPhiTreHan.size() > 0) {
					modPTreHan.setNumRows(0);
					duaPhiTreHanVaoTable(listPhiTreHan);
				}
				else {
					JOptionPane.showMessageDialog(this, "Khách hàng này khống có phí trễ hạn");
					txtTim.selectAll();
					txtTim.requestFocus();
				}
			}
			else {
				JOptionPane.showMessageDialog(this, "Số ID khách hàng không đúng");
				txtTim.selectAll();
				txtTim.requestFocus();
			}
		}
	}
	
	// Tự động cấp mã thanh toán
		public String capnhatMaThanhToanTreHan() {
			String matt = ttTreHanCon.getLastMaThanhToanTreHan();
			if(matt == null)
				matt = "TT_0000001";
			else {
				int stt = Integer.parseInt(matt.replaceAll("TT_", "")) + 1;
				if(stt < 10)
					matt = "TT_000000" + stt;
				else if(stt < 100)
					matt = "TT_00000" + stt;
				else if(stt < 1000)
					matt = "TT_0000" + stt;
				else if(stt < 10000)
					matt = "TT_000" + stt;
				else if(stt < 100000)
					matt = "TT_00" + stt;
				else if(stt < 1000000)
					matt = "TT_0" + stt;
				else
					matt = "TT_" + stt;
			}
			return matt;
		}
		
		// Xóa phí trễ hạn trong mảng tạm và bảng
		public void xoaPhiTreHanDaThanhToan(int n) {
			listPhiTreHan.remove(n);
			modPTreHan.removeRow(n);
		}
		
		public void clickXemChiTiet() {
			int row = tabPTreHan.getSelectedRow();
			if(row != -1)
				new Form_XemChiTietPhiTreHan(tabPTreHan.getValueAt(row, 1).toString()).setVisible(true);
			else
				JOptionPane.showMessageDialog(this, "Chưa chọn phí trễ hạn");
		}
		
		public void xoaPhiTreHanChoKhachHang() {
			int[] rows = tabPTreHan.getSelectedRows();
			if(rows.length > 0) {
				
				int n = rows.length, dem = 0;
				String matrehan = "";
				for (int i = 0; i < n; i++) {
					matrehan = tabPTreHan.getValueAt(rows[i] - dem, 1).toString();
					
					ptreCon.xoaPhiTreHanChoKhachHang(matrehan);

					xoaPhiTreHanDaThanhToan(rows[i] - dem);
					dem++;
				}
				duaPhiTreHanVaoTable(listPhiTreHan);
				JOptionPane.showMessageDialog(this, "Đã xóa thành công phí trễ hạn của khách hàng");
			}
			else
				JOptionPane.showMessageDialog(this, "Chưa chọn phí trễ hạn để xóa");
		}
		
		@Override
		public void actionPerformed(ActionEvent e) {
			Object ob = e.getSource();
			if(ob == btnTT) {			
				int[] rows = tabPTreHan.getSelectedRows();
				if(rows.length > 0) {
					
					int n = rows.length, dem = 0;
					String matrehan = "";
					for (int i = 0; i < n; i++) {
						matrehan = tabPTreHan.getValueAt(rows[i] - dem, 1).toString();
						PhiTreHan ptre = ptreCon.timPhiTreHan(matrehan);
						ThanhToanTreHan tt = new ThanhToanTreHan(capnhatMaThanhToanTreHan(), ptre, new Date());
						ttTreHanCon.themThanhToanTreHan(tt);
						
						xoaPhiTreHanDaThanhToan(rows[i] - dem);
						dem++;
					}
					duaPhiTreHanVaoTable(listPhiTreHan);
					JOptionPane.showMessageDialog(this, "Thanh toán thành công");
				}
				else
					JOptionPane.showMessageDialog(this, "Chưa chọn phí trễ hạn để thanh toán");
			}
			else if(ob == btnXoaPhiTreHan) {
				
				if (GUIChinh.user == null) {
					new DangNhap(jframe).setVisible(true);
				}else {
					xoaPhiTreHanChoKhachHang();
				}
			}
			else if(ob == btnXemChiTiet)
				clickXemChiTiet();
			else if(ob == btnCapNhat)
				lamMoiDuLieu();
			else if(ob == btnTim)
				timPhiTreHanCuaKhachHang();
		}

		@Override
		public void mouseClicked(MouseEvent e) {
			int[] rows = tabPTreHan.getSelectedRows();
			double sum = 0;
			if(rows.length > 0) {
				double tienno = 0;
				for (int i = 0; i < rows.length; i++) {
					tienno = Double.parseDouble(tabPTreHan.getValueAt(rows[i], 6).toString().replaceAll(",", ""));
					sum += tienno;
				}
				txtTongTien.setText(dmf.format(sum));
			}
			else
				txtTongTien.setText(dmf.format(sumTien));
			
			if(e.getClickCount() == 2) {
				int row = tabPTreHan.getSelectedRow();
				if(row != -1)
					new Form_XemChiTietPhiTreHan(tabPTreHan.getValueAt(row, 1).toString()).setVisible(true);
				else
					JOptionPane.showMessageDialog(this, "Chưa chọn phí trễ hạn");
			}
		}

	@Override
	public void mouseEntered(MouseEvent e) {
		// TODO Auto-generated method stub

	}

	@Override
	public void mouseExited(MouseEvent e) {
		// TODO Auto-generated method stub

	}

	@Override
	public void mousePressed(MouseEvent e) {
		// TODO Auto-generated method stub

	}

	@Override
	public void mouseReleased(MouseEvent e) {
		// TODO Auto-generated method stub

	}

	@Override
	public void focusGained(FocusEvent e) {
		if(e.getSource() == txtTim) {
			if(txtTim.getText().equals("Nhập ID khách hàng để tìm phí trễ hạn...")) {
				txtTim.setText("");
				txtTim.setForeground(Color.black);
			}
		}
	}

	@Override
	public void focusLost(FocusEvent e) {
		if(e.getSource() == txtTim) {
			if(txtTim.getText().equals("")) {
				txtTim.setText("Nhập ID khách hàng để tìm phí trễ hạn...");
				txtTim.setForeground(Color.LIGHT_GRAY);
			}
		}
	}
}
