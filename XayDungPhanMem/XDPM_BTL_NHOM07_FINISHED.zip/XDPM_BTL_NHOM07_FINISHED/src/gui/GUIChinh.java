package gui;

import java.awt.Color;
import java.awt.Cursor;
import java.awt.Dimension;
import java.awt.Font;
import java.awt.Image;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.KeyEvent;
import java.awt.event.KeyListener;
import java.awt.event.MouseEvent;
import java.awt.event.MouseListener;
import java.util.ArrayList;

import javax.swing.BorderFactory;
import javax.swing.ImageIcon;
import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JMenu;
import javax.swing.JMenuBar;
import javax.swing.JMenuItem;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.JTextField;
import javax.swing.border.Border;
import javax.swing.border.LineBorder;

import control.DiaControl;
import entities.Dia;
import entities.TaiKhoan;

public class GUIChinh extends JFrame implements ActionListener, MouseListener, KeyListener {

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;	

	private JPanel panelMenu;
	private JPanel panelQuickIcon;
	private JPanel pnMain;

	private JMenuBar menuBar;

	public static JMenu mnTuyChon;
	private JMenu mnQuanLyDia;
	private JMenu mnQuanLyTua;
	private JMenu mnQuanLyThueDia;
	private JMenu mnKhachHang;
	private JMenu mnThanhToanTreHan;
	private JMenu mnThongKe;
	private JMenu mnCapNhatLoaiDia;

	private JMenuItem mntmThoat;
	public static JMenuItem mntmDangXuat;
	private JMenuItem mntmChoThueDia;
	private JMenuItem mntmDatDia;
	private JMenuItem mntmHuyDatDia;
	private JMenuItem mntmtra;
	private JMenuItem mntmCapNhatGia;
	private JMenuItem mntmCapNhatHan;

	private JLabel iconHome;
	private JLabel iconAddKH;
	private JLabel iconThueDia;
	private JLabel iconTraDia;
	JLabel lblBackGround;

	private QuanLyKhachHang quanLyKhachHang = new QuanLyKhachHang(this);

	private JMenuItem mntmTkTuaDia;
	private JMenuItem mntmTkKHAll;
	private JMenuItem mntmTkKhNoTien;
	private JMenuItem mntmTkKHNoDia;

	private JTextField txtTimTua;
	private JButton btnTimTua;

	public static TaiKhoan user = null;
//	JList<TuaDia> dsTuaDia;
//	DefaultListModel<TuaDia> modelList;
//	JScrollPane scrollTimKiemTua;
	
	public static final int THONGKETATCAKHACHHANG = 1;
	public static final int THONGKEKHACHHANGCOPHITREHAN = 2;
	public static final int THONGKEKHACHHANGCODIATREHAN = 3;
	
	// Resize image
	public ImageIcon resizeImage(String imgPath, byte[] pic) {
		ImageIcon myImage = null;
		if (imgPath != null) {
			myImage = new ImageIcon(imgPath);
		}
		else {
			myImage = new ImageIcon(pic);
		}

		Image img1 = myImage.getImage();
		Image img2 = img1.getScaledInstance(lblBackGround.getWidth(), lblBackGround.getHeight(), Image.SCALE_SMOOTH);
		ImageIcon image = new ImageIcon(img2);
		return image;
	}

	public GUIChinh() {
		setTitle("Phần mềm cho thuê băng đĩa");
		setDefaultCloseOperation(EXIT_ON_CLOSE);
		
		pnMain = panelMain();
		createJFrameMain(pnMain);
	}
	
	public JPanel panelMain() {
		JPanel pnContain = new JPanel();
		pnContain.setLayout(null);
		pnContain.setBounds(0, 0, 1200, 788);
		pnContain.add(lblBackGround = new JLabel());
		lblBackGround.setBounds(0, 0, 1200, 590);
		lblBackGround.setIcon(resizeImage("images/guichinh/background/guiChinh.png", null));
		
		return pnContain;
	}

	public void createJFrameMain(JPanel panelMain) {

		setSize(1200, 700);
		setLocationRelativeTo(null);
		setDefaultCloseOperation(EXIT_ON_CLOSE);
		setResizable(false);
		getContentPane().setLayout(null);

		panelMenu = new JPanel();
		panelMenu.setBounds(0, 0, 1200, 35);
		getContentPane().add(panelMenu);
		panelMenu.setLayout(null);

		menuBar = new JMenuBar();
		menuBar.setBounds(0, 0, 1200, 35);
		panelMenu.add(menuBar);

		mnTuyChon = new JMenu();
		mnTuyChon.setIcon(new ImageIcon("images/guichinh/menubar/tuychon.png"));
		mnTuyChon.setOpaque(true);
		mnTuyChon.setForeground(new Color(0, 102, 204));
		mnTuyChon.setFont(new Font("Segoe UI Semibold", Font.PLAIN, 15));
		mnTuyChon.setBackground(new Color(233, 255, 255));
		menuBar.add(mnTuyChon);

		mntmDangXuat = new JMenuItem("Đăng xuất");
		mntmDangXuat.setPreferredSize(new Dimension(120, 25));
		mnTuyChon.add(mntmDangXuat);
		mntmThoat = new JMenuItem("Thoát");
		mntmThoat.setPreferredSize(new Dimension(120, 25));
		mnTuyChon.add(mntmThoat);

		mnKhachHang = new JMenu("Khách Hàng");
		mnKhachHang.setIcon(new ImageIcon("images/guichinh/menubar/khachhang.png"));
		mnKhachHang.setOpaque(true);
		mnKhachHang.setForeground(new Color(0, 102, 204));
		mnKhachHang.setFont(new Font("Segoe UI Semibold", Font.PLAIN, 15));
		mnKhachHang.setBackground(new Color(233, 255, 255));
		menuBar.add(mnKhachHang);

		mnQuanLyDia = new JMenu("Quản lý đĩa");
		mnQuanLyDia.setIcon(new ImageIcon("images/guichinh/menubar/quanlydia.png"));
		mnQuanLyDia.setOpaque(true);
		mnQuanLyDia.setForeground(new Color(0, 102, 204));
		mnQuanLyDia.setFont(new Font("Segoe UI Semibold", Font.PLAIN, 15));
		mnQuanLyDia.setBackground(new Color(233, 255, 255));
		menuBar.add(mnQuanLyDia);

		mnQuanLyTua = new JMenu("Quản lý tựa");
		mnQuanLyTua.setIcon(new ImageIcon("images/guichinh/menubar/quanlytua.png"));
		mnQuanLyTua.setOpaque(true);
		mnQuanLyTua.setForeground(new Color(0, 102, 204));
		mnQuanLyTua.setFont(new Font("Segoe UI Semibold", Font.PLAIN, 15));
		mnQuanLyTua.setBackground(new Color(233, 255, 255));
		menuBar.add(mnQuanLyTua);

		mnQuanLyThueDia = new JMenu("Quản lý thuê đĩa");
		mnQuanLyThueDia.setIcon(new ImageIcon("images/guichinh/menubar/quanlychothue.png"));
		mnQuanLyThueDia.setOpaque(true);
		mnQuanLyThueDia.setForeground(new Color(0, 102, 204));
		mnQuanLyThueDia.setFont(new Font("Segoe UI Semibold", Font.PLAIN, 15));
		mnQuanLyThueDia.setBackground(new Color(233, 255, 255));
		menuBar.add(mnQuanLyThueDia);

		mntmChoThueDia = new JMenuItem("Cho thuê đĩa");
		mntmChoThueDia.setPreferredSize(new Dimension(150, 25));
		mnQuanLyThueDia.add(mntmChoThueDia);
		
		mntmtra = new JMenuItem("Trả đĩa");
		mntmtra.setPreferredSize(new Dimension(150, 25));
		mnQuanLyThueDia.add(mntmtra);

		mntmDatDia = new JMenuItem("Đặt đĩa");
		mntmDatDia.setPreferredSize(new Dimension(150, 25));
		mnQuanLyThueDia.add(mntmDatDia);
		
		mntmHuyDatDia = new JMenuItem("Hủy đặt đĩa");
		mntmHuyDatDia.setPreferredSize(new Dimension(150, 25));
		mnQuanLyThueDia.add(mntmHuyDatDia);

		mnThanhToanTreHan = new JMenu("Thanh Toán trễ hạn");
		mnThanhToanTreHan.setIcon(new ImageIcon("images/guichinh/menubar/quanlytrehan.png"));
		mnThanhToanTreHan.setOpaque(true);
		mnThanhToanTreHan.setForeground(new Color(0, 102, 204));
		mnThanhToanTreHan.setFont(new Font("Segoe UI Semibold", Font.PLAIN, 15));
		mnThanhToanTreHan.setBackground(new Color(233, 255, 255));
		menuBar.add(mnThanhToanTreHan);

		mnCapNhatLoaiDia = new JMenu("Cập nhật loại đĩa");
		mnCapNhatLoaiDia.setIcon(new ImageIcon("images/guichinh/menubar/loaidia.png"));
		mnCapNhatLoaiDia.setOpaque(true);
		mnCapNhatLoaiDia.setForeground(new Color(0, 102, 204));
		mnCapNhatLoaiDia.setFont(new Font("Segoe UI Semibold", Font.PLAIN, 15));
		mnCapNhatLoaiDia.setBackground(new Color(233, 255, 255));
		menuBar.add(mnCapNhatLoaiDia);

		mntmCapNhatGia = new JMenuItem("Cập nhật giá loại đĩa");
		mntmCapNhatHan = new JMenuItem("Cập nhật hạn thuê loại đĩa");
		mntmCapNhatGia.setPreferredSize(new Dimension(180, 25));
		mntmCapNhatHan.setPreferredSize(new Dimension(180, 25));
		mnCapNhatLoaiDia.add(mntmCapNhatGia);
		mnCapNhatLoaiDia.add(mntmCapNhatHan);

		mnThongKe = new JMenu("Thống kê");
		mnThongKe.setIcon(new ImageIcon("images/guichinh/menubar/thongke.png"));
		mnThongKe.setOpaque(true);
		mnThongKe.setForeground(new Color(0, 102, 204));
		mnThongKe.setFont(new Font("Segoe UI Semibold", Font.PLAIN, 15));
		mnThongKe.setBackground(new Color(233, 255, 255));
		mnThongKe.setPreferredSize(new Dimension(120, 30));
		menuBar.add(mnThongKe);

		mntmTkTuaDia = new JMenuItem("Thống kê tựa đĩa");
		mntmTkKHAll = new JMenuItem("Thống kê tất cả khách hàng");
		mntmTkKhNoTien = new JMenuItem("Thống kê khách hàng có nợ trễ hạn");
		mntmTkKHNoDia = new JMenuItem("Thống kê khách hàng có đĩa trễ hạn");
		mntmTkTuaDia.setPreferredSize(new Dimension(225, 25));
		mntmTkKHAll.setPreferredSize(new Dimension(225, 25));
		mntmTkKhNoTien.setPreferredSize(new Dimension(225, 25));
		mntmTkKHNoDia.setPreferredSize(new Dimension(225, 25));

		mnThongKe.add(mntmTkTuaDia);
		mnThongKe.add(mntmTkKHAll);
		mnThongKe.add(mntmTkKhNoTien);
		mnThongKe.add(mntmTkKHNoDia);


		panelQuickIcon = new JPanel();
		panelQuickIcon.setBorder(new LineBorder(Color.LIGHT_GRAY));
		panelQuickIcon.setBounds(0, 35, 1200, 48);
		getContentPane().add(panelQuickIcon);
		panelQuickIcon.setLayout(null);

		iconHome = new JLabel("");
		iconHome.setIcon(new ImageIcon("images\\guichinh\\quickbar\\home.png"));
		iconHome.setBounds(0, 0, 50, 50);
		iconHome.setToolTipText("Trang chủ");
		panelQuickIcon.add(iconHome);
		
		iconAddKH = new JLabel("");
		iconAddKH.setIcon(new ImageIcon("images\\guichinh\\quickbar\\addkhachhang.png"));
		iconAddKH.setBounds(50, 0, 50, 50);
		iconAddKH.setToolTipText("Thêm khách hàng mới");
		panelQuickIcon.add(iconAddKH);

		iconThueDia = new JLabel("");
		iconThueDia.setIcon(new ImageIcon("images\\guichinh\\quickbar\\chothue.png"));
		iconThueDia.setBounds(100, 0, 45, 45);
		iconThueDia.setToolTipText("Cho thuê đĩa");
		panelQuickIcon.add(iconThueDia);

		iconTraDia = new JLabel("");
		iconTraDia.setIcon(new ImageIcon("images\\guichinh\\quickbar\\tradia.png"));
		iconTraDia.setBounds(150, 0, 45, 45);
		iconTraDia.setToolTipText("Trả đĩa");
		panelQuickIcon.add(iconTraDia);

		txtTimTua = new JTextField();
		txtTimTua.setBounds(750, 7, 300, 30);
		panelQuickIcon.add(txtTimTua);
		
		
//		panelQuickIcon.add(scrollTimKiemTua = new JScrollPane());
//		scrollTimKiemTua.setBounds(750, 40, 300, 100);
//		modelList = new DefaultListModel<>();
//		dsTuaDia = new JList<>();
//		dsTuaDia.setModel(modelList);
//		dsTuaDia.setFont(new Font("Segoe UI", Font.PLAIN, 15));
//		dsTuaDia.setSelectionMode(ListSelectionModel.SINGLE_SELECTION);
//		scrollTimKiemTua.setViewportView(dsTuaDia);
//		scrollTimKiemTua.setVisible(true);
		
		
		btnTimTua = new JButton("Tìm tựa đĩa");
		btnTimTua.setBounds(1070, 5, 120, 35);
		btnTimTua.setContentAreaFilled(false);
		btnTimTua.setOpaque(true);
		btnTimTua.setForeground(Color.white);
		btnTimTua.setBorder(null);
		btnTimTua.setCursor(new Cursor(Cursor.HAND_CURSOR));
		btnTimTua.setFont(new Font("Segoe UI", Font.BOLD, 15));
		btnTimTua.setBackground(Color.decode("#24B8FF"));
		panelQuickIcon.add(btnTimTua);
		
		pnMain = new JPanel();
		pnMain.setLayout(null);
		pnMain.setBounds(0, 83, 1200, 588);
		getContentPane().add(pnMain);
		pnMain.setOpaque(false);
		showpanel(panelMain);


		mnKhachHang.addMouseListener(this);
		mnQuanLyDia.addMouseListener(this);
		mnQuanLyTua.addMouseListener(this);
		mnThanhToanTreHan.addMouseListener(this);
		btnTimTua.addMouseListener(this);
		
		iconHome.addMouseListener(this);
		iconAddKH.addMouseListener(this);
		iconThueDia.addMouseListener(this);
		iconTraDia.addMouseListener(this);

		mntmThoat.addActionListener(this);
		mntmDangXuat.addActionListener(this);
		mntmChoThueDia.addActionListener(this);
		mntmDatDia.addActionListener(this);
		mntmHuyDatDia.addActionListener(this);
		mntmtra.addActionListener(this);
		mntmTkTuaDia.addActionListener(this);
		mntmTkKHAll.addActionListener(this);
		mntmTkKhNoTien.addActionListener(this);
		mntmTkKHNoDia.addActionListener(this);
		mntmCapNhatGia.addActionListener(this);
		mntmCapNhatHan.addActionListener(this);
		btnTimTua.addActionListener(this);
		
		txtTimTua.addKeyListener(this);
		

		/**
		 * kiểm tra người dùng để thực hiện chức năng tương ứng
		 */
		if(user != null) {
			mnTuyChon.setText("   Admin   ");
			mntmDangXuat.setText("Đăng xuất");
		}
		else {
			mnTuyChon.setText("  Tùy chọn  ");
			mntmDangXuat.setText("Đăng nhập");
		}
	}

	public ImageIcon ImgResizable(String path,int width,int height) {
		ImageIcon img = new ImageIcon(new ImageIcon(path).getImage().getScaledInstance(width, height, Image.SCALE_AREA_AVERAGING));
		return img;
	}

	public void hiddenTim(boolean b) {
		txtTimTua.setVisible(b);
		btnTimTua.setVisible(b);
	}

	public void timThongTinDiaTheoTua() {
		String tua = txtTimTua.getText();

		if(tua.equals("")) {
			JOptionPane.showMessageDialog(this, "Chưa nhập tựa đĩa");
			txtTimTua.requestFocus();
			return;
		}

		DiaControl diaControl = new DiaControl();
		ArrayList<Dia> dsDia = diaControl.timThongTinDia(tua);
		if(dsDia.size() > 0)
			new Form_XemTrangThaiDia(dsDia).setVisible(true);
		else {
			JOptionPane.showMessageDialog(this, "Tựa đĩa này không tìm thấy");
			txtTimTua.selectAll();
			txtTimTua.requestFocus();
			return;
		}
	}

	@Override
	public void actionPerformed(ActionEvent e) {
		Object o = e.getSource();
		if(o.equals(mntmChoThueDia)) {
			showpanel(new ChoThueDia());
			setDefaultBackgroundMenu();
			hiddenTim(true);
		}
		else if(o.equals(mntmDatDia)) {
			new Form_DatDia(this).setVisible(true);
		}
		else if(o.equals(mntmHuyDatDia)) {
			showpanel(new HuyDatDia());
			setDefaultBackgroundMenu();
			hiddenTim(false);
		}
		else if(o.equals(mntmtra)) {
			showpanel(new TraDia());
			setDefaultBackgroundMenu();
			hiddenTim(false);
		}
		else if(o == btnTimTua)
			timThongTinDiaTheoTua();
		else if(o == mntmThoat)
			System.exit(0);
		

		if(o == mntmCapNhatGia || o == mntmCapNhatHan || o == mntmDangXuat || o == mntmTkTuaDia|| o == mntmTkKHAll || o == mntmTkKhNoTien || o == mntmTkKHNoDia) {
			if(user != null) {
				if(o == mntmCapNhatGia)
					new Form_CapNhatLoaiDia(1).setVisible(true);
				else if(o == mntmCapNhatHan)
					new Form_CapNhatLoaiDia(2).setVisible(true);
				else if(o.equals(mntmTkTuaDia)) {
					showpanel(new ThongKeTuaDia());
					setDefaultBackgroundMenu();
					hiddenTim(true);
				}
				else if(o == mntmTkKHAll) {
					showpanel(new ThongKeThongTinKhachHang(THONGKETATCAKHACHHANG));
					setDefaultBackgroundMenu();
					hiddenTim(false);
				}
				else if(o == mntmTkKhNoTien) {
					showpanel(new ThongKeThongTinKhachHang(THONGKEKHACHHANGCOPHITREHAN));
					setDefaultBackgroundMenu();
					hiddenTim(false);
				}
				else if(o == mntmTkKHNoDia) {
					showpanel(new ThongKeThongTinKhachHang(THONGKEKHACHHANGCODIATREHAN));
					setDefaultBackgroundMenu();
					hiddenTim(false);
				}

				else if(o == mntmDangXuat) {
					user = null;
					mnTuyChon.setText("  Tùy chọn  ");
					mntmDangXuat.setText("Đăng nhập");
				}
			}
			else
				new DangNhap(this).setVisible(true);
		}
	}

	@Override
	public void mouseClicked(MouseEvent e) {
		Object o = e.getSource();

		if(o.equals(mnThanhToanTreHan)) {
			mnThanhToanTreHan.setBackground(Color.decode("#BCE8FF"));
			showpanel(new ThanhToanPhiTreHan(this));
			hiddenTim(false);
		}
		else {
			mnThanhToanTreHan.setBackground(new Color(233, 255, 255));
		}
		if(o.equals(mnKhachHang)) {
			mnKhachHang.setBackground(Color.decode("#BCE8FF"));
			showpanel(quanLyKhachHang);
			hiddenTim(false);
		}
		else {
			mnKhachHang.setBackground(new Color(233, 255, 255));
		}
		if(o.equals(mnQuanLyDia) || o.equals(mnQuanLyTua)) {
			if(user != null) {
				

				if(o.equals(mnQuanLyDia)) {
					mnQuanLyDia.setBackground(Color.decode("#BCE8FF"));
					showpanel(new QuanLyDia());
					hiddenTim(false);
				}
				else {
					mnQuanLyDia.setBackground(new Color(233, 255, 255));
				}

				if(o.equals(mnQuanLyTua)) {
					mnQuanLyTua.setBackground(Color.decode("#BCE8FF"));
					showpanel(new QuanLyTua());
					hiddenTim(false);
				}
				else {
					mnQuanLyTua.setBackground(new Color(233, 255, 255));
				}
			}
			else
				new DangNhap(this).setVisible(true);
		}
		
		if(o.equals(iconHome)) {
			JPanel pnHome = panelMain();
			showpanel(pnHome);
			hiddenTim(true);
		}
		if (o.equals(iconAddKH)) {
			ThemKhachHang tkh = new ThemKhachHang(this, null);
			tkh.setVisible(true);
		}
		
		else
			if(o.equals(iconThueDia)) {
				showpanel(new ChoThueDia());
				setDefaultBackgroundMenu();
				hiddenTim(true);
			}else
				if(o.equals(iconTraDia)) {
					showpanel(new TraDia());
					setDefaultBackgroundMenu();
					hiddenTim(false);
				}
	}
	@Override
	public void mousePressed(MouseEvent e) {}

	@Override
	public void mouseReleased(MouseEvent e) {}

	@Override
	public void mouseEntered(MouseEvent e) {
		Object o = e.getSource();
		Border line = BorderFactory.createLineBorder(Color.gray, 2);
		if(o.equals(iconHome))
			iconHome.setBorder(line);
		
		if (o.equals(iconAddKH)) {
			iconAddKH.setBorder(line);
		}
		
		if (o.equals(iconThueDia)) {
			iconThueDia.setBorder(line);
		}
		
		if (o.equals(iconTraDia)) {
			iconTraDia.setBorder(line);
		}
		if(o.equals(btnTimTua)) {
			btnTimTua.setBackground(Color.decode("#64CDFF"));
		}
		
	}

	@Override
	public void mouseExited(MouseEvent e) {
		Object o = e.getSource();
		Border line = null;
		
		if(o.equals(iconHome))
			iconHome.setBorder(line);
		
		if (o.equals(iconAddKH)) {
			iconAddKH.setBorder(line);
		}
		
		if (o.equals(iconThueDia)) {
			iconThueDia.setBorder(line);
		}
		
		if (o.equals(iconTraDia)) {
			iconTraDia.setBorder(line);
		}
		if(o.equals(btnTimTua)) {
			btnTimTua.setBackground(Color.decode("#24B8FF"));
		}
	}

	public void setDefaultBackgroundMenu() {
		mnKhachHang.setBackground(new Color(233, 255, 255));
		mnQuanLyDia.setBackground(new Color(233, 255, 255));
		mnQuanLyTua.setBackground(new Color(233, 255, 255));
		mnThanhToanTreHan.setBackground(new Color(233, 255, 255));
	}

	public void showpanel(JPanel panel) {
		pnMain.removeAll();
//		quanLyDia.setBounds(0, 0, 1200, 788);
		pnMain.add(panel);
		pnMain.repaint();
		pnMain.validate();
	}

	@Override
	public void keyPressed(KeyEvent e) {
		if(e.getKeyCode() == KeyEvent.VK_ENTER) {
			if(e.getSource() == txtTimTua)
				timThongTinDiaTheoTua();
		}
	}

	@Override
	public void keyReleased(KeyEvent e) {
		// TODO Auto-generated method stub

	}

	@Override
	public void keyTyped(KeyEvent e) {
		// TODO Auto-generated method stub

	}
}
