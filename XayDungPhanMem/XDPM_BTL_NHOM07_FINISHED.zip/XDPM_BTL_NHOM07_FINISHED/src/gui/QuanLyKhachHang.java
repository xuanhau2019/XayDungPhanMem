package gui;

import java.awt.Color;
import java.awt.Component;
import java.awt.Cursor;
import java.awt.Font;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.FocusEvent;
import java.awt.event.FocusListener;
import java.awt.event.KeyEvent;
import java.awt.event.KeyListener;
import java.util.ArrayList;
import java.util.List;

import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.JScrollPane;
import javax.swing.JTable;
import javax.swing.JTextField;
import javax.swing.ListSelectionModel;
import javax.swing.table.DefaultTableModel;
import javax.swing.table.JTableHeader;
import javax.swing.table.TableCellRenderer;

import control.KhachHangControl;
import entities.KhachHang;


@SuppressWarnings("serial")
public class QuanLyKhachHang extends JPanel implements ActionListener,KeyListener,FocusListener {

	private DefaultTableModel tableModel;
	private JTable table;
	private JButton btnThemKh;
	private JButton btnSuaKh;
	private JButton btnXoaKh;
	private JTextField textField;
	private JLabel lblTitle;
	private ThemKhachHang khDL;
	private JFrame jframe;
	KhachHangControl khcon = new KhachHangControl();
	ArrayList<KhachHang> listKH = new ArrayList<KhachHang>();
	/**
	 * Create the frame.
	 */

	GUIChinh guiChinh;
	public QuanLyKhachHang(GUIChinh parent) {
		this.guiChinh = parent;
		setLayout(null);

		JPanel panel = new JPanel();
		panel.setBounds(0, 0, 1200, 788);
		setBounds(0, 0, 1200, 788);
		add(panel);
		panel.setLayout(null);

		JPanel pnTitle = new JPanel();
		pnTitle.setBounds(0, 0, 1200, 30);
		pnTitle.setBackground(Color.CYAN);

		lblTitle = new JLabel("Quản lý khách hàng");
		lblTitle.setFont(new Font("Segoe UI", Font.BOLD, 18));

		pnTitle.add(lblTitle);

		panel.add(pnTitle);

		JScrollPane scrollPane = new JScrollPane();
		scrollPane.setBounds(10, 162, 1180, 615);
		panel.add(scrollPane);

		table = new JTable() {
			public Component prepareRenderer( TableCellRenderer renderer, int row, int col ) {
				Component c = super.prepareRenderer(renderer, row, col);
				if ( row % 2 == 0 && !isCellSelected(row, col)) {
					c.setBackground( Color.decode("#F1F1F1") );
				}
				else 
					if(!isCellSelected(row, col)){
						c.setBackground( Color.decode("#D7F1FF") );
					}else {
						c.setBackground(Color.decode("#25C883"));
					}		        
				return c;
			}

		};
		table.setBorder(null);
		table.setFillsViewportHeight(true);
		table.setShowGrid(false);

		JTableHeader header = table.getTableHeader();
		header.setBackground(Color.decode("#007ECA"));
		header.setForeground(Color.white);
		header.setOpaque(false);

		table.setModel(tableModel = new DefaultTableModel(
				new Object[][] {

				},
				new String[] {
						"Mã khách hàng","Tên khách hàng", "Số điện thoại", "Địa chỉ"
				}
				){
			boolean[] columnEditables = new boolean[] {
					false, false, false, false
			};
			public boolean isCellEditable(int row, int column) {
				return columnEditables[column];
			}

		});

		scrollPane.setViewportView(table);        
		table.setRowHeight(25);
		table.setSelectionMode(ListSelectionModel.SINGLE_SELECTION);
		table.getTableHeader().setReorderingAllowed(false);

		btnThemKh = new JButton("Thêm Khách Hàng");
		btnThemKh.setContentAreaFilled(false);
		btnThemKh.setForeground(Color.white);
		btnThemKh.setBorder(null);
		btnThemKh.setBackground(Color.decode("#4CAF50"));
		btnThemKh.setCursor(new Cursor(Cursor.HAND_CURSOR));
		btnThemKh.setOpaque(true);
		btnThemKh.setFont(new Font("Segoe UI", Font.BOLD, 15));
		btnThemKh.setBounds(696, 81, 139, 41);
		panel.add(btnThemKh);

		btnSuaKh = new JButton("Sửa Khách Hàng");
		btnSuaKh.setContentAreaFilled(false);
		btnSuaKh.setForeground(Color.white);
		btnSuaKh.setBorder(null);
		btnSuaKh.setBackground(Color.decode("#C2C018"));
		btnSuaKh.setCursor(new Cursor(Cursor.HAND_CURSOR));
		btnSuaKh.setOpaque(true);
		btnSuaKh.setFont(new Font("Segoe UI", Font.BOLD, 15));
		btnSuaKh.setBounds(856, 81, 139, 41);
		panel.add(btnSuaKh);

		btnXoaKh = new JButton("Xóa Khách Hàng");
		btnXoaKh.setContentAreaFilled(false);
		btnXoaKh.setForeground(Color.white);
		btnXoaKh.setBorder(null);
		btnXoaKh.setBackground(Color.decode("#FF2F50"));
		btnXoaKh.setCursor(new Cursor(Cursor.HAND_CURSOR));
		btnXoaKh.setOpaque(true);
		btnXoaKh.setFont(new Font("Segoe UI", Font.BOLD, 15));
		btnXoaKh.setBounds(1016, 81, 139, 41);
		panel.add(btnXoaKh);

		textField = new JTextField();
		textField.setBounds(10, 85, 661, 38);
		textField.setText("Nhập thông tin để tìm kiếm...");
		textField.setFont(new Font("Segoe UI", Font.BOLD, 15));
		textField.setForeground(Color.decode("#9E9E9E"));
		panel.add(textField);
		textField.setColumns(10);

		JLabel lblTimKhachHang = new JLabel(">>Tìm khách hàng");
		lblTimKhachHang.setFont(new Font("Segoe UI", Font.BOLD, 17));
		lblTimKhachHang.setForeground(new Color(255, 0, 255));
		lblTimKhachHang.setBounds(10, 48, 600, 30);
		panel.add(lblTimKhachHang);

		btnThemKh.addActionListener(this);
		btnSuaKh.addActionListener(this);
		btnXoaKh.addActionListener(this);
		textField.addKeyListener(this);
		textField.addFocusListener(this);
		
		hienThiDanhSachKH();
	}

	public void hienThiDanhSachKH() {
		List<KhachHang>list = khcon.layDanhSachKhachHang();
		while(tableModel.getRowCount() >= 1)
			tableModel.removeRow(0);

		list.forEach(x -> {
			Object[] tx = {x.getIdkh(),x.getTenkh(),x.getSodt(),x.getDiachi()};
			tableModel.addRow(tx);
		});
	}
	public void hienThiKHTimKiem(String ttkh) {
		ArrayList<KhachHang> list = khcon.timKhachHang(ttkh);
		Object[] row = new Object[4];
		if(list.size()>0)
		{
			tableModel.setNumRows(0);
			for(int i=0;i<list.size();i++)
			{
				row[0]=list.get(i).getIdkh();
				row[1]=list.get(i).getTenkh();
				row[2]=list.get(i).getSodt();
				row[3]=list.get(i).getDiachi();
				tableModel.addRow(row);
			}
		}
	}
	@Override
	public void actionPerformed(ActionEvent e) {
		Object o = e.getSource();		
		if(o.equals(btnThemKh)){
			khDL = new ThemKhachHang(jframe,null);
			khDL.setVisible(true);
			hienThiDanhSachKH();
			String makh = khDL.getMakh();
			if(table.getRowCount()>0) {
				for (int i = 0; i < table.getRowCount(); i++) {
					if(table.getValueAt(i, 0).equals(makh))
						table.setRowSelectionInterval(i, i);
				}
			}
		}
		if (o.equals(btnSuaKh)){
			if(table.getSelectedRow()>=0) {
				KhachHang kh = khcon.layKHByID(table.getValueAt(table.getSelectedRow(), 0).toString());
				khDL = new ThemKhachHang(jframe,kh);
				khDL.setVisible(true);
				hienThiDanhSachKH();
				String makh = khDL.getMakh();
				if(table.getRowCount()>0) {
					for (int i = 0; i < table.getRowCount(); i++) {
						if(table.getValueAt(i, 0).equals(makh))
							table.setRowSelectionInterval(i, i);
					}
				}
			}else {
				JOptionPane.showMessageDialog(this, "Chọn khách hàng để sửa thông tin!");
			}	
		}
		if(o.equals(btnXoaKh))
		{
			if (GUIChinh.user == null) {
				new DangNhap(jframe).setVisible(true);
			}else {
				if(table.getSelectedRow()>=0)
				{
					int reply = JOptionPane.showConfirmDialog(this, "Bạn có chắc xóa khách hàng này ?","Xóa Khách Hàng", JOptionPane.YES_NO_OPTION);
					if(reply == JOptionPane.YES_OPTION)
					{
						if(khcon.xoaKH(table.getValueAt(table.getSelectedRow(), 0).toString())==false)
						{
							JOptionPane.showMessageDialog(this, "Khách hàng đang thuê đĩa không được xóa !");
						}
						else
						{
							JOptionPane.showMessageDialog(this, "Xóa khách hàng thành công !");
							hienThiDanhSachKH();
							textField.setText("");
						}
					}
					else
					{
						hienThiDanhSachKH();
					}
				}
				else
				{
					JOptionPane.showMessageDialog(this, "Chọn khách hàng để xóa !");
				}
			}
		}
	}

	@Override
	public void keyPressed(KeyEvent e) {
		Object o = e.getSource();
		if(o.equals(textField))
		{
			if(textField.getText().length()>100)
			{
				JOptionPane.showMessageDialog(this, "Bạn đã nhập quá nhiều!");
			}
		}
	}

	@Override
	public void keyReleased(KeyEvent e) {
		Object o = e.getSource();
		if(o.equals(textField)) 
		{
			hienThiKHTimKiem(textField.getText());
		}

	}

	@Override
	public void keyTyped(KeyEvent e) {
		// TODO Auto-generated method stub

	}

	@Override
	public void focusGained(FocusEvent e) {
		// TODO Auto-generated method stub
		Object o = e.getSource();
		if(o.equals(textField)&&textField.getText().equals("Nhập thông tin để tìm kiếm...")) {
			textField.setText("");
			textField.setForeground(Color.black);
		}
	}

	@Override
	public void focusLost(FocusEvent e) {
		// TODO Auto-generated method stub
		Object o = e.getSource();
		if(o.equals(textField)&&textField.getText().equals("")) {
			textField.setText("Nhập thông tin để tìm kiếm...");
			textField.setForeground(Color.LIGHT_GRAY);
		}
	}

}
