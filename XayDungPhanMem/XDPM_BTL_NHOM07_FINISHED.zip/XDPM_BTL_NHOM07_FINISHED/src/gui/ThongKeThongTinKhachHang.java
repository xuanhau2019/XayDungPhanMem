package gui;

import java.awt.BorderLayout;
import java.awt.Color;
import java.awt.Component;
import java.awt.Dimension;
import java.awt.Font;
import java.awt.event.MouseEvent;
import java.awt.event.MouseListener;
import java.awt.event.MouseMotionListener;
import java.text.DecimalFormat;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;

import javax.swing.BorderFactory;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.JScrollPane;
import javax.swing.JTable;
import javax.swing.ListSelectionModel;
import javax.swing.table.DefaultTableModel;
import javax.swing.table.JTableHeader;
import javax.swing.table.TableCellRenderer;

import control.ThongKeControl;
import entities.Dia;
import entities.KhachHang;
import entities.PhiTreHan;
import entities.PhieuThue;
import entities.PhieuTra;

@SuppressWarnings("serial")
public class ThongKeThongTinKhachHang extends JPanel implements MouseListener, MouseMotionListener {

	JLabel lblTD;
	JTable tableKhachHang, tableThongKeTheoKH;
	DefaultTableModel modelKhachHang, modelThongKeTheoKH;

	SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd");
	DecimalFormat dmf = new DecimalFormat("#,##0");
	protected int rollOverRowIndex = -1;

	ThongKeControl thongkeCon = new ThongKeControl();
	ArrayList<Object[]> allCustomers = new ArrayList<>();
	ArrayList<Object[]> onlyCustomer = new ArrayList<>();
	
	/**
	 * Create the panel.
	 */
	public ThongKeThongTinKhachHang(int chonThongKe) {

		setLayout(null);
		JPanel panel = new JPanel();
		panel.setBounds(0, 0, 1200, 588);
		setBounds(0, 0, 1200, 588);
		add(panel);

		// ------------------ NORTH ------------------ //
		JPanel pNorth = new JPanel();
		pNorth.setBackground(Color.CYAN);
		pNorth.setLayout(new BorderLayout());
		pNorth.setPreferredSize(new Dimension(1200, 35));
		pNorth.add(lblTD = new JLabel("THỐNG KÊ TẤT CẢ KHÁCH HÀNG", JLabel.CENTER));
		lblTD.setFont(new Font("Calibri Light", Font.BOLD, 27));
		panel.add(pNorth, BorderLayout.NORTH);

		// ------------------ CENTER ------------------ //
		JPanel pnCenter = new JPanel();
		pnCenter.setLayout(new BorderLayout());

		JPanel pnCenHead = new JPanel();
		pnCenHead.setLayout(new BorderLayout());
		pnCenHead.setPreferredSize(new Dimension(1200,250));
		pnCenHead.setBorder(BorderFactory.createTitledBorder("Thống kê thông tin khách hàng"));

		// bảng thống kê về thông tin khách hàng
		JScrollPane scrollPaneTTKhachHang = new JScrollPane();
		pnCenHead.add(scrollPaneTTKhachHang);
		pnCenter.add(pnCenHead, BorderLayout.NORTH);

		tableKhachHang = new JTable() {
			public Component prepareRenderer( TableCellRenderer renderer, int row, int col ) {
				Component c = super.prepareRenderer(renderer, row, col);
				c.setFont(new Font("Times New Roman", Font.BOLD, 15));
				if ( row % 2 == 0 && !isCellSelected(row, col)) {
					c.setBackground( Color.white );
				}
				else 
					if(!isCellSelected(row, col)){
						c.setBackground( Color.decode("#F1F1F1") );
					}else {
						c.setBackground(Color.decode("#009FFF"));
					}
				if( isRowSelected(row) || (row == rollOverRowIndex) ) {
					c.setForeground(Color.black);
					c.setBackground(Color.decode("#A9DFFF"));
				}
				else {
					c.setBackground(getBackground());
				}
				return c;

			}
		};
		tableKhachHang.setBorder(null);
		tableKhachHang.setFillsViewportHeight(true);
		tableKhachHang.setShowGrid(false);

		JTableHeader headerTableKhachHang = tableKhachHang.getTableHeader();
		headerTableKhachHang.setBackground(Color.decode("#007ECA"));
		headerTableKhachHang.setForeground(Color.white);
		headerTableKhachHang.setOpaque(false);

		tableKhachHang.setModel(modelKhachHang = new DefaultTableModel(
				new Object[][] {

				},
				new String[] {
						"STT", "ID khách hàng","Tên khách hàng", "Số điện thoại", "Số đĩa đang giữ", "Tổng tiền nợ", "Địa chỉ"
				}
				){
			boolean[] columnEditables = new boolean[] {
					false, false, false, false, false, false, false
			};
			public boolean isCellEditable(int row, int column) {
				return columnEditables[column];
			}

		});

		scrollPaneTTKhachHang.setViewportView(tableKhachHang);  
		tableKhachHang.getColumnModel().getColumn(0).setMaxWidth(40);
		tableKhachHang.getColumnModel().getColumn(0).setMinWidth(0);
		tableKhachHang.getColumnModel().getColumn(4).setMaxWidth(150);
		tableKhachHang.getColumnModel().getColumn(4).setMinWidth(100);
		tableKhachHang.setRowHeight(25);
		tableKhachHang.setSelectionMode(ListSelectionModel.SINGLE_SELECTION);
		tableKhachHang.getTableHeader().setReorderingAllowed(false);

		// bảng thống kê về đĩa khách đã thuê
		JPanel pnCenMid = new JPanel();
		pnCenMid.setLayout(new BorderLayout());
		pnCenMid.setBorder(BorderFactory.createTitledBorder("Thống kê theo từng khách hàng đến mượn đĩa"));
		JScrollPane scrollPaneThongKeDia = new JScrollPane();
		pnCenMid.add(scrollPaneThongKeDia);
		pnCenter.add(pnCenMid);

		tableThongKeTheoKH = new JTable() {

			public Component prepareRenderer( TableCellRenderer renderer, int row, int col ) {
				Component c = super.prepareRenderer(renderer, row, col);
				if ( row % 2 == 0 && !isCellSelected(row, col)) {
					c.setBackground( Color.decode("#F1F1F1") );
				}
				else 
					if(!isCellSelected(row, col)){
						c.setBackground( Color.decode("#D7F1FF") );
					}else {
						c.setBackground(Color.decode("#25C883"));
					}		        
				return c;
			}
		};
		tableThongKeTheoKH.setBorder(null);
		tableThongKeTheoKH.setFillsViewportHeight(true);
		tableThongKeTheoKH.setShowGrid(false);
		tableThongKeTheoKH.setIntercellSpacing(new Dimension(0, 5));

		JTableHeader header = tableThongKeTheoKH.getTableHeader();
		header.setBackground(Color.decode("#007ECA"));
		header.setForeground(Color.white);
		header.setOpaque(false);

		tableThongKeTheoKH.setModel(modelThongKeTheoKH = new DefaultTableModel(
				new Object[][] {

				},
				new String[] {
						"STT", "Tên Tựa", "Đĩa", "Ngày thuê", "Kỳ Hạn", "Ngày trả", "Tiền phạt"
				}
		));
		
		tableThongKeTheoKH.getColumnModel().getColumn(0).setMaxWidth(40);
		tableThongKeTheoKH.getColumnModel().getColumn(0).setMinWidth(0);
		tableThongKeTheoKH.getColumnModel().getColumn(2).setMaxWidth(100);
		tableThongKeTheoKH.getColumnModel().getColumn(2).setMinWidth(100);
		scrollPaneThongKeDia.setViewportView(tableThongKeTheoKH);        
		tableThongKeTheoKH.setRowHeight(25);
		tableThongKeTheoKH.setSelectionMode(ListSelectionModel.SINGLE_SELECTION);
		tableThongKeTheoKH.getTableHeader().setReorderingAllowed(false);

		panel.add(pnCenter, BorderLayout.CENTER);			
		
		switch (chonThongKe) {
			case 1:
				allCustomers = thongkeCon.thongKeThongTinKhachHang();
				lblTD.setText("THỐNG KÊ TẤT CẢ KHÁCH HÀNG");
				break;
			case 2:
				allCustomers = thongkeCon.thongKeKhachHangCoPhiTreHan();
				lblTD.setText("THỐNG KÊ KHÁCH HÀNG CÓ NỢ TRỄ HẠN");
				break;
			case 3:
				allCustomers = thongkeCon.thongKeKhachHangCoDiaTreHan();
				lblTD.setText("THỐNG KÊ KHÁCH HÀNG CÓ ĐĨA TRỄ HẠN");
				break;
		}
		duaThongTinThongKeKhachHangVaoTableKhachHang(allCustomers);
		
		tableKhachHang.addMouseListener(this);
		tableKhachHang.addMouseMotionListener(this);
	}
	
	public void duaThongTinThongKeKhachHangVaoTableKhachHang(ArrayList<Object[]> list) {
		modelKhachHang.setNumRows(0);
		KhachHang kh = new KhachHang();
		double tongTienDangNo = 0;
		if (list.size() > 0) {
			int i = 0;
			for (Object[] objs : list) {
				kh = (KhachHang) objs[0];
				tongTienDangNo = Double.parseDouble(objs[2].toString());
				String[] items = {++i +"", kh.getIdkh(), kh.getTenkh(), kh.getSodt(), objs[1].toString(), dmf.format(tongTienDangNo), kh.getDiachi()};
				modelKhachHang.addRow(items);
			}
		}
	}

	public void duaChiTietThongKeTheoKhachHhangVaoTableThongKeTheoKH(ArrayList<Object[]> list) {
		modelThongKeTheoKH.setNumRows(0);
		Dia dia = null;
		PhieuThue pthue = null;
		PhieuTra ptra = null;
		PhiTreHan phiTreHan = null;
		
		if(list.size() > 0) {
			int i = 0;
			for (Object[] objs : list) {
				dia = (Dia) objs[0];
				pthue = (PhieuThue) objs[1];
				ptra = (PhieuTra) objs[2];
				Date kyHan = (Date) objs[3];
				phiTreHan = (PhiTreHan) objs[5];
				
				// nếu đã thanh toán phí trễ hạn thì không có hiển thị
				if(objs[4] == null) {
					String[] items = {++i +"", dia.getTuadia().getTentua(), dia.getMadia(), sdf.format(pthue.getNgaythue()), sdf.format(kyHan),
							"Chưa trả đĩa", "0"};
		
					if(ptra != null) {
						items[4] = "Đã trả đĩa";
						items[5] = sdf.format(ptra.getNgaytradia());
						if(phiTreHan != null)
							items[6] = dmf.format(phiTreHan.getTienno());
					}
					modelThongKeTheoKH.addRow(items);
				}
			}
		}
		else
			JOptionPane.showMessageDialog(this, "Khách hàng này chưa thuê đĩa nên không có thông tin để thống kê");
	}

	@Override
	public void mouseClicked(MouseEvent e) {
		int row = tableKhachHang.getSelectedRow();
		if(row != -1) {
			onlyCustomer = thongkeCon.thongKeTheoTungKhachHang(tableKhachHang.getValueAt(row, 1).toString());
			duaChiTietThongKeTheoKhachHhangVaoTableThongKeTheoKH(onlyCustomer);
		}
	}

	@Override
	public void mouseEntered(MouseEvent e) {
		// TODO Auto-generated method stub

	}

	@Override
	public void mouseExited(MouseEvent e) {
		if(e.getSource().equals(tableKhachHang)) {
			rollOverRowIndex = -1;
			repaint();
		}	
	}

	@Override
	public void mousePressed(MouseEvent e) {
		// TODO Auto-generated method stub

	}

	@Override
	public void mouseReleased(MouseEvent e) {
		// TODO Auto-generated method stub

	}

	@Override
	public void mouseDragged(MouseEvent e) {
		// TODO Auto-generated method stub

	}

	@Override
	public void mouseMoved(MouseEvent e) {
		int row = tableKhachHang.rowAtPoint(e.getPoint());
		if( row != rollOverRowIndex ) {
			rollOverRowIndex = row;
			repaint();
		}
	}

}
