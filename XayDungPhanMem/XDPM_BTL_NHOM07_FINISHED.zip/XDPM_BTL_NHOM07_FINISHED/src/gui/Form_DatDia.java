package gui;

import java.awt.Color;
import java.awt.Cursor;
import java.awt.Font;
import java.awt.Image;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.KeyEvent;
import java.awt.event.KeyListener;
import java.awt.event.MouseEvent;
import java.awt.event.MouseListener;
import java.util.ArrayList;
import java.util.Date;

import javax.swing.BorderFactory;
import javax.swing.ButtonGroup;
import javax.swing.DefaultListModel;
import javax.swing.ImageIcon;
import javax.swing.JButton;
import javax.swing.JDialog;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JList;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.JRadioButton;
import javax.swing.JScrollPane;
import javax.swing.JTextArea;
import javax.swing.JTextField;
import javax.swing.ListSelectionModel;

import control.DatDiaControl;
import control.KhachHangControl;
import control.TuaDiaControl;
import entities.DatDia;
import entities.Dia;
import entities.KhachHang;
import entities.TuaDia;

@SuppressWarnings("serial")
public class Form_DatDia extends JDialog implements ActionListener, MouseListener, KeyListener {

	JLabel lblMaKH, lblTenKH, lblTuaDia, lblLoaiDia, lblMota, lblAnh;
	JTextField txtMaKH, txtTenKH, txtTuaDia;
	JRadioButton radPhim, radGame;
	JTextArea txaMoTa;
	JButton btnLuu, btnXoaRong;
	JList<TuaDia> dsTuaDia;
	DefaultListModel<TuaDia> modelList;
	JScrollPane scrollTimKiemTua;
	
	KhachHangControl khCon = new KhachHangControl();
	DatDiaControl 	 datDiaCon = new DatDiaControl();
	TuaDiaControl 	 tuaDiaCon = new TuaDiaControl();
	
	KhachHang	khachhangDat = null;
	TuaDia		tuadiaDat = null;

	public Form_DatDia(JFrame parent) {
		super(parent,true);
		setTitle("Đặt đĩa");
		setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
		setSize(679, 550);
		setResizable(false);
		setLocationRelativeTo(null);
		getContentPane().setLayout(null);

		JPanel panel = new JPanel();
		panel.setBounds(10, 48, 652, 528);
		panel.setBackground(Color.white);
		getContentPane().add(panel);
		panel.setLayout(null);

		JPanel pnTittle = new JPanel();
		pnTittle.setBounds(0, 0, 746, 44);
		getContentPane().add(pnTittle);
		pnTittle.setBackground(Color.cyan);
		JLabel lblTitle = new JLabel("ĐẶT ĐĨA", JLabel.CENTER);
		lblTitle.setFont(new Font("Segoe UI", Font.BOLD, 25));
		pnTittle.add(lblTitle);

		lblMaKH = new JLabel("Mã khách hàng");
		lblMaKH.setFont(new Font("Segoe UI", Font.BOLD, 13));
		lblMaKH.setBounds(7, 10, 100, 40);
		panel.add(lblMaKH);
		txtMaKH = new JTextField();
		txtMaKH.setBounds(114, 10, 285, 40);
		txtMaKH.setFont(new Font("Segoe UI", Font.PLAIN, 15));
		txtMaKH.setColumns(10);
		txtMaKH.setToolTipText("Nhấn 'Enter' để kiểm tra ID khách hàng");
		panel.add(txtMaKH);

		lblTenKH = new JLabel("Khách hàng", JLabel.RIGHT);
		lblTenKH.setFont(new Font("Segoe UI", Font.BOLD, 13));
		lblTenKH.setBounds(7, 70, 83, 40);
		panel.add(lblTenKH);
		txtTenKH = new JTextField();
		txtTenKH.setEditable(false);
		txtTenKH.setBounds(114, 70, 285, 40);
		txtTenKH.setFont(new Font("Segoe UI", Font.PLAIN, 15));
		txtTenKH.setColumns(10);
		panel.add(txtTenKH);

		lblTuaDia = new JLabel("Tựa đĩa", JLabel.RIGHT);
		lblTuaDia.setFont(new Font("Segoe UI", Font.BOLD, 13));
		lblTuaDia.setBounds(7, 130, 83, 40);
		panel.add(lblTuaDia);
		txtTuaDia = new JTextField();
		txtTuaDia.setBounds(114, 130, 285, 40);
		txtTuaDia.setFont(new Font("Segoe UI", Font.PLAIN, 15));
		txtTuaDia.setColumns(10);
		panel.add(txtTuaDia);

		panel.add(scrollTimKiemTua = new JScrollPane());
		scrollTimKiemTua.setBounds(114, 172, 285, 100);
		modelList = new DefaultListModel<>();
		dsTuaDia = new JList<>();
		dsTuaDia.setModel(modelList);
		dsTuaDia.setFont(new Font("Segoe UI", Font.PLAIN, 15));
		dsTuaDia.setSelectionMode(ListSelectionModel.SINGLE_SELECTION);
		scrollTimKiemTua.setViewportView(dsTuaDia);
		scrollTimKiemTua.setVisible(false);

		lblLoaiDia = new JLabel("Loại đĩa", JLabel.RIGHT);
		lblLoaiDia.setFont(new Font("Segoe UI", Font.BOLD, 13));
		lblLoaiDia.setBounds(7, 190, 83, 41);
		panel.add(lblLoaiDia);
		radPhim = new JRadioButton("Phim");
		radPhim.setFont(new Font("Segoe UI", Font.BOLD, 15));
		radPhim.setBounds(133, 190, 117, 36);
		radPhim.setBackground(Color.white);
		radPhim.setToolTipText("Tựa này là Phim");
		panel.add(radPhim);
		radGame = new JRadioButton("Game");
		radGame.setFont(new Font("Segoe UI", Font.BOLD, 15));
		radGame.setBounds(252, 190, 117, 36);
		radGame.setToolTipText("Tựa này là Game");
		radGame.setBackground(Color.white);
		panel.add(radGame);

		ButtonGroup groupbtn = new ButtonGroup();
		groupbtn.add(radGame);
		groupbtn.add(radPhim);
		radPhim.setEnabled(false);
		radGame.setEnabled(false);
		radGame.setSelected(true);

		panel.add(lblMota = new JLabel("Mô tả", JLabel.RIGHT));
		lblMota.setFont(new Font("Segoe UI", Font.BOLD, 13));
		lblMota.setBounds(7, 265, 83, 40);
		txaMoTa = new JTextArea(12,14);
		JScrollPane scrollPane = new JScrollPane(txaMoTa);
		txaMoTa.setEditable(false);
		txaMoTa.setFont(new Font("Segoe UI", Font.PLAIN, 15));
		txaMoTa.setColumns(10);
		txaMoTa.setForeground(Color.BLACK);
		scrollPane.setBounds(114, 250, 285, 100);
		scrollPane.setVerticalScrollBarPolicy(JScrollPane.VERTICAL_SCROLLBAR_ALWAYS);
		panel.add(scrollPane);

		btnLuu = new JButton("Đặt đĩa");
		btnLuu.setContentAreaFilled(false);
		btnLuu.setOpaque(true);
		btnLuu.setForeground(Color.white);
		btnLuu.setBorder(null);
		btnLuu.setBackground(Color.decode("#4CAF50"));
		btnLuu.setCursor(new Cursor(Cursor.HAND_CURSOR));
		btnLuu.setFont(new Font("Segoe UI", Font.BOLD, 15));
		btnLuu.setBounds(133, 400, 188, 51);
		panel.add(btnLuu);
		btnXoaRong = new JButton("Xóa rỗng");
		btnXoaRong.setContentAreaFilled(false);
		btnXoaRong.setOpaque(true);
		btnXoaRong.setForeground(Color.white);
		btnXoaRong.setBorder(null);
		btnXoaRong.setBackground(Color.decode("#C14008"));
		btnXoaRong.setCursor(new Cursor(Cursor.HAND_CURSOR));
		btnXoaRong.setFont(new Font("Segoe UI", Font.BOLD, 15));
		btnXoaRong.setBounds(341, 400, 188, 51);
		panel.add(btnXoaRong);

		panel.add(lblAnh = new JLabel(""));
		lblAnh.setBorder(BorderFactory.createLineBorder(Color.BLACK));
		lblAnh.setBounds(452, 130, 170, 220);

		btnLuu.addActionListener(this);
		btnXoaRong.addActionListener(this);
		dsTuaDia.addMouseListener(this);
		txtTuaDia.addKeyListener(this);
		txtMaKH.addKeyListener(this);
	}

	// Resize image
	public ImageIcon resizeImage(String imgPath, byte[] pic) {
		ImageIcon myImage = null;
		if (imgPath != null) {
			myImage = new ImageIcon(imgPath);
		}
		else {
			myImage = new ImageIcon(pic);
		}

		Image img1 = myImage.getImage();
		Image img2 = img1.getScaledInstance(lblAnh.getWidth(), lblAnh.getHeight(), Image.SCALE_SMOOTH);
		ImageIcon image = new ImageIcon(img2);
		return image;
	}
	
	public void xoaRongThongTinKhachHang() {
		txtMaKH.setText("");
		txtTenKH.setText("");
	}
	public void xoaRongThongTinTuaDia() {
		txtTuaDia.setText("");
		radPhim.setSelected(true);
		txaMoTa.setText("");
		lblAnh.setIcon(null);
	}

	// Tìm và đưa khách hàng vào textfield
	public void timKhachHangDuaVaoTextField(String idkh) {
		khachhangDat = khCon.timKhachHangTheoID(idkh);
		if(khachhangDat != null) {
			txtTenKH.setText(khachhangDat.getTenkh());
			txtTuaDia.requestFocus();
		}
		else {
			JOptionPane.showMessageDialog(this, "Mã khách hàng không đúng");
			txtMaKH.selectAll();
			txtMaKH.requestFocus();
		}
	}
	
	// đưa thông tin tựa đĩa vào textfield {
	public void duaThongTinTuaDiavaoTextField(TuaDia tuaDia) {
		txtTuaDia.setText(tuaDia.getTentua());
		if(tuaDia.getLoaidia().getMaloaidia() == 1)
			radPhim.setSelected(true);
		else
			radGame.setSelected(true);
		txaMoTa.setText(tuaDia.getMota());
		lblAnh.setIcon(resizeImage("images/" + tuaDia.getAnh(), null));
	}
	
	public void luuDatDiaCuaKhach() {
		boolean ktTuaHetDiaChua = false;
		for(Dia dia : tuadiaDat.getListDia()) {
			if(dia.getTrangthai().equals("S"))
				ktTuaHetDiaChua = true;
		}
		
		if(ktTuaHetDiaChua)
			JOptionPane.showMessageDialog(this, "Tựa này vẫn còn đĩa trên kệ. Bạn hãy thể thuê ngay bây giờ!");
		else {
			boolean ktTuaDat = datDiaCon.kiemtraTuaDat(khachhangDat.getIdkh(), tuadiaDat.getMatua());
			if(ktTuaDat != true) {
				DatDia datdia = new DatDia(khachhangDat, tuadiaDat, new Date(), null);
				datDiaCon.themDatDia(datdia);
				JOptionPane.showMessageDialog(this, "Đã đặt đĩa thành công");
				xoaRongThongTinKhachHang();
				xoaRongThongTinTuaDia();
			}
			else
				JOptionPane.showMessageDialog(this, khachhangDat.getTenkh() + " đã đặt tựa này trước đó");
		}
	}
	
	public void duaTuaDiaVaoJList(ArrayList<TuaDia> list) {
		for (TuaDia tuaDia : list) {
			modelList.addElement(tuaDia);
			dsTuaDia.setSelectedIndex(0);
		}
	}
	
	public boolean timTuaDia(String tua) {
		ArrayList<TuaDia> arrayTuaDia = new ArrayList<>();
		arrayTuaDia = tuaDiaCon.timThongTinTuaDia(tua);
		if(arrayTuaDia.size() > 0) {
			modelList.removeAllElements();
			duaTuaDiaVaoJList(arrayTuaDia);
			return true;
		}
		return false;
	}
	
	@Override
	public void actionPerformed(ActionEvent e) {
		Object ob = e.getSource();
		if(ob == btnXoaRong) {
			xoaRongThongTinKhachHang();
			xoaRongThongTinTuaDia();
		}
		else if(ob == btnLuu) {
			if(txtMaKH.getText().equals("")) {
				JOptionPane.showMessageDialog(this, "Mã khách hàng không được rỗng");
				txtMaKH.requestFocus();
				return;
			}
			if(txtTuaDia.getText().equals("")) {
				JOptionPane.showMessageDialog(this, "Tựa đĩa không được rỗng");
				txtTuaDia.requestFocus();
				return;
			}
			
			luuDatDiaCuaKhach();
		}
	}
	
	public void chonTuaDiaTrongJList() {
		tuadiaDat = dsTuaDia.getSelectedValue();
		duaThongTinTuaDiavaoTextField(tuadiaDat);
		scrollTimKiemTua.setVisible(false);
		txaMoTa.requestFocus();
	}

	@Override
	public void mouseClicked(MouseEvent e) {
		if(e.getSource() == dsTuaDia) {
			int row = dsTuaDia.getSelectedIndex();
			if(row != -1)
				chonTuaDiaTrongJList();
		}
	}

	@Override
	public void mouseEntered(MouseEvent e) {
		// TODO Auto-generated method stub

	}

	@Override
	public void mouseExited(MouseEvent e) {
		// TODO Auto-generated method stub

	}

	@Override
	public void mousePressed(MouseEvent e) {
		// TODO Auto-generated method stub

	}

	@Override
	public void mouseReleased(MouseEvent e) {
		// TODO Auto-generated method stub

	}

	@Override
	public void keyPressed(KeyEvent e) {
		if(e.getKeyCode() == KeyEvent.VK_ENTER) {
			Object ob = e.getSource();
			if(ob == txtMaKH) {
				if(!txtMaKH.getText().equals(""))
					timKhachHangDuaVaoTextField(txtMaKH.getText());
			}
			else if(ob == txtTuaDia) {
				if(!txtTuaDia.getText().equals("")) {
					if(dsTuaDia.getSelectedIndex() != -1)
						chonTuaDiaTrongJList();
				}
			}
		}
	}

	@Override
	public void keyReleased(KeyEvent e) {
		Object ob = e.getSource();
		
		if(ob == txtTuaDia) {
			if(!txtTuaDia.getText().equals("")) {
				boolean bTimTua = timTuaDia(txtTuaDia.getText());
				if(bTimTua == true)
					scrollTimKiemTua.setVisible(true);
				else
					scrollTimKiemTua.setVisible(false);
			}
			else {
				scrollTimKiemTua.setVisible(false);
				xoaRongThongTinTuaDia();
			}
		}
	}

	@Override
	public void keyTyped(KeyEvent e) {
		// TODO Auto-generated method stub
		
	}
}
