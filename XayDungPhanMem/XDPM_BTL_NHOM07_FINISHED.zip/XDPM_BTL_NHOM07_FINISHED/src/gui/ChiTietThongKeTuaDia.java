package gui;

import java.util.List;

import javax.swing.JDialog;
import javax.swing.JFrame;
import javax.swing.JLabel;

import org.jfree.chart.ChartFactory;
import org.jfree.chart.ChartPanel;
import org.jfree.chart.JFreeChart;
import org.jfree.data.general.DefaultPieDataset;
import org.jfree.data.general.PieDataset;

import entities.Dia;
import entities.TuaDia;

public class ChiTietThongKeTuaDia extends JDialog {
	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	private static int thue = 0,giu = 0,ton = 0;
	private static int count = 0;
	
	private static JFreeChart createChart(PieDataset dataset,TuaDia td) {
		JFreeChart chart = ChartFactory.createPieChart(
				"Chi tiết đĩa của "+td.getTentua(), dataset, true, true, true);
		return chart;
	}

	private static PieDataset createDataset(TuaDia td) {
		List<Dia>listd = td.getListDia();
		listd.forEach(x->{
			if(x.getTrangthai().equals("S"))
				ton++;
			else 
				if (x.getTrangthai().equals("H"))
					giu++;
				else
					if(x.getTrangthai().equals("R"))
						thue++;
		});
		count = ton+giu+thue;
		DefaultPieDataset dataset = new DefaultPieDataset();
		dataset.setValue("Số lượng đĩa được thuê", thue);
		dataset.setValue("Số lượng đĩa được khách hàng giữ",giu);
		dataset.setValue("Số lượng tồn kho",  ton);
		return dataset;
	}



	public ChiTietThongKeTuaDia(JFrame parent, TuaDia tuaDia, int slKHDatDia) {
		super(parent,true);
		setTitle("Thống kê chi tiết");
		setSize(600, 400);
		setLocationRelativeTo(null);
		setResizable(false);
		setDefaultCloseOperation(DISPOSE_ON_CLOSE);
		
		JFreeChart pieChart = createChart(createDataset(tuaDia),tuaDia);
		ChartPanel chartPanel = new ChartPanel(pieChart);
		getContentPane().add(chartPanel);
		chartPanel.setLayout(null);
		
		JLabel lblangC = new JLabel("Hiện có "+slKHDatDia+" Khách hàng đang trong hàng chờ đặt tựa này");
		lblangC.setBounds(151, 316, 304, 14);
		chartPanel.add(lblangC);
		
		JLabel lblTong = new JLabel("Tổng số lượng đĩa: " + count);
		lblTong.setBounds(10, 33, 144, 14);
		chartPanel.add(lblTong);
		
		ton = 0;
		thue = 0;
		giu = 0;
		
	}
}
