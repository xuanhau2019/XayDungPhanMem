package gui;

import java.awt.BorderLayout;
import java.awt.Color;
import java.awt.Component;
import java.awt.Dimension;
import java.awt.Font;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.MouseEvent;
import java.awt.event.MouseListener;
import java.text.DecimalFormat;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;

import javax.swing.Box;
import javax.swing.ImageIcon;
import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.JScrollPane;
import javax.swing.JTable;
import javax.swing.JTextField;
import javax.swing.table.DefaultTableModel;
import javax.swing.table.JTableHeader;
import javax.swing.table.TableCellRenderer;

import control.PhiTreHanControl;
import control.PhieuThueControl;
import control.ThanhToanTreHanControl;
import entities.ChiTietPhieuThue;
import entities.KhachHang;
import entities.PhiTreHan;
import entities.ThanhToanTreHan;

@SuppressWarnings("serial")
public class Form_ThanhToanPhiTreHan extends JFrame implements ActionListener, MouseListener {
	
	JLabel lblTD, lblTenKH, lblSodt, lblDiaChi, lblTongTien;
	JLabel lblgtTenKH, lblgtSodt, lblgtDiachi;
	JTextField txtTongTien;
	JButton btnTT, btnHuy, btnXemChiTiet;
	DefaultTableModel modPTreHan;
	JTable tabPTreHan;
	
	PhiTreHanControl ptreCon = new PhiTreHanControl();
	ThanhToanTreHanControl ttTreHanCon = new ThanhToanTreHanControl();
	double sumTien = 0;
	ArrayList<PhiTreHan> listPhiTreHan = new ArrayList<>();
	DecimalFormat dmf = new DecimalFormat("#,##0");
	SimpleDateFormat sd = new SimpleDateFormat("yyyy-MM-dd");
	
	public Form_ThanhToanPhiTreHan(KhachHang kh) {
		setTitle("Thanh toán phí trể hạn");
		setSize(750,400);
		setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
		setLocationRelativeTo(null);
		setResizable(false);
		
		// Tạo frame thanh toán
		JPanel pNorth = new JPanel();
		pNorth.setBackground(Color.CYAN);
		pNorth.add(lblTD = new JLabel("THANH TOÁN PHÍ TRỄ HẠN"));
		lblTD.setFont(new Font("Calibri Light", Font.BOLD, 25));
		add(pNorth, BorderLayout.NORTH);
		
		JPanel pnCenter = new JPanel();
		pnCenter.setLayout(new BorderLayout());
//		JPanel pnConCenter = new JPanel();
//		pnConCenter.setLayout(new BorderLayout());
//		pnConCenter.setPreferredSize(new Dimension(750,75));
//		JPanel pnCenNor = new JPanel();
//		pnCenNor.setLayout(null);
//		pnCenNor.add(lblTenKH = new JLabel("Khách hàng:",JLabel.RIGHT));
//		pnCenNor.add(lblgtTenKH = new JLabel(kh.getTenkh()));
//		lblTenKH.setBounds(15, 5, 80, 20);
//		lblgtTenKH.setBounds(110, 5, 300, 20);
//		pnCenNor.add(lblSodt = new JLabel("Số điện thoại:", JLabel.RIGHT));
//		pnCenNor.add(lblgtSodt = new JLabel(kh.getSodt()));
//		lblSodt.setBounds(15, 25, 80, 20);
//		lblgtSodt.setBounds(110, 25, 300, 20);
//		pnCenNor.add(lblDiaChi = new JLabel("Địa chỉ:", JLabel.RIGHT));
//		pnCenNor.add(lblgtDiachi = new JLabel(kh.getDiachi()));
//		lblDiaChi.setBounds(15, 45, 80, 20);
//		lblgtDiachi.setBounds(110, 45, 300, 20);
//		pnConCenter.add(pnCenNor);
//		pnCenter.add(pnConCenter, BorderLayout.NORTH);
		
		Box bCen = Box.createVerticalBox();
		bCen.add(Box.createVerticalStrut(7));
		String[] arr1 = {"STT", "Mã trễ hạn", "Khách hàng", "Số điện thoại", "Mã đĩa", "Tựa đĩa", "Tiền nợ"};
		modPTreHan = new DefaultTableModel(arr1, 0);
		tabPTreHan = new JTable(modPTreHan) {
			public boolean isCellEditable(int rowIndex, int colIndex) {
				return false;   //Disallow the editing of any cell
			}
			// Chỉnh màu cho body table
			public Component prepareRenderer(TableCellRenderer renderer, int row, int col) {
				Component c = super.prepareRenderer(renderer, row, col);
				if(row % 2 == 0 && !isCellSelected(row,col))
					c.setBackground(Color.decode("#F1F1F1"));
				else
					if(!isCellSelected(row,col))
						c.setBackground(Color.decode("#D7F1FF"));
					else
						c.setBackground(Color.decode("#25C883"));
				return c;
			}
		};
		// Chỉnh màu cho tiêu đề table
		JTableHeader header2 = tabPTreHan.getTableHeader();
		header2.setBackground(Color.decode("#007ECA"));
		header2.setForeground(Color.WHITE);
		header2.setFont(new Font("Calibri Light", Font.ITALIC, 16));
		header2.setOpaque(false);

		tabPTreHan.setRowHeight(25);
		tabPTreHan.getColumnModel().getColumn(0).setPreferredWidth(1);
		tabPTreHan.setAutoCreateRowSorter(true);					// sắp xếp
		JScrollPane scoll1 = new JScrollPane(tabPTreHan);
		bCen.add(scoll1);
		pnCenter.add(bCen, BorderLayout.CENTER);

		add(pnCenter, BorderLayout.CENTER);

		JPanel pSouth = new JPanel();
//		pSouth.setLayout(new BorderLayout());
		Box bSou = Box.createVerticalBox();
		bSou.add(Box.createVerticalStrut(10));
		Box b8, b9;
		bSou.add(b8 = Box.createHorizontalBox());
		b8.add(Box.createVerticalStrut(15));
		b8.add(Box.createHorizontalStrut(520));
		b8.add(lblTongTien = new JLabel("Tổng tiền"));
		b8.add(Box.createHorizontalStrut(15));
		b8.add(txtTongTien = new JTextField(10));
		txtTongTien.setPreferredSize(new Dimension(0, 22));
		txtTongTien.setEditable(false);
		txtTongTien.setText("0");
		b8.add(Box.createHorizontalStrut(20));
		b8.add(new JLabel("VND"));
		b8.add(Box.createHorizontalStrut(20));
		bSou.add(Box.createVerticalStrut(20));
		bSou.add(b9 = Box.createHorizontalBox());
		b9.add(Box.createHorizontalStrut(170));
		b9.add(btnTT = new JButton("Thanh toán", new ImageIcon("images/thanhtoan.png")));
		b9.add(Box.createHorizontalStrut(30));
		b9.add(btnXemChiTiet = new JButton(new ImageIcon("images/chitiet.png")));
		b9.add(Box.createHorizontalStrut(30));
		b9.add(btnHuy = new JButton("      Hủy      ", new ImageIcon("images/cancal.png")));
		b9.add(Box.createVerticalStrut(10));
		pSouth.add(bSou);
		add(pSouth, BorderLayout.SOUTH);
		
		btnTT.addActionListener(this);
		btnHuy.addActionListener(this);
		btnXemChiTiet.addActionListener(this);
		tabPTreHan.addMouseListener(this);
		
		listPhiTreHan = ptreCon.layPhiTreHanCuaKhachHang(kh.getIdkh());
		duaPhiTreHanVaoTable(listPhiTreHan);
	}
	
	public void duaPhiTreHanVaoTable(ArrayList<PhiTreHan> list) {
		modPTreHan.setNumRows(0);
		sumTien = 0;
		
		if(list.size() > 0) {
			PhieuThueControl pthueCon = new PhieuThueControl();
			PhiTreHan ptre = new PhiTreHan();
			ChiTietPhieuThue ctpt = new ChiTietPhieuThue();
			KhachHang kh = null;
			
			for(int i =  0; i < list.size(); i++) {
				ptre = list.get(i);
				kh = ptre.getPhieutra().getPhieuthue().getKh();
				ctpt = pthueCon.timChiTietPhieuThue(ptre.getPhieutra().getPhieuthue(),ptre.getPhieutra().getDia()).get(0);
				String[] a = {Integer.toString(i + 1), ptre.getMatrehan(), kh.getTenkh(), kh.getSodt(), ctpt.getDia().getMadia(),
								ctpt.getDia().getTuadia().getTentua(), dmf.format(ptre.getTienno())};
				modPTreHan.addRow(a);
				sumTien += ptre.getTienno();
			}
		}
		
		txtTongTien.setText(dmf.format(sumTien));
	}

	// Tự động cấp mã thanh toán
	public String capnhatMaThanhToanTreHan() {
		String matt = ttTreHanCon.getLastMaThanhToanTreHan();
		if(matt == null)
			matt = "TT_0000001";
		else {
			int stt = Integer.parseInt(matt.replaceAll("TT_", "")) + 1;
			if(stt < 10)
				matt = "TT_000000" + stt;
			else if(stt < 100)
				matt = "TT_00000" + stt;
			else if(stt < 1000)
				matt = "TT_0000" + stt;
			else if(stt < 10000)
				matt = "TT_000" + stt;
			else if(stt < 100000)
				matt = "TT_00" + stt;
			else if(stt < 1000000)
				matt = "TT_0" + stt;
			else
				matt = "TT_" + stt;
		}
		return matt;
	}
	
	// Xóa phí trễ hạn trong mảng tạm và bảng
	public void xoaPhiTreHanDaThanhToan(int n) {
		listPhiTreHan.remove(n);
		modPTreHan.removeRow(n);
	}
	
	public void clickXemChiTiet() {
		int row = tabPTreHan.getSelectedRow();
		if(row != -1)
			new Form_XemChiTietPhiTreHan(tabPTreHan.getValueAt(row, 1).toString()).setVisible(true);
		else
			JOptionPane.showMessageDialog(this, "Chưa chọn phí trễ hạn");
	}
	
	@Override
	public void actionPerformed(ActionEvent e) {
		Object ob = e.getSource();
		if(ob == btnTT) {			
			int[] rows = tabPTreHan.getSelectedRows();
			if(rows.length > 0) {
				
				int n = rows.length, dem = 0;
				String matrehan = "";
				for (int i = 0; i < n; i++) {
					matrehan = tabPTreHan.getValueAt(rows[i] - dem, 1).toString();
					PhiTreHan ptre = ptreCon.timPhiTreHan(matrehan);

					ThanhToanTreHan tt = new ThanhToanTreHan(capnhatMaThanhToanTreHan(), ptre, new Date());
					ttTreHanCon.themThanhToanTreHan(tt);
					xoaPhiTreHanDaThanhToan(rows[i] - dem);
					dem++;
				}
				duaPhiTreHanVaoTable(listPhiTreHan);
				JOptionPane.showMessageDialog(this, "Thanh toán thành công");
			}
			else
				JOptionPane.showMessageDialog(this, "Chưa chọn phí trễ hạn để thanh toán");
		}
		else if(ob == btnHuy)
			this.dispose();
		else if(ob == btnXemChiTiet)
			clickXemChiTiet();
	}

	@Override
	public void mouseClicked(MouseEvent e) {
		int[] rows = tabPTreHan.getSelectedRows();
		double sum = 0;
		if(rows.length > 0) {
			double tienno = 0;
			for (int i = 0; i < rows.length; i++) {
				tienno = Double.parseDouble(tabPTreHan.getValueAt(rows[i], 6).toString().replaceAll(",", ""));
				sum += tienno;
			}
			txtTongTien.setText(dmf.format(sum));
		}
		else
			txtTongTien.setText(dmf.format(sumTien));
		
		if(e.getClickCount() == 2) {
			int row = tabPTreHan.getSelectedRow();
			if(row != -1)
				new Form_XemChiTietPhiTreHan(tabPTreHan.getValueAt(row, 1).toString()).setVisible(true);
			else
				JOptionPane.showMessageDialog(this, "Chưa chọn phí trễ hạn");
		}
	}

	@Override
	public void mouseEntered(MouseEvent e) {}

	@Override
	public void mouseExited(MouseEvent e) {}

	@Override
	public void mousePressed(MouseEvent e) {}

	@Override
	public void mouseReleased(MouseEvent e) {}

}
