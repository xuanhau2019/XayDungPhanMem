package gui;

import java.awt.Color;
import java.awt.Component;
import java.awt.Dimension;
import java.awt.Font;
import java.awt.Image;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.FocusEvent;
import java.awt.event.FocusListener;
import java.awt.event.KeyEvent;
import java.awt.event.KeyListener;
import java.awt.event.MouseEvent;
import java.awt.event.MouseListener;
import java.awt.event.MouseMotionListener;
import java.text.DecimalFormat;
import java.util.List;

import javax.swing.Icon;
import javax.swing.ImageIcon;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.JScrollPane;
import javax.swing.JTable;
import javax.swing.JTextField;
import javax.swing.ListSelectionModel;
import javax.swing.table.DefaultTableModel;
import javax.swing.table.JTableHeader;
import javax.swing.table.TableCellRenderer;

import control.TuaDiaControl;
import entities.TuaDia;

public class ThongKeTuaDia extends JPanel implements ActionListener, MouseListener, FocusListener, KeyListener, MouseMotionListener {
	
	private static final long serialVersionUID = 1L;
	
	private JTable table;
	private DefaultTableModel tableModel;
	private JTextField txtTim;
	private JLabel lblTitle;

	private TuaDiaControl tuaDiaControl = new TuaDiaControl();
	private List<TuaDia> listTua = tuaDiaControl.getAllTuaDia();

	private JFrame parent = new JFrame();
	protected int rollOverRowIndex=-1;
	DecimalFormat dmf = new DecimalFormat("#,##0");
	ChiTietThongKeTuaDia tKTua;
	
	@SuppressWarnings("serial")
	public ThongKeTuaDia() {
		setLayout(null);

		JPanel panel = new JPanel();
		panel.setBackground(Color.WHITE);
		panel.setBounds(0, 0, 1200, 588);
		setBounds(0, 0, 1200, 588);
		add(panel);
		panel.setLayout(null);

		JPanel pnTitle = new JPanel();
		pnTitle.setBounds(0, 0, 1200, 35);
		pnTitle.setBackground(Color.CYAN);

		lblTitle = new JLabel("Quản lý Tựa Đĩa");
		lblTitle.setFont(new Font("Segoe UI", Font.BOLD, 18));

		pnTitle.add(lblTitle);

		panel.add(pnTitle);

		JScrollPane scrollPane = new JScrollPane();
		scrollPane.setBounds(10, 108, 1180, 469);
		panel.add(scrollPane);

		table = new JTable() {

			public Component prepareRenderer( TableCellRenderer renderer, int row, int col ) {
				Component c = super.prepareRenderer(renderer, row, col);
				c.setFont(new Font("Segoe UI", Font.BOLD, 15));
				if ( row % 2 == 0 && !isCellSelected(row, col)) {
					c.setBackground( Color.white );
				}
				else 
					if(!isCellSelected(row, col)){
						c.setBackground( Color.decode("#F1F1F1") );
					}else {
						c.setBackground(Color.decode("#009FFF"));
					}
				if( isRowSelected(row) || (row == rollOverRowIndex) ) {
					c.setForeground(Color.black);
					c.setBackground(Color.decode("#A9DFFF"));
				}
				else {
					c.setBackground(getBackground());
				}
				return c;

			}


		};
		table.setBorder(null);
		table.setFillsViewportHeight(true);
		table.setShowGrid(false);
		table.setIntercellSpacing(new Dimension(0, 5));

		JTableHeader header = table.getTableHeader();
		header.setBackground(Color.decode("#007ECA"));
		header.setForeground(Color.white);
		header.setOpaque(false);

		table.setModel(tableModel = new DefaultTableModel(
				new Object[][] {

				},
				new String[] {
						"Avatar", "Tên Tựa", "Loại", "Giá thuê (Đồng)", "Hạn thuê (ngày)", "Phí trễ hạn (Đồng)","Mô tả","Mã Tựa"
				}
				){
			boolean[] columnEditables = new boolean[] {
					false, false, false, false, false, false, false,false
			};
			public boolean isCellEditable(int row, int column) {
				return columnEditables[column];
			}
			@SuppressWarnings({ "unchecked", "rawtypes" })
			public Class getColumnClass(int column) {
				return (column == 0) ? Icon.class : Object.class;
			}

		});
		table.setPreferredScrollableViewportSize(table.getPreferredSize());
		scrollPane.setViewportView(table);        
		table.setRowHeight(280);
		table.getColumnModel().getColumn(0).setPreferredWidth(81);
		table.removeColumn(table.getColumnModel().getColumn(7));
		table.setSelectionMode(ListSelectionModel.SINGLE_SELECTION);
		table.getTableHeader().setReorderingAllowed(false);
		table.setToolTipText("Nhấp đôi chuột để xem chi tiết");

		txtTim = new JTextField();
		txtTim.setBounds(10, 60, 690, 34);
		txtTim.setText("Nhập thông tin để tìm kiếm...");
		txtTim.setFont(new Font("Segoe UI", Font.BOLD, 15));
		txtTim.setColumns(10);
		txtTim.setForeground(Color.decode("#9E9E9E"));
		panel.add(txtTim);

		JLabel lblTimKhachHang = new JLabel(">>Tìm Tựa");
		lblTimKhachHang.setFont(new Font("Segoe UI", Font.BOLD, 17));
		lblTimKhachHang.setForeground(new Color(255, 0, 255));
		lblTimKhachHang.setBounds(10, 31, 600, 30);
		panel.add(lblTimKhachHang);

		txtTim.addKeyListener(this);
		txtTim.addFocusListener(this);

		table.addMouseMotionListener(this);
		table.addMouseListener(this);

		showAllTuaDia(listTua);
	}
	public void showAllTuaDia(List<TuaDia> list) {
		while(tableModel.getRowCount() >= 1)
			tableModel.removeRow(0);

		list.forEach(x -> {
			ImageIcon img = new ImageIcon(new ImageIcon("images/"+x.getAnh()).getImage().getScaledInstance(170, 280, Image.SCALE_AREA_AVERAGING));
			String loai = "Phim";
			if(x.getLoaidia().getMaloaidia() == 2)
				loai = "Game";

			Object[] tx = {img, x.getTentua(), loai, dmf.format(x.getLoaidia().getGiathue()), x.getLoaidia().getHanthue()+"",
					dmf.format(x.getPhitrehan()),x.getMota(),x.getMatua()};
			tableModel.addRow(tx);
		});
	}
	@Override
	public void actionPerformed(ActionEvent e) {
		// TODO Auto-generated method stub
		
	}
	@Override
	public void mouseClicked(MouseEvent e) {
		Object o = e.getSource();
		if (o.equals(table)) {
			if (e.getClickCount()==2) {
				int row = table.getSelectedRow();
				TuaDia td = tuaDiaControl.getTuaByID(table.getModel().getValueAt(row, 7).toString());
				int slKhDatDia = tuaDiaControl.soLuongKhachDatTua(td.getMatua());
				tKTua = new ChiTietThongKeTuaDia(parent, td, slKhDatDia);
				tKTua.setVisible(true);
			}
		}
		
		
	}

	@Override
	public void mousePressed(MouseEvent e) {}

	@Override
	public void mouseReleased(MouseEvent e) {}
	@Override
	public void mouseEntered(MouseEvent e) {

	}

	@Override
	public void mouseExited(MouseEvent e) {
		Object o = e.getSource();
		if(o.equals(table)) {
			table.setToolTipText("Nhấn double click để xem thống kê");
			rollOverRowIndex = -1;
			repaint();
		}
	}

	@Override
	public void keyTyped(KeyEvent e) {
		// TODO Auto-generated method stub

	}

	@Override
	public void keyPressed(KeyEvent e) {
		Object o = e.getSource();
		if(o.equals(txtTim)) {
			if(txtTim.getText().length()>100) {
				JOptionPane.showMessageDialog(this, "Bạn đã nhập quá nhiều!");
			}
		}
	}

	@Override
	public void keyReleased(KeyEvent e) {
		Object o = e.getSource();
		if(o.equals(txtTim)) {
			List<TuaDia> list = tuaDiaControl.timThongTinTuaDia(txtTim.getText());
			showAllTuaDia(list);
		}
	}

	@Override
	public void focusGained(FocusEvent e) {
		Object o = e.getSource();
		if(o.equals(txtTim)&&txtTim.getText().equals("Nhập thông tin để tìm kiếm...")) {
			txtTim.setText("");
			txtTim.setForeground(Color.black);
		}
	}

	@Override
	public void focusLost(FocusEvent e) {
		Object o = e.getSource();
		if(o.equals(txtTim)&&txtTim.getText().equals("")) {
			txtTim.setText("Nhập thông tin để tìm kiếm...");
			txtTim.setForeground(Color.LIGHT_GRAY);
		}
	}

	@Override
	public void mouseDragged(MouseEvent e) {
		// TODO Auto-generated method stub

	}

	@Override
	public void mouseMoved(MouseEvent e) {
		int row = table.rowAtPoint(e.getPoint());
		if( row != rollOverRowIndex ) {
			rollOverRowIndex = row;
			repaint();
		}
	}


}
