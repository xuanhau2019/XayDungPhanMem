package gui;

import java.awt.BorderLayout;
import java.awt.Color;
import java.awt.Component;
import java.awt.Dimension;
import java.awt.Font;
import java.awt.Image;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.KeyEvent;
import java.awt.event.KeyListener;
import java.awt.event.MouseEvent;
import java.awt.event.MouseListener;
import java.text.DecimalFormat;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;

import javax.swing.BorderFactory;
import javax.swing.Box;
import javax.swing.DefaultListModel;
import javax.swing.ImageIcon;
import javax.swing.JButton;
import javax.swing.JLabel;
import javax.swing.JList;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.JScrollPane;
import javax.swing.JTable;
import javax.swing.JTextField;
import javax.swing.ListSelectionModel;
import javax.swing.table.DefaultTableModel;
import javax.swing.table.JTableHeader;
import javax.swing.table.TableCellRenderer;

import control.DatDiaControl;
import control.DiaControl;
import control.KhachHangControl;
import control.PhiTreHanControl;
import control.PhieuThueControl;
import entities.ChiTietPhieuThue;
import entities.DatDia;
import entities.Dia;
import entities.KhachHang;
import entities.PhiTreHan;
import entities.PhieuThue;

@SuppressWarnings("serial")
public class ChoThueDia extends JPanel implements ActionListener, KeyListener, MouseListener {
	
	JLabel lblTD, lblTim, lblMaKH, lblTenKH, lblGhiChu, lblMaPT, lblNgayLap, lblMaDia, lblTuaDia,
	lblLoaiDia, lblGiaThue, lblHanThue, lblPhiTreHan, lblTongTien, lblAnh;
	JLabel lblgtGhiChu;
	JTextField txtMaKH, txtTenKH, txtMaPT, txtNgayLap, txtMaDia, txtTuaDia,
	txtLoaiDia, txtGiaThue, txtHanThue, txtPhiTreHan, txtTongTien;
	JButton btnThem, btnXoa, btnLuu, btnHuy, btnThanhToan;
	DefaultTableModel modCTPT;
	JTable tabCTPT;
	
	JList<Dia> listDia;
	DefaultListModel<Dia> modelList;
	JScrollPane scrollTimKiemDia;
	
	PhieuThueControl pthuecon = new PhieuThueControl();
	DiaControl diacon = new DiaControl();
	DatDiaControl datdiaControl = new DatDiaControl();
	
	ArrayList<ChiTietPhieuThue> arrayCTPT = new ArrayList<>();
	DecimalFormat dmf = new DecimalFormat("#,##0");
	SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd");
	double tongtien = 0;
	Date nowday = new Date();
	KhachHang khThueDia = null;											// Tạo đối tượng này để lưu lại khách hàng tạm thời
	Dia diaThue = null;													// Tạo đối tượng này để lưu lại đĩa tạm thời
	
	public ChoThueDia() {
		setLayout(null);
		JPanel panel = new JPanel();
		panel.setBounds(0, 0, 1200, 588);
		setBounds(0, 0, 1200, 588);
		add(panel);
		
		// ------------------ NORTH ------------------ //
		JPanel pNorth = new JPanel();
		pNorth.setBackground(Color.CYAN);
		pNorth.setLayout(new BorderLayout());
		pNorth.setPreferredSize(new Dimension(1200, 35));
		pNorth.add(lblTD = new JLabel("PHIẾU THUÊ", JLabel.CENTER));
		lblTD.setFont(new Font("Calibri Light", Font.BOLD, 27));
		panel.add(pNorth, BorderLayout.NORTH);

		// ------------------ CENTER ------------------ //
		JPanel pnCenMid = new JPanel();
		pnCenMid.setLayout(new BorderLayout());
		JPanel pnContain = new JPanel();
		pnContain.setLayout(new BorderLayout());
		JPanel pnConNor = new JPanel();
		pnConNor.setLayout(new BorderLayout());
		pnConNor.setPreferredSize(new Dimension(1200,90));
		pnConNor.setBorder(BorderFactory.createTitledBorder("Phiếu thuê"));
		JPanel pnBoxNor = new JPanel();
		pnBoxNor.setLayout(null);
		pnBoxNor.add(lblMaPT = new JLabel("Mã phiếu thuê"));
		pnBoxNor.add(txtMaPT = new JTextField());
		lblMaPT.setBounds(80, 3, 90, 20);
		txtMaPT.setBounds(175, 3, 200, 22);
		pnBoxNor.add(lblNgayLap = new JLabel("Ngày lập"));
		pnBoxNor.add(txtNgayLap = new JTextField());
		lblNgayLap.setBounds(420, 3, 100, 20);
		txtNgayLap.setBounds(490, 3, 200, 22);
		pnBoxNor.add(lblGhiChu = new JLabel("Ghi chú (*):"));
		pnBoxNor.add(lblgtGhiChu = new JLabel(""));
		lblgtGhiChu.setForeground(Color.GRAY);
		lblgtGhiChu.setFont(new Font("Calibri Light", Font.BOLD, 14));
		lblGhiChu.setBounds(732, 33, 100, 20);

		pnBoxNor.add(lblMaKH = new JLabel("ID khách hàng"));
		pnBoxNor.add(txtMaKH = new JTextField());
		lblMaKH.setBounds(80, 33, 90, 20);
		txtMaKH.setBounds(175, 33, 200, 22);
		pnBoxNor.add(lblTenKH = new JLabel("Khách hàng"));
		pnBoxNor.add(txtTenKH = new JTextField());
		lblTenKH.setBounds(420, 33, 100, 20);
		txtTenKH.setBounds(490, 33, 200, 22);
		pnBoxNor.add(btnThanhToan = new JButton("Thanh toán", new ImageIcon("images/thanhtoan.png")));
		btnThanhToan.setBounds(810, 33, 120, 30);
		
		pnConNor.add(pnBoxNor);
		pnContain.add(pnConNor, BorderLayout.NORTH);

		JPanel pnConCenter = new JPanel();
		pnConCenter.setLayout(new BorderLayout());
		pnConCenter.setPreferredSize(new Dimension(1200,160));
		pnConCenter.setBorder(BorderFactory.createTitledBorder("Chi tiết phiếu thuê"));
		JPanel pnBoxMid = new JPanel();
		pnBoxMid.setLayout(null);
		pnBoxMid.add(lblMaDia = new JLabel("Mã đĩa", JLabel.CENTER));
		pnBoxMid.add(txtMaDia = new JTextField());
		lblMaDia.setBounds(80, 3, 90, 20);
		txtMaDia.setBounds(175, 3, 200, 22);
		pnBoxMid.add(scrollTimKiemDia = new JScrollPane());
		scrollTimKiemDia.setBounds(175, 26, 200, 80);
		modelList = new DefaultListModel<>();
		listDia = new JList<>();
		listDia.setModel(modelList);
		listDia.setFont(new Font("Segoe UI", Font.PLAIN, 15));
		listDia.setSelectionMode(ListSelectionModel.SINGLE_SELECTION);
		scrollTimKiemDia.setViewportView(listDia);
		scrollTimKiemDia.setVisible(false);
		
		pnBoxMid.add(lblTuaDia = new JLabel("Tựa đĩa"));
		pnBoxMid.add(txtTuaDia = new JTextField());
		lblTuaDia.setBounds(420, 3, 100, 20);
		txtTuaDia.setBounds(490, 3, 200, 22);

		pnBoxMid.add(lblLoaiDia = new JLabel("Loại đĩa", JLabel.CENTER));
		pnBoxMid.add(txtLoaiDia = new JTextField());
		lblLoaiDia.setBounds(80, 33, 90, 20);
		txtLoaiDia.setBounds(175, 33, 200, 22);
		pnBoxMid.add(lblPhiTreHan = new JLabel("Phí trể hạn"));
		pnBoxMid.add(txtPhiTreHan = new JTextField());
		lblPhiTreHan.setBounds(420, 33, 100, 20);
		txtPhiTreHan.setBounds(490, 33, 200, 22);

		pnBoxMid.add(lblHanThue = new JLabel("Hạn thuê (ngày)"));
		pnBoxMid.add(txtHanThue = new JTextField());
		lblHanThue.setBounds(80, 63, 90, 20);
		txtHanThue.setBounds(175, 63, 200, 22);
		pnBoxMid.add(lblGiaThue = new JLabel("Giá thuê"));
		pnBoxMid.add(txtGiaThue = new JTextField());
		lblGiaThue.setBounds(420, 63, 100, 20);
		txtGiaThue.setBounds(490, 63, 200, 22);

		pnBoxMid.add(lblAnh = new JLabel());
		lblAnh.setBorder(BorderFactory.createLineBorder(Color.BLACK));
		lblAnh.setBounds(820, 3, 225, 125);

		pnBoxMid.add(btnThem = new JButton("      Thêm", new ImageIcon("images/add.png")));
		btnThem.setBounds(175, 100, 200, 30);
		pnBoxMid.add(btnXoa = new JButton("      Xóa", new ImageIcon("images/xoa.png")));
		btnXoa.setBounds(490, 100, 200, 30);
		pnConCenter.add(pnBoxMid);
		pnContain.add(pnConCenter, BorderLayout.CENTER);
		pnCenMid.add(pnContain, BorderLayout.NORTH);

		JPanel pnMiddel = new JPanel();
		pnMiddel.setLayout(new BorderLayout());
		pnMiddel.setPreferredSize(new Dimension(1200,185));
		Box boxTable = Box.createVerticalBox();
		boxTable.setBorder(BorderFactory.createTitledBorder("Bảng phiếu thuê"));
		String[] arr1 = {"STT", "Mã đĩa", "Tựa đĩa", "Loại đĩa", "Phí trễ hạn", "Hạn thuê (ngày)", "Giá thuê"};
		modCTPT = new DefaultTableModel(arr1, 0);
		tabCTPT = new JTable(modCTPT) {
			// Chỉnh màu cho body table
			public Component prepareRenderer(TableCellRenderer renderer, int row, int col) {
				Component c = super.prepareRenderer(renderer, row, col);
				if(row % 2 == 0 && !isCellSelected(row,col))
					c.setBackground(Color.decode("#F1F1F1"));
				else
					if(!isCellSelected(row,col))
						c.setBackground(Color.decode("#D7F1FF"));
					else
						c.setBackground(Color.decode("#25C883"));
				return c;
			}
		};
		// Chỉnh màu cho tiêu đề table
		JTableHeader header = tabCTPT.getTableHeader();
		header.setBackground(Color.decode("#007ECA"));
		header.setForeground(Color.WHITE);
		header.setFont(new Font("Calibri Light", Font.ITALIC, 16));
		header.setOpaque(false);

		tabCTPT.setRowHeight(25);
		tabCTPT.getColumnModel().getColumn(0).setPreferredWidth(2);
		tabCTPT.setAutoCreateRowSorter(true);							// sắp xếp
//		tabCTPT.setAutoResizeMode(JTable.AUTO_RESIZE_OFF);				// hiện thanh trượt ngang ở dưới
		tabCTPT.setSelectionMode(ListSelectionModel.SINGLE_SELECTION); 	// thiết lập chỉ cho chọn 1 hàng trong bảng
		JScrollPane scoll2 = new JScrollPane(tabCTPT);
		boxTable.add(scoll2);
		pnMiddel.add(boxTable, BorderLayout.CENTER);
		pnCenMid.add(pnMiddel, BorderLayout.CENTER);
		panel.add(pnCenMid, BorderLayout.CENTER);


		// ------------------ SOUTH ------------------ //
		JPanel pSouth = new JPanel();
		pSouth.setLayout(new BorderLayout());
		Box bSou = Box.createVerticalBox();
		bSou.add(Box.createVerticalStrut(10));
		Box b8, b9;
		bSou.add(b8 = Box.createHorizontalBox());
		b8.add(Box.createVerticalStrut(15));
		b8.add(Box.createHorizontalStrut(880));
		b8.add(lblTongTien = new JLabel("Tổng tiền"));
		b8.add(Box.createHorizontalStrut(15));
		b8.add(txtTongTien = new JTextField(20));
		txtTongTien.setPreferredSize(new Dimension(0, 22));
		txtTongTien.setEditable(false);
		txtTongTien.setText("0");
		b8.add(Box.createHorizontalStrut(20));
		b8.add(new JLabel("VND"));
		b8.add(Box.createHorizontalStrut(10));
		bSou.add(Box.createVerticalStrut(2));
		bSou.add(b9 = Box.createHorizontalBox());
		b9.add(Box.createHorizontalStrut(360));
		b9.add(btnLuu = new JButton("   Lưu phiếu thuê", new ImageIcon("images/save.png")));
		b9.add(Box.createHorizontalStrut(30));
		b9.add(btnHuy = new JButton("   Hủy phiếu thuê", new ImageIcon("images/cancal.png")));
		btnLuu.setPreferredSize(new Dimension(200, 80));
		btnHuy.setPreferredSize(btnLuu.getPreferredSize());
		b9.add(Box.createVerticalStrut(10));
		pSouth.add(bSou);
		panel.add(pSouth, BorderLayout.SOUTH);

		eventAction();
		eventTextField();
		
		hiddenTextField(false);
		txtMaDia.setEditable(false);
		btnLuu.setEnabled(false);
		btnHuy.setEnabled(false);
		btnXoa.setEnabled(false);
		btnThanhToan.setVisible(false);

		txtMaPT.setText(capnhatMaPhieuThue());				// gán mã phiếu thuê
		txtNgayLap.setText(sdf.format(nowday));
		
		txtMaKH.setToolTipText("Nhấn 'Enter' để tìm khách hàng");
		txtMaDia.setToolTipText("Nhấn 'Enter' để tìm đĩa");
	}
	
	// Resize image
	public ImageIcon resizeImage(String imgPath, byte[] pic) {
		ImageIcon myImage = null;
		if (imgPath != null) {
			myImage = new ImageIcon(imgPath);
		}
		else {
			myImage = new ImageIcon(pic);
		}

		Image img1 = myImage.getImage();
		Image img2 = img1.getScaledInstance(lblAnh.getWidth(), lblAnh.getHeight(), Image.SCALE_SMOOTH);
		ImageIcon image = new ImageIcon(img2);
		return image;
	}
	
	// Tự cập nhật phiếu thuê
	public String capnhatMaPhieuThue() {
		String mapt = pthuecon.getLastMaPhieuThue();
		if(mapt == null)
			mapt = "PTHUE_0000001";
		else {
			int stt = Integer.parseInt(mapt.replaceAll("PTHUE_", "")) + 1;
			if(stt < 10)
				mapt = "PTHUE_000000" + stt;
			else if(stt < 100)
				mapt = "PTHUE_00000" + stt;
			else if(stt < 1000)
				mapt = "PTHUE_0000" + stt;
			else if(stt < 10000)
				mapt = "PTHUE_000" + stt;
			else if(stt < 100000)
				mapt = "PTHUE_00" + stt;
			else if(stt < 1000000)
				mapt = "PTHUE_0" + stt;
			else
				mapt = "PTHUE_" + stt;
		}
		return mapt;
	}

	// Bắt sự kiện button
	public void eventAction() {
		btnThem.addActionListener(this);
		btnXoa.addActionListener(this);
		btnLuu.addActionListener(this);
		btnHuy.addActionListener(this);
		btnThanhToan.addActionListener(this);
		
		tabCTPT.addMouseListener(this);
		listDia.addMouseListener(this);
	}
	// Bắt sự kiện text field
	public void eventTextField() {
		txtMaDia.addKeyListener(this);
		txtMaKH.addKeyListener(this);
	}

	// Ẩn textfield
	public void hiddenTextField(boolean b) {
		txtMaPT.setEditable(b);
		txtNgayLap.setEditable(b);
		txtTenKH.setEditable(b);
		txtTuaDia.setEditable(b);
		txtLoaiDia.setEditable(b);
		txtPhiTreHan.setEditable(b);
		txtHanThue.setEditable(b);
		txtGiaThue.setEditable(b);
	}

	// Xóa trắng TextField Khách hàng
	public void xoatrangFieldKhachHang() {
		txtMaKH.setText("");
		txtTenKH.setText("");
	}
	// Xóa trắng TextField Đĩa
	public void xoatrangFieldDia() {
		txtMaDia.setText("");
		txtTuaDia.setText("");
		txtLoaiDia.setText("");
		txtPhiTreHan.setText("");
		txtHanThue.setText("");
		txtGiaThue.setText("");
		lblAnh.setIcon(null);
	}

	// Hủy phiếu thuê
	public void huyPhieuThue() {
		txtMaPT.setText(capnhatMaPhieuThue());
		xoatrangFieldKhachHang();
		xoatrangFieldDia();
		modCTPT.setNumRows(0);
		arrayCTPT = new ArrayList<>();
		tongtien = 0;
		txtTongTien.setText("0");
		txtMaDia.setEditable(false);
		btnHuy.setEnabled(false);
		btnXoa.setEnabled(false);
		btnLuu.setEnabled(false);
	}
	
	public void duaDiaVaoJList(ArrayList<Dia> list) {
		for (Dia dia : list) {
			modelList.addElement(dia);
			listDia.setSelectedIndex(0);
		}
	}
	public void chonDiaTrongJList() {
		diaThue = listDia.getSelectedValue();
		timDiaDuaVaoTextField(diaThue);

		scrollTimKiemDia.setVisible(false);
		modelList.removeAllElements();
	}

	// Tìm thông tin khách hàng và đưa vào TextField
	public void timvaduaThongTinKHvaoTextField(String idkh) {
		KhachHangControl khcon = new KhachHangControl();
		khThueDia = khcon.timKhachHangTheoID(idkh);
		if(khThueDia != null) {
			txtTenKH.setText(khThueDia.getTenkh());
			
			thongbaoPhiTreHan(khThueDia);
			
			// Cho phép nhập thông tin đĩa
			txtMaDia.setEditable(true);
			txtMaDia.requestFocus();
			btnHuy.setEnabled(true);
			btnLuu.setEnabled(true);
		}
		else {
			JOptionPane.showMessageDialog(this, "Mã khách hàng không đúng");
			txtMaKH.selectAll();
			txtMaKH.requestFocus();
		}
	}
	
	// thông báo phí trễ hạn của khách hàng
	public void thongbaoPhiTreHan(KhachHang kh) {
		// Kiểm tra xem khách hàng có phí trể hạn hay không?
		PhiTreHanControl trehanCon = new PhiTreHanControl();
		ArrayList<PhiTreHan> arrayTreHan = new ArrayList<>();
		arrayTreHan = trehanCon.layPhiTreHanCuaKhachHang(kh.getIdkh());
		double tongtien = 0;
		if(arrayTreHan.size() > 0) {
			for (PhiTreHan phiTreHan : arrayTreHan)
				tongtien += phiTreHan.getTienno();
		}
		
		if(tongtien > 0) {
			lblGhiChu.setBounds(732, 3, 100, 20);
			lblgtGhiChu.setBounds(810, 3, 500, 22);
			lblgtGhiChu.setText(kh.getTenkh() + " hiện đang nợ phí trễ hạn " + dmf.format(tongtien) + " VNĐ");
			btnThanhToan.setVisible(true);
		}
		else {
			lblGhiChu.setBounds(732, 33, 100, 20);
			lblgtGhiChu.setBounds(810, 33, 500, 22);
			lblgtGhiChu.setText("Hiện tại chưa nợ phí trễ hạn");
			btnThanhToan.setVisible(false);
		}
	}

	// Tìm thông tin đĩa và đưa vào TextField
	public void timDiaDuaVaoTextField(Dia dia) {
		diaThue = null;
//		Dia dia = diacon.timDiaTheoMa(madia);
		if(dia != null) {
			if(dia.getTrangthai().equals("S"))
				diaThue = dia;
			else {
				if(dia.getTrangthai().equals("H")) {
					DatDia diadat = datdiaControl.timDiaKhachHangDaDat(khThueDia, dia);
					if(diadat != null)
						diaThue = dia;
					else {
						JOptionPane.showMessageDialog(this, "Đĩa này đã có khách đặt trước");
//						txtMaDia.selectAll();
//						txtMaDia.requestFocus();
//						return;
					}
				}
				else if(dia.getTrangthai().equals("R")) {
					JOptionPane.showMessageDialog(this, "Đĩa này đã có người thuê");
//					txtMaDia.selectAll();
//					txtMaDia.requestFocus();
//					return;
				}
				else if(dia.getTrangthai().equals("D") || diaThue == null) {
					JOptionPane.showMessageDialog(this, "Đĩa này không có trong kho");
//					txtMaDia.selectAll();
//					txtMaDia.requestFocus();
//					return;
				}
			}
		}
		
		if(diaThue != null) {
			txtTuaDia.setText(diaThue.getTuadia().getTentua());
			if(diaThue.getTuadia().getLoaidia().getMaloaidia() == 1)
				txtLoaiDia.setText("Phim");
			else
				txtLoaiDia.setText("Game");
			txtPhiTreHan.setText(dmf.format(diaThue.getTuadia().getPhitrehan()));
			txtHanThue.setText(Integer.toString(diaThue.getTuadia().getLoaidia().getHanthue()));
			txtGiaThue.setText(dmf.format(diaThue.getTuadia().getLoaidia().getGiathue()));
			lblAnh.setIcon(resizeImage("images/"+ diaThue.getTuadia().getAnh(), null));

			btnLuu.setEnabled(true);
			btnThem.setEnabled(true);
			btnXoa.setEnabled(false);
			txtTuaDia.requestFocus();
			txtMaDia.setText(diaThue.getMadia());
		}
		else {
//			JOptionPane.showMessageDialog(this, "Đĩa này không có trong kho");
			txtMaDia.selectAll();
			txtMaDia.requestFocus();
			return;
		}
	}

	// Đưa dữ liệu vào đối tượng chi tiết phiếu thuê
	public ChiTietPhieuThue ganDoiTuongChiTietPhieuThue(PhieuThue pt) {

		double phitrehan = Double.parseDouble(txtPhiTreHan.getText().replaceAll(",", ""));
		int hantradia = Integer.parseInt(txtHanThue.getText());
		double giathue = Double.parseDouble(txtGiaThue.getText().replaceAll(",", ""));
		ChiTietPhieuThue ctpt = new ChiTietPhieuThue(pt, diaThue, phitrehan, hantradia, giathue, "C");
		return ctpt;
	}

	// Thêm chi tiết phiếu thuê vào bảng
	public  void themChiTietPhieuThue(ChiTietPhieuThue ctpt) {
		if(ctpt != null) {
			if(!arrayCTPT.contains(ctpt)) {
				arrayCTPT.add(ctpt);
				String loaidia = ctpt.getDia().getTuadia().getLoaidia().getTenloaidia();
				
				String[] a = {Integer.toString(tabCTPT.getRowCount() + 1),ctpt.getDia().getMadia(),ctpt.getDia().getTuadia().getTentua(),
						loaidia,dmf.format(ctpt.getPhitrehan()),Integer.toString(ctpt.getHantradia()),dmf.format(ctpt.getGiathue())};
				modCTPT.addRow(a);
				tongtien += ctpt.getGiathue();
				txtTongTien.setText(dmf.format(tongtien));
				xoatrangFieldDia();
				btnHuy.setEnabled(true);
			}
			else {
				JOptionPane.showMessageDialog(this, "Đĩa này đã có trong phiếu thuê");
				txtMaDia.selectAll();
				txtMaDia.requestFocus();
			}
		}
	}

	// Đưa chi tiết phiếu thêu vào bảng
	public void duaChiTietPhieuThueVaoTable(ArrayList<ChiTietPhieuThue> arr) {
		for(int i = 0; i < arr.size(); i++) {
			ChiTietPhieuThue ctpt = arr.get(i);
			themChiTietPhieuThue(ctpt);
		}
	}

	// xóa đĩa đã chọn trong bảng
	public void xoaDiaTrongBang(int row) {
		xoatrangFieldDia();
		tongtien -= Double.parseDouble(tabCTPT.getValueAt(row, 6).toString().replaceAll(",", ""));

		arrayCTPT.remove(row);
		modCTPT.removeRow(row);
		txtTongTien.setText(dmf.format(tongtien));
		if(arrayCTPT.size() > 0)
			duaChiTietPhieuThueVaoTable(arrayCTPT);
		else {
			btnXoa.setEnabled(false);
			btnLuu.setEnabled(false);
		}
	}

	// Lưu phiếu thuê vào CSDL
	public void luuPhieuThue(PhieuThue pt) {
		if(pt != null) {
			pthuecon.themPhieuThue(pt);
			Dia dia;
			DatDia diadat;
			for (ChiTietPhieuThue ctpt : arrayCTPT) {
				pthuecon.themChiTietPhieuThue(ctpt);
				dia = ctpt.getDia();
				
				// tìm và kiểm tra xem đĩa này đã gán hay chưa
				diadat = datdiaControl.timDiaKhachHangDaDat(khThueDia, dia);
				if(diadat != null)
					datdiaControl.xoaDatDia(khThueDia.getIdkh(), dia.getTuadia().getMatua());
				
				dia.setTrangthai("R");
				diacon.capnhatThongTinDia(dia);
			}

			huyPhieuThue();

			txtMaPT.setText(capnhatMaPhieuThue());
			JOptionPane.showMessageDialog(this, "Phiếu thuê được lập thành công");
		}
	}

	@Override
	public void actionPerformed(ActionEvent e) {
		Object ob = e.getSource();
		if(ob == btnThem) {

			if(!txtTuaDia.getText().equals("")) {
				PhieuThue pt = new PhieuThue(txtMaPT.getText(), khThueDia, new Date());
				ChiTietPhieuThue ctpt = ganDoiTuongChiTietPhieuThue(pt);
				themChiTietPhieuThue(ctpt);
			}
			else
				JOptionPane.showMessageDialog(this, "Chưa có thông tin đĩa");
		}
		else if(ob == btnHuy)
			huyPhieuThue();							// Xóa luôn phiếu thuê đã gán cho khách hàng nàys
		else if(ob == btnXoa) {
			int row = tabCTPT.getSelectedRow();
			if(row != -1) {
				if(JOptionPane.showConfirmDialog(this, "Bạn có chắc muốn xóa không?",
						"Cảnh báo", JOptionPane.YES_NO_OPTION) == JOptionPane.YES_OPTION) {

					xoaDiaTrongBang(row);
				}
			}
			else
				JOptionPane.showMessageDialog(this, "Bạn phải chọn đĩa để xóa khỏi phiếu thuê");
		}
		else if(ob == btnLuu) {
			PhieuThue pt = new PhieuThue(txtMaPT.getText(), khThueDia, new Date());
			luuPhieuThue(pt);
		}
		else if(ob == btnThanhToan)
			new Form_ThanhToanPhiTreHan(khThueDia).setVisible(true);
	}

	@Override
	public void keyPressed(KeyEvent e) {
		Object ob = e.getSource();
		if(e.getKeyCode() == KeyEvent.VK_ENTER) {
			if(ob == txtMaKH) {
				String idkh = txtMaKH.getText();
				// bắt lỗi nhập sai mã
				if(idkh.equals("")) {
					JOptionPane.showMessageDialog(this, "ID của khách hàng không được rỗng");
					txtMaKH.requestFocus();
					xoatrangFieldKhachHang();
					return;
				}

				timvaduaThongTinKHvaoTextField(idkh);
			}
			if(ob == txtMaDia) {
				String madia = txtMaDia.getText();
				// bắt lỗi nhập sai mã
				if(madia.equals("")) {
					JOptionPane.showMessageDialog(this, "Mã đĩa không được rỗng");
					txtMaDia.requestFocus();
					xoatrangFieldDia();
					return;
				}
				else {
					if(listDia.getSelectedIndex() != -1)
						chonDiaTrongJList();
					else {
						JOptionPane.showMessageDialog(this, "Mã đĩa không đúng");
						txtMaDia.selectAll();
						txtMaDia.requestFocus();
					}
				}

//				timDiaDuaVaoTextField(madia);
			}
		}
	}

	public boolean timThongTinDia(String madia) {
		ArrayList<Dia> arrayDia = new ArrayList<>();
		arrayDia = diacon.soKhopMaDia(madia);
		if(arrayDia.size() > 0) {
			modelList.removeAllElements();
			duaDiaVaoJList(arrayDia);
			return true;
		}
		return false;
	}
	
	@Override
	public void keyReleased(KeyEvent e) {

		if(e.getSource() == txtMaDia) {
			if(!txtMaDia.getText().equals("")) {
				boolean bTimDia = timThongTinDia(txtMaDia.getText());
				if(bTimDia == true)
					scrollTimKiemDia.setVisible(true);
				else
					scrollTimKiemDia.setVisible(false);
			}
			else {
				scrollTimKiemDia.setVisible(false);
				xoatrangFieldDia();
			}
		}
	}

	@Override
	public void keyTyped(KeyEvent e) {}

	@Override
	public void mouseClicked(MouseEvent e) {
		if(e.getSource() == listDia) {
			int row = listDia.getSelectedIndex();
			if(row != -1)
				chonDiaTrongJList();
		}
		else if(e.getSource() == tabCTPT) {
			int row = tabCTPT.getSelectedRow();
			if(row != -1) {
				String madia = tabCTPT.getValueAt(row, 1).toString();
				txtMaDia.setText(madia);
				txtTuaDia.setText(tabCTPT.getValueAt(row, 2).toString());
				txtLoaiDia.setText(tabCTPT.getValueAt(row, 3).toString());
				txtPhiTreHan.setText(tabCTPT.getValueAt(row, 4).toString());
				txtHanThue.setText(tabCTPT.getValueAt(row, 5).toString());
				txtGiaThue.setText(tabCTPT.getValueAt(row, 6).toString());

				btnXoa.setEnabled(true);

				for (ChiTietPhieuThue ctpt : arrayCTPT) {
					if(madia.equals(ctpt.getDia().getMadia())) {
						lblAnh.setIcon(resizeImage("images/"+ ctpt.getDia().getTuadia().getAnh(), null));
						break;
					}
				}
			}
		}
	}

	@Override
	public void mouseEntered(MouseEvent e) {}

	@Override
	public void mouseExited(MouseEvent e) {}

	@Override
	public void mousePressed(MouseEvent e) {}

	@Override
	public void mouseReleased(MouseEvent e) {}

}
