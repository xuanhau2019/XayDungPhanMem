package gui;

import java.awt.BorderLayout;
import java.awt.Color;
import java.awt.Dimension;
import java.awt.Font;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.KeyEvent;
import java.awt.event.KeyListener;
import java.util.ArrayList;

import javax.swing.Box;
import javax.swing.ImageIcon;
import javax.swing.JButton;
import javax.swing.JComboBox;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.JTextField;

import control.LoaiDiaControl;
import entities.LoaiDia;

@SuppressWarnings("serial")
public class Form_CapNhatLoaiDia extends JFrame implements ActionListener, KeyListener {

	JLabel lblTD, lblLoaiDia, lblThongTin;
	JComboBox<String> cbxLoai;
	JTextField txtThongTin;
	JButton btnLuu, btnHuy;

	LoaiDiaControl loaidiaControl = new LoaiDiaControl();
	int chooseUpdate = 0;


	/**
	 * Nếu giá trị truyền vào là 1 thì là cập nhật giá thuê của loại đĩa
	 * Nếu giá trị truyền vào là 2 thì là cập nhật thời hạn thuê của loại đĩa
	 */
	public Form_CapNhatLoaiDia(int chonLoaiDia) {

		chooseUpdate = chonLoaiDia;

		setTitle("Cập nhật loại đĩa");
		setSize(400,270);
		setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
		setLocationRelativeTo(null);
		setResizable(false);

		// Tạo frame thanh toán
		JPanel pNorth = new JPanel();
		pNorth.setBackground(Color.CYAN);
		pNorth.add(lblTD = new JLabel(""));
		lblTD.setFont(new Font("Calibri Light", Font.BOLD, 25));
		add(pNorth, BorderLayout.NORTH);

		JPanel pCenter = new JPanel();
		pCenter.setLayout(new BorderLayout());
		pCenter.setPreferredSize(new Dimension(400, 300));

		JPanel pContain = new JPanel();
		pContain.setLayout(null);
		pContain.add(lblLoaiDia = new JLabel("Loại đĩa", JLabel.CENTER));
		pContain.add(cbxLoai = new JComboBox<>());
		lblLoaiDia.setBounds(30, 25, 90, 22);
		cbxLoai.setBounds(140, 25, 200, 25);
		pContain.add(lblThongTin = new JLabel("", JLabel.CENTER));
		pContain.add(txtThongTin = new JTextField());
		lblThongTin.setBounds(30, 80, 90, 22);
		txtThongTin.setBounds(140, 80, 200, 25);
		pCenter.add(pContain);
		add(pCenter, BorderLayout.CENTER);

		JPanel pSouth = new JPanel();
		pSouth.setLayout(new BorderLayout());
		Box boxVertical = Box.createVerticalBox();
		Box boxHorizantal = Box.createHorizontalBox();
		boxHorizantal.add(Box.createHorizontalStrut(25));
		boxHorizantal.add(btnLuu = new JButton("Lưu", new ImageIcon("images/save.png")));
		boxHorizantal.add(Box.createHorizontalStrut(40));
		boxHorizantal.add(btnHuy = new JButton("  Hủy  ", new ImageIcon("images/cancal.png")));
		btnLuu.setPreferredSize(new Dimension(150, 40));
		btnHuy.setPreferredSize(new Dimension(150, 40));
		boxVertical.add(boxHorizantal);
		boxVertical.add(Box.createVerticalStrut(15));
		pSouth.add(boxVertical);
		add(pSouth, BorderLayout.SOUTH);


		if(chonLoaiDia == 1) {
			lblTD.setText("CẬP NHẬT GIÁ THUÊ");
			lblThongTin.setText("Giá thuê");
		}
		else {
			lblTD.setText("CẬP NHẬT HẠN THUÊ");
			lblThongTin.setText("Hạn thuê (ngày)");
		}

		duaLoaiVaoCombobox(loaidiaControl.getAllLoaiDia());
		
		btnLuu.addActionListener(this);
		btnHuy.addActionListener(this);
		
		txtThongTin.addKeyListener(this);
	}

	public void duaLoaiVaoCombobox(ArrayList<LoaiDia> list) {
		for (LoaiDia ld : list)
			cbxLoai.addItem(ld.getTenloaidia());
	}

	public void capnhatGiaThue() {
		if(txtThongTin.getText().equals("")) {
			JOptionPane.showMessageDialog(this, "Chưa nhập giá thuê");
			txtThongTin.requestFocus();
		}
		else {
			try {
				double giathue = Double.parseDouble(txtThongTin.getText());
				if(giathue < 0) {
					JOptionPane.showMessageDialog(this, "Giá thuê phải > 0");
					txtThongTin.selectAll();
					txtThongTin.requestFocus();
					return;
				}

				int chon = cbxLoai.getSelectedIndex();
				LoaiDia loaiUpdate = new LoaiDia();
				if(chon == 0) {
					loaiUpdate = loaidiaControl.getLoaiDiaTheoMa(1);
				}
				else
					loaiUpdate = loaidiaControl.getLoaiDiaTheoMa(2);
					
				loaiUpdate.setGiathue(giathue);
				loaidiaControl.capnhatLoaiDia(loaiUpdate);
				JOptionPane.showMessageDialog(this, "Cập nhật giá thuê thành công");
				txtThongTin.setText("");
			} catch (Exception e) {
				JOptionPane.showMessageDialog(this, "Phải nhập số");
				txtThongTin.selectAll();
				txtThongTin.requestFocus();
			}
		}
	}
	
	public void capnhatHanThue() {
		if(txtThongTin.getText().equals("")) {
			JOptionPane.showMessageDialog(this, "Chưa nhập hạn thuê");
			txtThongTin.requestFocus();
		}
		else {
			try {
				int hanthue = Integer.parseInt(txtThongTin.getText());
				if(hanthue <= 0) {
					JOptionPane.showMessageDialog(this, "Hạn thuê phải >= 0");
					txtThongTin.selectAll();
					txtThongTin.requestFocus();
					return;
				}
				else if(hanthue > 10) {
					JOptionPane.showMessageDialog(this, "Hạn thuê phải < 10");
					txtThongTin.selectAll();
					txtThongTin.requestFocus();
					return;
				}

				int chon = cbxLoai.getSelectedIndex();
				LoaiDia loaiUpdate = new LoaiDia();
				if(chon == 0) {
					loaiUpdate = loaidiaControl.getLoaiDiaTheoMa(1);
				}
				else
					loaiUpdate = loaidiaControl.getLoaiDiaTheoMa(2);
				
				loaiUpdate.setHanthue(hanthue);
				loaidiaControl.capnhatLoaiDia(loaiUpdate);
				JOptionPane.showMessageDialog(this, "Cập nhật hạn thuê thành công");
				txtThongTin.setText("");
			} catch (Exception e) {
				JOptionPane.showMessageDialog(this, "Phải nhập số nguyên");
				txtThongTin.selectAll();
				txtThongTin.requestFocus();
			}
		}
	}

	@Override
	public void actionPerformed(ActionEvent e) {
		Object ob = e.getSource();
		
		if(ob == btnLuu) {
			if(chooseUpdate == 1)
				capnhatGiaThue();
			else
				capnhatHanThue();
		}
		else if(ob == btnHuy)
			this.dispose();
	}

	@Override
	public void keyPressed(KeyEvent e) {
		if(e.getKeyCode() == KeyEvent.VK_ENTER) {
			if(e.getSource() == txtThongTin) {
				if(chooseUpdate == 1)
					capnhatGiaThue();
				else
					capnhatHanThue();
			}
		}
	}

	@Override
	public void keyReleased(KeyEvent e) {
		// TODO Auto-generated method stub
		
	}

	@Override
	public void keyTyped(KeyEvent e) {
		// TODO Auto-generated method stub
		
	}

}
