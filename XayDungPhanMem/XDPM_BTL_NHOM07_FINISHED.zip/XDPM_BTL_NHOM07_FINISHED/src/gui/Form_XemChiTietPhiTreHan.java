package gui;

import java.awt.BorderLayout;
import java.awt.Color;
import java.awt.Dimension;
import java.awt.Font;
import java.awt.Image;
import java.text.DecimalFormat;
import java.text.SimpleDateFormat;

import javax.swing.BorderFactory;
import javax.swing.ImageIcon;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JPanel;

import control.PhiTreHanControl;
import control.PhieuThueControl;
import entities.ChiTietPhieuThue;
import entities.KhachHang;
import entities.PhiTreHan;
import entities.TuaDia;

@SuppressWarnings("serial")
public class Form_XemChiTietPhiTreHan extends JFrame {

	JLabel lblTD, lblTenKH, lblSodt, lblDiaChi, lblTenTua, lblMaDia, lblHanThue, lblNgayThue, lblNgayTra, lblPhiTreHan, lblAnh;
	JLabel lblgtTenKH, lblgtSodt, lblgtDiachi, lblgtTenTua, lblgtMaDia, lblgtHanThue, lblgtNgayThue, lblgtNgayTra, lblgtPhiTreHan;
	
	static final SimpleDateFormat DAYFORMAT = new SimpleDateFormat("yyyy-MM-dd");
	static final DecimalFormat DECIMALFORMAT = new DecimalFormat("#,##0");
	
	public Form_XemChiTietPhiTreHan(String maTreHan) {	
		
		setTitle("Xem chi tiết phí trễ hạn");
		setSize(500,400);
		setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
		setLocationRelativeTo(null);
		setResizable(false);
		
		// Tạo frame thanh toán
		JPanel pNorth = new JPanel();
		pNorth.setBackground(Color.CYAN);
		pNorth.add(lblTD = new JLabel("CHI TIẾT PHÍ TRỄ HẠN"));
		lblTD.setFont(new Font("Calibri Light", Font.BOLD, 25));
		add(pNorth, BorderLayout.NORTH);
		
		JPanel pnCenter = new JPanel();
		pnCenter.setLayout(new BorderLayout());
		JPanel pnConCenter = new JPanel();
		pnConCenter.setLayout(new BorderLayout());
		pnConCenter.setPreferredSize(new Dimension(500,120));
		JPanel pnCenNor = new JPanel();
		pnCenNor.setBorder(BorderFactory.createTitledBorder("Thông tin khách hàng"));
		pnCenNor.setLayout(null);
		pnCenNor.add(lblTenKH = new JLabel("Khách hàng:",JLabel.RIGHT));
		pnCenNor.add(lblgtTenKH = new JLabel());
		lblTenKH.setBounds(15, 20, 80, 20);
		lblgtTenKH.setBounds(120, 20, 300, 20);
		pnCenNor.add(lblSodt = new JLabel("Số điện thoại:", JLabel.RIGHT));
		pnCenNor.add(lblgtSodt = new JLabel());
		lblSodt.setBounds(15, 50, 80, 20);
		lblgtSodt.setBounds(120, 50, 300, 20);
		pnCenNor.add(lblDiaChi = new JLabel("Địa chỉ:", JLabel.RIGHT));
		pnCenNor.add(lblgtDiachi = new JLabel());
		lblDiaChi.setBounds(15, 80, 80, 20);
		lblgtDiachi.setBounds(120, 80, 300, 20);
		pnConCenter.add(pnCenNor);
		pnCenter.add(pnConCenter, BorderLayout.NORTH);
		
		JPanel pnConSouth = new JPanel();
		pnConSouth.setLayout(new BorderLayout());
		pnConSouth.setPreferredSize(new Dimension(500,300));
		JPanel pnContain = new JPanel();
		pnConSouth.setBorder(BorderFactory.createTitledBorder("Xem chi tiết phí trễ hạn"));
		pnConSouth.setLayout(null);
		pnConSouth.add(lblTenTua = new JLabel("Tên tựa đĩa:"));
		pnConSouth.add(lblgtTenTua = new JLabel(""));
		lblTenTua.setBounds(15, 20, 80, 20);
		lblgtTenTua.setBounds(120, 20, 400, 20);
		pnConSouth.add(lblMaDia = new JLabel("Mã đĩa:"));
		pnConSouth.add(lblgtMaDia = new JLabel(""));
		lblMaDia.setBounds(15, 50, 80, 20);
		lblgtMaDia.setBounds(120, 50, 300, 20);
		pnConSouth.add(lblNgayThue = new JLabel("Ngày thuê:"));
		pnConSouth.add(lblgtNgayThue = new JLabel(""));
		lblNgayThue.setBounds(15, 80, 80, 20);
		lblgtNgayThue.setBounds(120, 80, 300, 20);
		pnConSouth.add(lblNgayTra = new JLabel("Ngày trả:"));
		pnConSouth.add(lblgtNgayTra = new JLabel(""));
		lblNgayTra.setBounds(15, 110, 80, 20);
		lblgtNgayTra.setBounds(120, 110, 300, 20);
		pnConSouth.add(lblHanThue = new JLabel("Hạn thuê:"));
		pnConSouth.add(lblgtHanThue = new JLabel(""));
		lblHanThue.setBounds(15, 140, 80, 20);
		lblgtHanThue.setBounds(120, 140, 300, 20);
		pnConSouth.add(lblPhiTreHan = new JLabel("Phí trễ hạn:"));
		pnConSouth.add(lblgtPhiTreHan = new JLabel(""));
		lblPhiTreHan.setBounds(15, 170, 80, 20);
		lblgtPhiTreHan.setBounds(120, 170, 300, 20);
		
		pnConSouth.add(lblAnh = new JLabel(""));
		lblAnh.setBorder(BorderFactory.createLineBorder(Color.BLACK));
		lblAnh.setBounds(285, 45, 200, 160);
		
		pnConSouth.add(pnContain);
		pnCenter.add(pnConSouth, BorderLayout.CENTER);
		add(pnCenter, BorderLayout.CENTER);
		
		timPhiTreHanTheoMaTreHan(maTreHan);
	}
	
	public void timPhiTreHanTheoMaTreHan(String maTreHan) {
		PhiTreHanControl ptreCon = new PhiTreHanControl();		
		PhiTreHan pTreHan = ptreCon.timPhiTreHan(maTreHan);
		if(pTreHan != null)
			ganPhiTreHanVaoLabel(pTreHan);		
	}
	
	// Resize image
	public ImageIcon resizeImage(String imgPath, byte[] pic) {
		ImageIcon myImage = null;
		if (imgPath != null) {
			myImage = new ImageIcon(imgPath);
		}
		else {
			myImage = new ImageIcon(pic);
		}

		Image img1 = myImage.getImage();
		Image img2 = img1.getScaledInstance(lblAnh.getWidth(), lblAnh.getHeight(), Image.SCALE_SMOOTH);
		ImageIcon image = new ImageIcon(img2);
		return image;
	}
	
	public void ganPhiTreHanVaoLabel(PhiTreHan ptre) {
		PhieuThueControl pthueCon = new PhieuThueControl();
		ChiTietPhieuThue ctPhieuThue = pthueCon.timChiTietPhieuThue(ptre.getPhieutra().getPhieuthue(), ptre.getPhieutra().getDia()).get(0);
		TuaDia tuaDia = ctPhieuThue.getDia().getTuadia();
		lblgtTenTua.setText(tuaDia.getTentua());
		lblgtMaDia.setText(ctPhieuThue.getDia().getMadia());
		lblgtNgayThue.setText(DAYFORMAT.format(ctPhieuThue.getPhieuthue().getNgaythue()));
		lblgtNgayTra.setText(DAYFORMAT.format(ptre.getPhieutra().getNgaytradia()));
		lblgtHanThue.setText(Integer.toString(ctPhieuThue.getHantradia()) + " ngày");
		lblgtPhiTreHan.setText(DECIMALFORMAT.format(ctPhieuThue.getPhitrehan()));
		lblAnh.setIcon(resizeImage("images/"+ tuaDia.getAnh(), null));
		
		KhachHang kh = ctPhieuThue.getPhieuthue().getKh();
		lblgtTenKH.setText(kh.getTenkh());
		lblgtSodt.setText(kh.getSodt());
		lblgtDiachi.setText(kh.getDiachi());
	}
	
//	public static void main(String[] args) {
//		new Form_XemChiTietPhiTreHan().setVisible(true);
//	}

}
