package gui;

import java.awt.Color;
import java.awt.Component;
import java.awt.Container;
import java.awt.Cursor;
import java.awt.Desktop;
import java.awt.Font;
import java.awt.Frame;
import java.awt.Image;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.FocusEvent;
import java.awt.event.FocusListener;
import java.awt.event.KeyEvent;
import java.awt.event.KeyListener;
import java.awt.event.MouseEvent;
import java.awt.event.MouseListener;
import java.io.File;
import java.io.IOException;

import javax.imageio.ImageIO;
import javax.swing.ButtonGroup;
import javax.swing.ImageIcon;
import javax.swing.JButton;
import javax.swing.JComboBox;
import javax.swing.JDialog;
import javax.swing.JFileChooser;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.JRadioButton;
import javax.swing.JScrollPane;
import javax.swing.JSpinner;
import javax.swing.JTextArea;
import javax.swing.JTextField;
import javax.swing.JToggleButton;
import javax.swing.SpinnerNumberModel;
import javax.swing.border.LineBorder;
import javax.swing.filechooser.FileFilter;
import javax.swing.filechooser.FileNameExtensionFilter;

import control.LoaiDiaControl;
import control.TuaDiaControl;
import entities.LoaiDia;
import entities.TuaDia;

@SuppressWarnings("serial")
public class ThemTuaJDialog extends JDialog  implements ActionListener, FocusListener, KeyListener, MouseListener{

	TuaDia tuaDia = new TuaDia();

	private JTextField txtMaTua;
	private JTextField txtTenTua;

	private JFileChooser filechoose;

	private String filePath;

	private JButton btnChoose;

	private JLabel lblImg;

	//	private JSpinner spnHanThue;
	//	private JSpinner spnGiaThue;

	private TuaDiaControl control = new TuaDiaControl();

	private JSpinner spnPhiTreHan;

	private JTextArea txtMota;

	private JButton btnThem;

	private JButton btnOpen;

	private JRadioButton rdPhim;

	private JRadioButton rdGame;

	//	private JLabel lblHanThue;

	private JLabel lblPhiTreHan;

	//	private JLabel lblGiaThue;

	private JLabel lblTenTua;

	private JLabel lblMaTua;

	private boolean flagmota = false;

	private boolean flagimg = false;

	private JButton btnHuy;

	public String getMaTua() {
		return tuaDia.getMatua();
	}

	@SuppressWarnings("unused")
	public ThemTuaJDialog(Frame parent, TuaDia tuadiaP) {
		super(parent, true);
		setTitle("Thêm Tựa Đĩa");
		setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
		setSize(679, 605);
		setResizable(false);
		getContentPane().setLayout(null);
		setLocationRelativeTo(parent);

		JPanel panel = new JPanel();
		panel.setBounds(10, 48, 652, 528);
		panel.setBackground(Color.white);
		getContentPane().add(panel);
		panel.setLayout(null);

		JPanel pnTittle = new JPanel();
		pnTittle.setBounds(0, 0, 746, 44);
		getContentPane().add(pnTittle);
		pnTittle.setBackground(Color.cyan);

		JLabel lblTitle = new JLabel("Thêm Tựa Đĩa");
		lblTitle.setFont(new Font("Segoe UI", Font.BOLD, 25));
		pnTittle.add(lblTitle);

		lblMaTua = new JLabel("Mã Tựa");
		lblMaTua.setFont(new Font("Segoe UI", Font.BOLD, 13));
		lblMaTua.setBounds(7, 5, 83, 41);
		panel.add(lblMaTua);

		txtMaTua = new JTextField();
		txtMaTua.setBackground(Color.white);
		txtMaTua.setBorder(null);
		txtMaTua.setEditable(false);
		txtMaTua.setBounds(114, 5, 285, 41);
		txtMaTua.setFont(new Font("Segoe UI", Font.PLAIN, 15));
		txtMaTua.setColumns(10);
		panel.add(txtMaTua);

		lblTenTua = new JLabel("Tên Tựa");
		lblTenTua.setFont(new Font("Segoe UI", Font.BOLD, 13));
		lblTenTua.setBounds(7, 76, 83, 41);
		panel.add(lblTenTua);

		txtTenTua = new JTextField();
		txtTenTua.setToolTipText("Bắt buộc nhập");
		txtTenTua.setFont(new Font("Segoe UI", Font.PLAIN, 15));
		txtTenTua.setColumns(10);
		txtTenTua.setText("Nhập Tên Tựa Đĩa...");
		txtTenTua.setForeground(Color.LIGHT_GRAY);
		txtTenTua.setBounds(114, 74, 285, 41);
		panel.add(txtTenTua);


		lblPhiTreHan = new JLabel("Phí trễ hạn(VND)");
		lblPhiTreHan.setFont(new Font("Segoe UI", Font.BOLD, 13));
		lblPhiTreHan.setBounds(7, 142, 127, 41);
		panel.add(lblPhiTreHan);

		spnPhiTreHan = new JSpinner();
		spnPhiTreHan.setToolTipText("Phí trễ hạn từ 1.000 đồng đến 1.000.000 đồng");
		spnPhiTreHan.setFont(new Font("Segoe UI", Font.PLAIN, 15));
		spnPhiTreHan.setBounds(114, 140, 285, 41);
		panel.add(spnPhiTreHan);

		SpinnerNumberModel smphi = new SpinnerNumberModel(1000,1,1000000,1000);
		spnPhiTreHan.setModel(new SpinnerNumberModel(1000.0, 1000.0, 1000000.0, 1000.0));

		txtMota = new JTextArea(12,14);
		JScrollPane scrollPane = new JScrollPane(txtMota);
		txtMota.setFont(new Font("Segoe UI", Font.PLAIN, 15));
		txtMota.setColumns(10);
		txtMota.setText("Mô tả về đĩa...");
		txtMota.setForeground(Color.LIGHT_GRAY);
		scrollPane.setBounds(114, 215, 285, 99);
		scrollPane.setVerticalScrollBarPolicy(JScrollPane.VERTICAL_SCROLLBAR_ALWAYS);
		panel.add(scrollPane);

		lblImg = new JLabel();
		lblImg.setToolTipText("Chọn hình có tỉ lệ 170x280 để có chất lượng tốt nhất và vui lòng chép hình vào thư mục mặc định");
		lblImg.setBounds(452, 57, 170, 280);
		panel.add(lblImg);

		LineBorder lnbd = new LineBorder(Color.black);
		lblImg.setBorder(lnbd);

		btnThem = new JButton("Thêm");
		btnThem.setContentAreaFilled(false);
		btnThem.setOpaque(true);
		btnThem.setForeground(Color.white);
		btnThem.setBorder(null);
		btnThem.setBackground(Color.decode("#4CAF50"));
		btnThem.setCursor(new Cursor(Cursor.HAND_CURSOR));
		btnThem.setFont(new Font("Segoe UI", Font.BOLD, 15));
		btnThem.setBounds(133, 455, 188, 51);
		panel.add(btnThem);

		filechoose = new JFileChooser();
		disableNav(filechoose);
		filechoose.setFileSelectionMode(JFileChooser.FILES_AND_DIRECTORIES);

		FileFilter imageFilter = new FileNameExtensionFilter(
				"Image files", ImageIO.getReaderFileSuffixes());

		filechoose.addChoosableFileFilter(imageFilter);
		filechoose.setAcceptAllFileFilterUsed(false);

		btnChoose = new JButton("Chọn hình...");
		btnChoose.setToolTipText("Chọn hình đại diện cho tựa đĩa");
		btnChoose.setSize(152, 30);
		btnChoose.setLocation(462, 354);
		btnChoose.addActionListener(this);

		panel.add(btnChoose);

		rdPhim = new JRadioButton("Phim");
		rdPhim.setFont(new Font("Segoe UI", Font.BOLD, 15));
		rdPhim.setBounds(133, 335, 117, 36);
		rdPhim.setBackground(Color.white);
		rdPhim.setToolTipText("Tựa này là Phim");
		panel.add(rdPhim);

		rdGame = new JRadioButton("Game");
		rdGame.setFont(new Font("Segoe UI", Font.BOLD, 15));
		rdGame.setBounds(252, 335, 117, 36);
		rdGame.setToolTipText("Tựa này là Game");
		rdGame.setBackground(Color.white);
		panel.add(rdGame);

		ButtonGroup groupbtn = new ButtonGroup();
		groupbtn.add(rdGame);
		groupbtn.add(rdPhim);
		rdPhim.setSelected(true);

		JLabel lblMoTa = new JLabel("Mô tả");
		lblMoTa.setFont(new Font("Segoe UI", Font.BOLD, 13));
		lblMoTa.setBounds(7, 200, 59, 30);
		panel.add(lblMoTa);

		btnOpen = new JButton("Mở thư mục mặc định");
		btnOpen.setToolTipText("");
		btnOpen.setBounds(462, 395, 152, 30);
		panel.add(btnOpen);

		btnHuy = new JButton("Hủy");
		btnHuy.setContentAreaFilled(false);
		btnHuy.setOpaque(true);
		btnHuy.setForeground(Color.white);
		btnHuy.setBorder(null);
		btnHuy.setBackground(Color.decode("#C14008"));
		btnHuy.setCursor(new Cursor(Cursor.HAND_CURSOR));
		btnHuy.setFont(new Font("Segoe UI", Font.BOLD, 15));
		btnHuy.setBounds(341, 455, 188, 51);
		panel.add(btnHuy);

		//	    JLabel lblbackground = new JLabel();
		//		lblbackground.setBounds(0,0,435,852);
		//		lblbackground.setIcon(new ImageIcon(new ImageIcon("images/FormBackground/ThemTuaDiaBackground.jpg").getImage().getScaledInstance(435, 852, Image.SCALE_AREA_AVERAGING)));
		//		getContentPane().add(lblbackground);

		if (tuadiaP!=null) {
			txtMaTua.setText(tuadiaP.getMatua());
			txtMaTua.setForeground(Color.black);
			txtTenTua.setText(tuadiaP.getTentua());
			txtTenTua.setForeground(Color.black);
			//			spnGiaThue.setValue(tuadiaP.getLoaidia().getGiathue());
			spnPhiTreHan.setValue(tuadiaP.getPhitrehan());
			//			spnHanThue.setValue(tuadiaP.getLoaidia().getHanthue());
			btnThem.setText("Hoàn tất");
			btnThem.setBackground(Color.decode("#C2C018"));
			if(tuadiaP.getMota()!=null) {
				txtMota.setText(tuadiaP.getMota());
				txtMota.setForeground(Color.black);
				flagmota = true;
			}
			if(tuadiaP.getAnh()!=null) {
				filePath = tuadiaP.getAnh();
				lblImg.setIcon(new ImageIcon(new ImageIcon("images/"+filePath).getImage().getScaledInstance(170, 280, Image.SCALE_AREA_AVERAGING)));
				flagimg = true;

			}
		}

		txtTenTua.addFocusListener(this);
		txtTenTua.addKeyListener(this);
		txtMota.addFocusListener(this);
		txtMota.addKeyListener(this);
		//	    spnGiaThue.addKeyListener(this);
		//	    spnHanThue.addKeyListener(this);
		spnPhiTreHan.addKeyListener(this);

		btnThem.addActionListener(this);
		btnOpen.addActionListener(this);
		btnThem.addMouseListener(this);

		btnHuy.addActionListener(this);
		btnHuy.addMouseListener(this);

		if (tuadiaP == null) {
			setTxtMaTua();
		}
	}
	@Override
	public void actionPerformed(ActionEvent e) {
		// TODO Auto-generated method stub
		Object o = e.getSource();
		if(o.equals(btnChoose)) {
			boolean flag = true;
			filechoose.setCurrentDirectory(new File("./images"));
			int returnVal = filechoose.showOpenDialog(getParent());
			if (returnVal == JFileChooser.APPROVE_OPTION ) {
				String filePath = filechoose.getSelectedFile().getAbsolutePath();
				String[] split = filePath.split("images");
				String proPath = System.getProperty("user.dir")+"\\";

				if (!split[0].equals(proPath)) {
					flag = false;
				}
				if(flag) {
					this.filePath = split[1];
					lblImg.setIcon(new ImageIcon(new ImageIcon(filePath).getImage().getScaledInstance(170, 280, Image.SCALE_AREA_AVERAGING)));
				}else {
					JOptionPane.showMessageDialog(this, "Vui lòng chọn hình bên trong thư mục Images");
				}
			}
			else{
				System.out.println("Open command cancelled by user." );           
			} 
		}

		if (o.equals(btnOpen)) {
			File f = new File("./images");
			Desktop ds = Desktop.getDesktop();
			try {
				ds.open(f);
			} catch (IOException e1) {
				e1.printStackTrace();
			}
		}

		if(o.equals(btnThem)) {
			if(txtTenTua.getText().equals("")||txtTenTua.getText().equals("Nhập Tên Tựa Đĩa..."))
				JOptionPane.showMessageDialog(this, "Chưa nhập tên tựa!!");
			else {
				checkrong();
				String matua = txtMaTua.getText();
				String tenTua = txtTenTua.getText();
				int maloaidia = 1;
				LoaiDiaControl loaidiaControl = new LoaiDiaControl();
				if(!flagimg && !flagmota) {
					int c = JOptionPane.showConfirmDialog(this, "Bạn chưa nhập mô tả và chọn hình cho Tựa đĩa này, bạn có chắc chắn lưu ?");
					if (c == JOptionPane.YES_OPTION) {
						flagimg = true;
						flagmota = true;
					}
				}
				else			
					if(!flagimg) {
						int c = JOptionPane.showConfirmDialog(this, "Bạn chưa chọn hình cho Tựa đĩa này, bạn có chắc chắn lưu ?");
						if (c == JOptionPane.YES_OPTION) {
							flagimg = true;
						}
					}
					else
						if(!flagmota) {
							int c = JOptionPane.showConfirmDialog(this, "Bạn chưa nhập mô tả Tựa đĩa này, bạn có chắc chắn lưu ?");
							if (c == JOptionPane.YES_OPTION) {
								flagmota = true;
							}
						}
				if(flagmota && flagimg){
					if (rdGame.isSelected()) {
						maloaidia = 2;
					}
					double phitre = Double.parseDouble((spnPhiTreHan.getValue()+""));

					String mota = txtMota.getText();
					String anh = filePath;

					LoaiDia ld = loaidiaControl.getLoaiDiaTheoMa(maloaidia);
					TuaDia t = new TuaDia(matua, tenTua, ld, phitre, mota, anh);
					if (btnThem.getText().equals("Thêm")) {
						if(control.themTua(t)) {
							this.tuaDia = t;
							JOptionPane.showMessageDialog(this, "Thêm tựa thành công");
							dispose();
						}
					}else {
						if(control.suaTua(t)) {
							//						this.tuaDia = t;
							JOptionPane.showMessageDialog(this, "Sửa tựa thành công");
							dispose();
						}
					}

				}
			}
		}

		if(o.equals(btnHuy)) {
			dispose();
		}
	}

	@SuppressWarnings("rawtypes")
	private void disableNav(Container c) {
		for (Component x : c.getComponents()) {
			if (x instanceof JComboBox)
				((JComboBox)x).setEnabled(false);
			else if (x instanceof JToggleButton) {
				x.setEnabled(false);
			}
			else if (x instanceof Container)
				disableNav((Container)x);
		}
	}

	public void setTxtMaTua() {
		String matua = control.getMatuaMax();
		if(matua == null)
			matua = "TD_0000001";
		else {
			int stt = Integer.parseInt(matua.replaceAll("TD_", "")) + 1;
			if(stt < 10)
				matua = "TD_00000" + stt;
			else if(stt < 100)
				matua = "TD_0000" + stt;
			else if(stt < 1000)
				matua = "TD_000" + stt;
			else if(stt < 10000)
				matua = "TD_00" + stt;
			else if(stt < 100000)
				matua = "TD_0" + stt;
			else
				matua = "TD_" + stt;
		}

		txtMaTua.setText(matua);
	}

	@Override
	public void focusGained(FocusEvent e) {
		Object o = e.getSource();
		if(o.equals(txtTenTua)&&txtTenTua.getText().equals("Nhập Tên Tựa Đĩa...")) {
			txtTenTua.setText("");
			txtTenTua.setForeground(Color.black);
		}

		if(o.equals(txtMota)&&txtMota.getText().equals("Mô tả về đĩa...")) {
			txtMota.setText("");
			txtMota.setForeground(Color.black);
		}
	}

	@Override
	public void focusLost(FocusEvent e) {
		Object o = e.getSource();
		if(o.equals(txtTenTua) && txtTenTua.getText().equals("")) {
			txtTenTua.setText("Nhập Tên Tựa Đĩa...");
			txtTenTua.setForeground(Color.LIGHT_GRAY);
		}

		if(o.equals(txtMota) && txtMota.getText().equals("")) {
			txtMota.setText("Mô tả về đĩa...");
			txtMota.setForeground(Color.LIGHT_GRAY);
		}
	}

	@Override
	public void keyTyped(KeyEvent e) {
		// TODO Auto-generated method stub

	}

	@Override
	public void keyPressed(KeyEvent e) {

	}

	@Override
	public void keyReleased(KeyEvent e) {
		Object o = e.getSource();
		if(o.equals(txtTenTua)) {
			if(txtTenTua.getText().trim().equals("") || txtTenTua.getText().equals("Nhập Tên Tựa Đĩa...")) {
				paintTxtBorderColor(txtTenTua, lblTenTua, false);
			}else {
				paintTxtBorderColor(txtTenTua, lblTenTua, true);
			}
			if (txtTenTua.getText().length() > 300) {
				JOptionPane.showMessageDialog(this, "Bạn đã nhập quá nhiều!");
				paintTxtBorderColor(txtTenTua, lblTenTua, false);
			}
		}

	}

	public boolean checkGia(String spn) {
		try {
			if (Double.parseDouble(spn) >= 1000) {
				return true;
			}else {
				return false;
			}
		} catch (Exception e) {
			JOptionPane.showMessageDialog(this, "Vui lòng nhập số và giá > 1000");
			return false;
		}
	}

	public boolean checkHan(String spn) {
		try {
			if (Integer.parseInt(spn) > 0) {
				return true;
			}else {
				return false;
			}
		} catch (Exception e) {
			JOptionPane.showMessageDialog(this, "Vui lòng nhập số và Hạn thuê > 1 hoặc = 1");
			return false;
		}
	}

	public void paintTxtBorderColor(JTextField txt, JLabel lbl, boolean isTrue) {
		if (isTrue) {
			LineBorder ln = new LineBorder(Color.decode("#82CB87"));
			txt.setBorder(ln);
		}else {
			LineBorder ln = new LineBorder(Color.red);
			txt.setBorder(ln);
		}
	}

	public void checkrong() {
		if(txtMota.getText().trim().equals("")||txtMota.getText().equals("Mô tả về đĩa...")) {
			txtMota.setText("");
			flagmota  = false;
		}else {
			flagmota = true;
		}

		if(filePath==null) {
			flagimg  = false;
		}else {
			flagimg = true;
		}
	}

	@Override
	public void mouseClicked(MouseEvent e) {
		// TODO Auto-generated method stub

	}

	@Override
	public void mousePressed(MouseEvent e) {
		// TODO Auto-generated method stub

	}

	@Override
	public void mouseReleased(MouseEvent e) {
		// TODO Auto-generated method stub

	}

	@Override
	public void mouseEntered(MouseEvent e) {
		Object o = e.getSource();
		if(o.equals(btnThem))
			if (btnThem.getText().equals("Thêm")) 
				btnThem.setBackground(Color.decode("#66D856"));	
			else
				btnThem.setBackground(Color.decode("#FFD454"));

		if(o.equals(btnHuy))
			btnHuy.setBackground(Color.decode("#FF6B83"));
	}

	@Override
	public void mouseExited(MouseEvent e) {
		Object o = e.getSource();
		if(o.equals(btnThem))
			if (btnThem.getText().equals("Thêm")) 
				btnThem.setBackground(Color.decode("#4CAF50"));	
			else
				btnThem.setBackground(Color.decode("#C2C018"));
		if(o.equals(btnHuy))
			btnHuy.setBackground(Color.decode("#C14008"));
	}
}
