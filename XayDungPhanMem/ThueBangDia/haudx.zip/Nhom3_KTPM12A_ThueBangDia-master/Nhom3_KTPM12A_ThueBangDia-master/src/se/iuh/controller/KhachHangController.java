package se.iuh.controller;

import se.iuh.model.KhachHang;

public class KhachHangController extends GeneralCRUD<KhachHang> {

}
