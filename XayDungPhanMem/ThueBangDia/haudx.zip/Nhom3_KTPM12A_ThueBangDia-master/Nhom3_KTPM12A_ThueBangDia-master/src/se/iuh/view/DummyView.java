package se.iuh.view;

public class DummyView {

}
