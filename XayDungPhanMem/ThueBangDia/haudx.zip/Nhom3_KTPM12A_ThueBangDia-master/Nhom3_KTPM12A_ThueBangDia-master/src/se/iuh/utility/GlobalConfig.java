package se.iuh.utility;

public class GlobalConfig {
	public static final int THONGKE_TATCA = 0;
	public static final int THONGKE_TREHAN = 1;
	public static final int THONGKE_NOPHI = 2;
}
