package se.iuh.controller;

import se.iuh.model.PhieuThue;

public class PhieuThueController extends GeneralCRUD<PhieuThue> {

}
