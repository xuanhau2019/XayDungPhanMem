package se.iuh.controller;

import se.iuh.model.ThanhToanTreHan;

public class ThanhToanTreHanController extends GeneralCRUD<ThanhToanTreHan> {

}
