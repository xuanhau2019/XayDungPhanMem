package se.iuh.controller;

import se.iuh.model.PhieuTra;

public class PhieuTraController extends GeneralCRUD<PhieuTra> {
	
}
