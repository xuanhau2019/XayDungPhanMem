package se.iuh.controller;

import se.iuh.model.NhanVien;

public class NhanVienController extends GeneralCRUD<NhanVien> {

}
